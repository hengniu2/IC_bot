console.log("✅ BC Game background script loaded.");

// Store the latest game data
let latestGameData = null;

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "NEW_BCGAME_DATA") {
        console.log("🎮 Background received game data:", message.data);
        latestGameData = message.data;
        
        // Broadcast to all tabs
        broadcastToReactApp(message.data);
    }
    
    // Return true to indicate we'll respond asynchronously
    return true;
});

// Function to broadcast data to the React app
function broadcastToReactApp(data) {
    // Get all tabs
    chrome.tabs.query({}, (tabs) => {
        // Send message to all tabs except the sender
        tabs.forEach((tab) => {
            // Only send to http/https URLs (to avoid errors with chrome:// tabs)
            if (tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
                chrome.tabs.sendMessage(tab.id, {
                    type: "BCGAME_DATA_BROADCAST",
                    data: data
                }).catch(error => {
                    // Ignore errors from tabs that don't have listeners
                    console.log(`Could not send to tab ${tab.id}`);
                });
            }
        });
    });
}

// Handle requests for the latest data
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "GET_LATEST_BCGAME_DATA") {
        sendResponse({ data: latestGameData });
    }
    return true;
});
