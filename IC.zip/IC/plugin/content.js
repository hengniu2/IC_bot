console.log("✅ BC Game content script loaded.");

function getGameData() {
    const container = document.querySelector('div.relative.w-full.overflow-auto.pb-2.rounded-none.max-h-\\[31rem\\].sm\\:max-h-\\[36rem\\]');
    if (!container) return null;

    const firstRow = container.querySelector('table tbody tr');
    if (!firstRow) return null;

    const gameIdSpan = firstRow.querySelector('td:first-child span.text-primary.hover\\:underline.leading-6');
    const lastTd = firstRow.querySelector('td:last-child');

    if (gameIdSpan && lastTd) {

        const data =  {
            gameId: gameIdSpan.textContent.trim(),
            hash: lastTd.textContent.trim()
        };
        return data
    }
    return null;
}

// Function to send data to the background script
function sendToBackground(data) {
    chrome.runtime.sendMessage({ type: "NEW_BCGAME_DATA", data: data });
}

function setupObserver() {
    const targetNode = document.querySelector('div.relative.w-full.overflow-auto.pb-2.rounded-none.max-h-\\[31rem\\].sm\\:max-h-\\[36rem\\]');
    if (targetNode) {
        console.log("🎯 Table container found! Setting up observer...");
        const initialData = getGameData();
        if (initialData) {
            console.log("🚀 Initial Game Data:", initialData);
            // Send to background script
            sendToBackground(initialData);
            // Also send via postMessage for any in-page listeners
            window.postMessage({ type: "NEW_BCGAME_DATA", data: initialData }, "*");
        } else {
            console.log("❌ No data found on initial load.");
        }
        const observer = new MutationObserver(() => {
            console.log("📢 Table updated!");
            const data = getGameData();
            if (data) {
                console.log("🎲 New Game Data:", data);
                // Send to background script
                sendToBackground(data);
                // Also send via postMessage for any in-page listeners
                window.postMessage({
                    type: "NEW_BCGAME_DATA",
                    data: data
                }, "*");
            }
        });
        observer.observe(targetNode, { childList: true, subtree: true });
    } else {
        console.log("⚠️ Table container not found. Retrying...");
        setTimeout(setupObserver, 1000);  // Retry every 1 second until found
    }
}

setupObserver();
