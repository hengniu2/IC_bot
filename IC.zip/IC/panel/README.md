Key Terms:

MNP: Moon Next Pairs

TR+: Three Reds

MSS: Moon Sum Series

BVH (VFB): Bust Value History

MID: Moon Interval Difference

SBtrend: Immediate Analysis of Current Situation

Bots:

Red-Three-Bot:
This bot fires when the "Next Value" of the 3 cards in the TR+ pattern is less than 3.

MoonTouch Bot:
This bot fires when the last two values in the Moon Sum Series (MSS) are both less than 40.

MoonNextPairs Bot:
This bot checks the following MNP patterns:

const patternsToCheck = [
  [1, 1, 1, 1, 1, 2],
  [1, 1, 1, 1, 1, 2, 1],
  [1, 1, 1, 1, 1, 2, 1, 1],
  [1, 1, 1, 1, 1, 2, 1, 1, 1],
  [2, 2, 2, 2, 2, 1],
  [2, 2, 2, 2, 2, 1, 2],
  [2, 2, 2, 2, 2, 1, 2, 2],
  [2, 2, 2, 2, 2, 1, 2, 2, 2]
];

Let me know if you need any further clarification.

BadRedsBot
  3 reds
  Loss After Win: 2-3, <1.5

SwingBot
  3 Signals
  