// components/EmailService.js
import React, { useEffect, useRef } from 'react';

// CORS proxy URL (This is a free proxy, but you may want to host your own in production)
const CORS_PROXY_URL = 'https://cors-anywhere.com/';

// The original Resend API endpoint
const RESEND_API_URL = 'https://api.resend.com/emails';

// Resend API Key and Recipient Emails
const RESEND_API_KEY = 're_hu6YTGMr_JiQHP1sjfFCDf6xTqsbUeajC';
const RECIPIENT_EMAILS =  
  'itsbigdavid99@gmail.com';


function EmailService({ botStatus, botType }) {
  const previousStatusRef = useRef(null);
  const emailCooldownRef = useRef(0);

  const sendEmailNotification = async (subject, message) => {
    // Cooldown to prevent spam (5 minutes)
    const now = Date.now();
    if (now - emailCooldownRef.current < 5 * 60 * 1000) {

      return;
    }

    try {
      // Prepend the CORS proxy URL to the original API endpoint
      const urlWithProxy = CORS_PROXY_URL + RESEND_API_URL;

      // Send the email notification via the proxy
      const response = await fetch(urlWithProxy, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'onboarding@resend.dev',
          to: RECIPIENT_EMAILS, // Now sends to both email addresses
          subject: subject,
          html: `
            <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4;">
              <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2 style="color: #4CAF50; margin-top: 0;">🚨 Trading Bot Alert</h2>
                <p><strong>Bot Type:</strong> ${botType}</p>
                <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
                <hr style="margin: 20px 0;">
                <p style="color: #666; font-size: 12px;">
                  This is an automated notification from your trading bot system.
                </p>
              </div>
            </div>
          `,
        }),
      });

      if (response.ok) {
        console.log('Email notification sent successfully to all recipients');
        emailCooldownRef.current = now;
      } else {
        const errorText = await response.text();
        console.error('Failed to send email:', errorText);

        // Check if it's an authentication error
        if (response.status === 401 || response.status === 403) {
          console.error('Authentication failed - check your RESEND_API_KEY');
        }
      }
    } catch (error) {
      console.error('Error sending email:', error);
    }
  };

  useEffect(() => {
    // Only send email when status changes to "Active"
    if (botStatus === 'Active' && previousStatusRef.current !== 'Active') {
      sendEmailNotification(
        `🤖 ${botType} - ACTIVE iCrash SIGNAL`,
        `Enjoy`
      );
    }

    // Update previous status
    previousStatusRef.current = botStatus;
  }, [botStatus, botType]);

  // This component doesn't render anything visible
  return null;
}

export default EmailService;