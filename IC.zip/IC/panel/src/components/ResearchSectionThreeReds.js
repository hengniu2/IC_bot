// components/ResearchSection.js
import React, { useMemo, useState } from 'react';

// Helper function to find sequences of 5+ games with bust < 2x followed by value > 2x
const findLowSequencesFollowedByHigh = (bustValues, analysisLength) => {
  // Apply length limit if specified
  let analysisValues = [...bustValues];
  if (analysisLength && analysisLength > 0) {
    analysisValues = bustValues.slice(0, analysisLength);
  }
  
  analysisValues = analysisValues.reverse();
  const sequences = [];
  let currentLowSequence = [];
  
  for (let i = 0; i < analysisValues.length - 1; i++) {
    const currentBust = analysisValues[i];
    const nextBust = analysisValues[i + 1];
    
    // If current bust is < 2, add to current low sequence
    if (currentBust < 2) {
      currentLowSequence.push({ 
        index: i, 
        value: currentBust,
        gameNumber: i + 1
      });
    } else {
      // If we have a sequence of 5+ low busts and next value is > 2
      if (currentLowSequence.length >= 3 && currentBust > 2) {
        // REVERSED: WIN (>3) or HOLD (2-3)
        const resultType = currentBust >= 3 ? 'WIN' : 'HOLD';
        
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: i + 1,
          nextValue: currentBust,
          resultType: resultType,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2))
        });
      }
      // Reset the sequence
      currentLowSequence = [];
    }
  }
  
  // Check if there's a sequence at the end of the array
  if (currentLowSequence.length >= 3) {
    sequences.push({
      lowSequenceLength: currentLowSequence.length,
      startGame: currentLowSequence[0].gameNumber,
      endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
      nextGame: 'N/A',
      nextValue: 'N/A',
      resultType: 'INCOMPLETE',
      lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2)),
      incomplete: true
    });
  }
  return sequences;
};

function ResearchSectionThreeReds({ gameResults }) {
  const [analysisLength, setAnalysisLength] = useState(200);
  
  // Research calculations
  const researchData = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return {
        lowSequences: []
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    
    // Find sequences of 5+ games with bust < 2x followed by value > 2x
    const lowSequences = findLowSequencesFollowedByHigh(bustValues, analysisLength);
    return {lowSequences: lowSequences};
    // return {
    //   lowSequences: lowSequences.slice(-15) // Show top 15 sequences
    // };
  }, [gameResults, analysisLength]);

  const handleAnalysisLengthChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value > 0) {
      setAnalysisLength(value);
    }
  };

  if (!gameResults || gameResults.length === 0) {
    return (
      <div style={{
        marginTop: '40px',
        padding: '20px',
        background: '#f8f9fa',
        borderRadius: '8px',
        border: '1px solid #dee2e6'
      }}>
        <h2>Research Section</h2>
        <p>No game data available for research.</p>
      </div>
    );
  }

  return (
    <div style={{
      marginTop: '40px',
      padding: '20px',
      background: '#f8f9fa',
      borderRadius: '8px',
      border: '1px solid #dee2e6'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2 style={{ margin: 0 }}>TR+</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <label htmlFor="analysisLengthInput" style={{ fontSize: '14px', fontWeight: 'bold' }}>
            Analysis Length:
          </label>
          <input
            type="number"
            id="analysisLengthInput"
            min="1"
            max="10000"
            value={analysisLength}
            onChange={handleAnalysisLengthChange}
            style={{
              width: '80px',
              padding: '5px 8px',
              border: '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '14px'
            }}
          />
          <span style={{ fontSize: '12px', color: '#6c757d' }}>
            games
          </span>
        </div>
      </div>

      <div style={{ 
        fontSize: '12px', 
        color: '#666', 
        background: '#fff', 
        padding: '10px', 
        borderRadius: '4px',
        marginBottom: '15px',
        border: '1px solid #ddd'
      }}>
        <strong>Analysis Info:</strong> Total games analyzed: {Math.min(gameResults.length, analysisLength)} | 
        Sequences found: {researchData.lowSequences.length} |
        Showing last 15 sequences
      </div>
      
      {researchData.lowSequences.length > 0 ? (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
          gap: '15px',
          maxHeight: '500px',
          overflowY: 'auto',
          padding: '10px'
        }}>
          {researchData.lowSequences.map((sequence, index) => (
            <div key={index} style={{ 
              padding: '15px', 
              background: sequence.incomplete ? '#fff3cd' : 
                         sequence.resultType === 'WIN' ? '#d4edda' : 
                         sequence.resultType === 'HOLD' ? '#f8d7da' : '#e2e3e5',
              borderRadius: '8px',
              border: `2px solid ${sequence.incomplete ? '#ffeaa7' : 
                                sequence.resultType === 'WIN' ? '#c3e6cb' : 
                                sequence.resultType === 'HOLD' ? '#f5c6cb' : '#d6d8db'}`,
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <div style={{ marginBottom: '10px', fontSize: '16px', fontWeight: 'bold' }}>
                Sequence {index + 1}: {sequence.lowSequenceLength}
              </div>
              
              <div style={{ fontSize: '14px', marginBottom: '8px' }}>
                <strong>Games:</strong> {sequence.startGame} - {sequence.endGame}
              </div>            
    
              {!sequence.incomplete ? (
                <div style={{ fontSize: '14px', marginBottom: '8px' }}>
                  <strong>Next game ({sequence.nextGame}):</strong> 
                  <span style={{ 
                    color: sequence.resultType === 'WIN' ? '#28a745' : 
                           sequence.resultType === 'HOLD' ? '#dc3545' : '#6c757d',
                    fontWeight: 'bold',
                    marginLeft: '5px',
                    fontSize: '16px'
                  }}>
                    {sequence.nextValue.toFixed(2)}x - {sequence.resultType}
                  </span>
                </div>
              ) : (
                <div style={{ fontSize: '14px', color: '#856404', fontWeight: 'bold' }}>
                  ⚠️ No next value available (end of data)
                </div>
              )}
              
              <div style={{ 
                fontSize: '12px', 
                color: '#6c757d', 
                marginTop: '10px',
                padding: '8px',
                background: 'rgba(255,255,255,0.7)',
                borderRadius: '4px'
              }}>
                <strong>Low sequence values:</strong><br/>
                [{sequence.lowSequenceValues.join(', ')}]
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ 
          padding: '20px', 
          textAlign: 'center',
          background: 'white',
          borderRadius: '8px',
          border: '1px solid #dee2e6'
        }}>
          <p style={{ fontSize: '16px', color: '#6c757d' }}>
            No sequences of 5+ games &lt; 2x followed by &gt; 2x found in the current data.
          </p>
        </div>
      )}
    </div>
  );
}

export default ResearchSectionThreeReds;