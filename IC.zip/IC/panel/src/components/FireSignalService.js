// components/FireSignalService.js
import React, { useEffect, useRef } from 'react';

// Base webhook URL
const FIRESIGNAL_BASE_URL = 'http://localhost:5678/webhook/937ad9c1-19be-4a95-a9f3-615eb4b68fb5/';

function FireSignalService({ botName, betValue, fireSignal, onFireSignal }) {
  const fireSignalSentRef = useRef(false);

  // Function to send firesignal web request
const sendFireSignal = async () => {
  try {
    const query = new URLSearchParams({
      bot: String(botName ?? ""),
      bet: String(betValue ?? ""),
    }).toString();

    const url = `${FIRESIGNAL_BASE_URL}?${query}`;
    console.log("Sending FireSignal request to:", url);

    const response = await fetch(url, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    });

    if (response.ok) {
      console.log(`FireSignal sent for ${botName} with bet $${betValue}`);
      return true;
    } else {
      console.error("FireSignal failed:", response.status);
      return false;
    }
  } catch (error) {
    console.error("Error sending FireSignal:", error);
    return false;
  }
};

  // Effect for firesignal web requests
  useEffect(() => {
    // Send firesignal when fireSignal prop is true and hasn't been sent yet
    if (fireSignal && !fireSignalSentRef.current) {
      sendFireSignal().then(success => {
        if (success) {
          fireSignalSentRef.current = true;
          console.log(`${botName} FireSignal web request sent`);
          
          // Call the callback to auto-execute bet if provided
          if (onFireSignal) {
            onFireSignal();
          }
        }
      });
    }
    
    // Reset fireSignalSent when fireSignal becomes false
    if (!fireSignal && fireSignalSentRef.current) {
      fireSignalSentRef.current = false;
      console.log(`${botName} FireSignal reset`);
    }
  }, [fireSignal, botName, betValue, onFireSignal]);

  // This component doesn't render anything visible
  return null;
}

export default FireSignalService;