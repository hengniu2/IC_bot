// components/BotControlPanel.js
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import FireSignalService from './FireSignalService';

function BotControlPanel({ mainBot, lastGeneratedBust }) {
  const [botStates, setBotStates] = useState({
    fourV: false,
    swing: false,
    badRed: false,
    threeBad: false,
    moonSeries: false,
    moonTouch: false
  });

  const [badRedTriggerSent, setBadRedTriggerSent] = useState(false);
  const [badRedTriggerKey, setBadRedTriggerKey] = useState(0);

  // Handle toggle for each bot
  const handleToggle = (botName) => {
    const newState = !botStates[botName];
    setBotStates(prev => ({
      ...prev,
      [botName]: newState
    }));

    // For BadRed, send trigger signal when toggled ON
    if (botName === 'badRed' && newState) {
      // Reset trigger state and increment key to force re-trigger
      setBadRedTriggerSent(false);
      setTimeout(() => {
        setBadRedTriggerSent(true);
        setBadRedTriggerKey(prev => prev + 1);
        // Reset after signal is sent
        setTimeout(() => {
          setBadRedTriggerSent(false);
        }, 2000);
      }, 100);
    }
  };

  const bots = [
    { key: 'fourV', name: '4V', displayName: '4V Bot' },
    { key: 'swing', name: 'Swing', displayName: 'Swing Bot' },
    { key: 'badRed', name: 'BadRed', displayName: 'Bad Red Bot' },
    { key: 'threeBad', name: '3Bad', displayName: '3 Bad Bot' },
    { key: 'moonSeries', name: 'MoonSeries', displayName: 'Moon Series Bot' },
    { key: 'moonTouch', name: 'MoonTouch', displayName: 'Moon Touch Bot' }
  ];

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#f5f5f5',
      padding: '40px 20px',
      fontFamily: 'Arial, sans-serif',
      marginTop: 0,
      paddingTop: '40px'
    }}>
      <div style={{
        maxWidth: '800px',
        margin: '0 auto',
        backgroundColor: 'white',
        borderRadius: '12px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        padding: '40px'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px',
          borderBottom: '2px solid #007bff',
          paddingBottom: '20px'
        }}>
          <h2 style={{
            margin: 0,
            fontSize: '28px',
            fontWeight: 'bold',
            color: '#333'
          }}>
            Bot Control Panel
          </h2>
          <Link
            to="/"
            style={{
              padding: '10px 20px',
              backgroundColor: '#6c757d',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '6px',
              fontSize: '14px',
              fontWeight: 'bold',
              transition: 'background-color 0.3s',
              display: 'inline-block'
            }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#5a6268'}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#6c757d'}
          >
            ← Back to Main
          </Link>
        </div>

      <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '15px'
      }}>
        {bots.map((bot) => (
          <div
            key={bot.key}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '15px',
              backgroundColor: botStates[bot.key] ? '#e8f5e8' : '#f8f9fa',
              borderRadius: '8px',
              border: `2px solid ${botStates[bot.key] ? '#4CAF50' : '#dee2e6'}`,
              transition: 'all 0.3s ease'
            }}
          >
            <div>
              <div style={{
                fontSize: '16px',
                fontWeight: 'bold',
                color: '#333',
                marginBottom: '4px'
              }}>
                {bot.displayName}
              </div>
              <div style={{
                fontSize: '12px',
                color: '#666'
              }}>
                {botStates[bot.key] ? 'Trigger: ON' : 'Trigger: OFF'}
              </div>
            </div>

            <label style={{
              position: 'relative',
              display: 'inline-block',
              width: '60px',
              height: '30px',
              cursor: 'pointer'
            }}>
              <input
                type="checkbox"
                checked={botStates[bot.key]}
                onChange={() => handleToggle(bot.key)}
                style={{
                  opacity: 0,
                  width: 0,
                  height: 0
                }}
              />
              <span style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: botStates[bot.key] ? '#4CAF50' : '#ccc',
                borderRadius: '30px',
                transition: '0.3s',
                boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
              }}>
                <span style={{
                  position: 'absolute',
                  content: '""',
                  height: '24px',
                  width: '24px',
                  left: '3px',
                  bottom: '3px',
                  backgroundColor: 'white',
                  borderRadius: '50%',
                  transition: '0.3s',
                  transform: botStates[bot.key] ? 'translateX(30px)' : 'translateX(0)',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
                }} />
              </span>
            </label>
          </div>
        ))}
      </div>

      {/* Fire Signal Service for BadRed - sends trigger when toggle is ON */}
      {botStates.badRed && (
        <FireSignalService
          key={badRedTriggerKey}
          botName="redBad"
          betValue={10}
          fireSignal={badRedTriggerSent}
          onFireSignal={() => {
            if (mainBot && lastGeneratedBust) {
              const result = mainBot.executeBet(10, lastGeneratedBust, 2.0);
              console.log('BadRed Bot Control: Trigger signal sent and bet executed:', result);
            }
          }}
        />
      )}
      </div>
    </div>
  );
}

export default BotControlPanel;

