# ThreeRed Bot n8n Workflow Setup

## Overview
This workflow receives webhook requests from the React panel when ThreeRed Bot is active and triggers the AutoHotkey script.

## Setup Instructions

1. **Import the workflow:**
   - Open n8n
   - Import `backup_threered.json`
   - The workflow contains:
     - Webhook node (receives GET requests)
     - Execute Command node (runs AutoHotkey script)

2. **Configure the Webhook:**
   - Open the Webhook node
   - Note the webhook path/ID (e.g., `three-red-bot-webhook-id`)
   - Update `FireSignalService.js` in the React panel with the actual webhook ID:
     ```javascript
     'ThreeRed': 'http://localhost:5678/webhook/YOUR_ACTUAL_WEBHOOK_ID/',
     ```

3. **Configure the Execute Command:**
   - Update the AutoHotkey path if different:
     ```json
     "command": "\"C:\\\\Program Files\\\\AutoHotkey\\\\v2\\\\AutoHotkey64.exe\" \"C:\\\\Users\\\\YOUR_USER\\\\Documents\\\\AutoHotkey\\\\threered.ahk\""
     ```

4. **Activate the workflow:**
   - Toggle the workflow to "Active" in n8n

## Workflow Behavior

- Receives GET requests from React panel when ThreeRed Bot detects activation
- Sends requests on each new game data until bust value >= 2.0
- Executes `threered.ahk` script to automate betting

## Testing

Test the webhook by visiting:
```
http://localhost:5678/webhook/YOUR_WEBHOOK_ID?bot=ThreeRed&bet=10
```
