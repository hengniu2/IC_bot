# CORS Fix for n8n Webhooks

## Problem
Browser blocks requests from React app (localhost:3000) to n8n webhook (localhost:5678) due to CORS policy.

## Solution
Add "Respond to Webhook" node with CORS headers in n8n workflow.

## Steps to Fix in n8n

1. **Open your workflow in n8n**

2. **Update Webhook node:**
   - Click on Webhook node
   - Set "Response Mode" to "Using 'Respond to Webhook' Node"
   - This allows the workflow to send a proper response with headers

3. **Add "Respond to Webhook" node:**
   - Add a new node: "Respond to Webhook"
   - Connect it AFTER "Execute Command" node
   - In the node settings, add these Response Headers:
     - `Access-Control-Allow-Origin: *`
     - `Access-Control-Allow-Methods: GET, POST, OPTIONS`
     - `Access-Control-Allow-Headers: Content-Type`

4. **Workflow structure should be:**
   ```
   Webhook → Execute Command → Respond to Webhook
   ```

5. **Save and activate the workflow**

## Alternative: Quick Fix (if you can't modify n8n)

If you can't modify the n8n workflow right now, you can use `mode: 'no-cors'` in FireSignalService.js, but you won't be able to check if the request succeeded.

## Why This Happens

- Browser security: Different origins (localhost:3000 vs localhost:5678) require CORS headers
- n8n webhooks don't send CORS headers by default
- Adding "Respond to Webhook" node with CORS headers fixes this
