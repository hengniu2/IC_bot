console.log("✅ BC Game React content script loaded.");

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "BCGAME_DATA_BROADCAST") {
        // console.log("📡 React content script received:", message.data);
        
        // Forward to the React app using window.postMessage
        window.postMessage({
            type: "NEW_BCGAME_DATA",
            data: message.data,
            source: "chrome-extension"
        }, "*");
    }
    return true;
});

// Request the latest data when the page loads
chrome.runtime.sendMessage({ type: "GET_LATEST_BCGAME_DATA" }, (response) => {
    if (response && response.data) {
        // console.log("📦 Got latest data from background:", response.data);
        window.postMessage({
            type: "NEW_BCGAME_DATA",
            data: response.data,
            source: "chrome-extension"
        }, "*");
    }
});
