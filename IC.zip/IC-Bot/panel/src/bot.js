// bot.js
export class MainBot {
  constructor(initialBalance = 1000) {
    this.balance = initialBalance;
    this.betHistory = [];
    this.config = {
      baseBet: 10,
      maxSeriesLength: 8
    };
  }

  convertToBinaryPattern(moonNextPairs) {
    return moonNextPairs.map(value => value >= 2 ? 2 : 1);
  }

  calculateBetAmount(moonNextPairs) {
    if (!moonNextPairs || moonNextPairs.length < 5) {
      return { amount: 0, status: 'Inactive', reason: 'Insufficient data (need at least 5 values)' };
    }

    const binaryPattern = this.convertToBinaryPattern(moonNextPairs).slice(-8);  

    let matchedPattern = null;

    matchedPattern = this.checkPatternsForLast(binaryPattern);

    if (matchedPattern) {
      const betAmount = this.config.baseBet * (matchedPattern.length - 4);
      return {
        amount: betAmount,
        status: 'Active',
        reason: `Pattern matched: [${matchedPattern.join(', ')}]`,
        pattern: matchedPattern,
        binaryPattern: binaryPattern.slice(-matchedPattern.length)
      };
    }

    return {
      amount: 0,
      status: 'Inactive',
      reason: 'No pattern matched',
      binaryPattern: binaryPattern.slice(-8)
    };
  }


  checkPatternsForLast(binaryPattern) {
    const patternsToCheck = [    
      [1, 1, 1, 1, 1, 2, 1],
      [1, 1, 1, 1, 1, 2, 1, 1],
      [1, 1, 1, 1, 1, 2, 1, 1, 1],     
      [2, 2, 2, 2, 2, 1, 2],
      [2, 2, 2, 2, 2, 1, 2, 2],
      [2, 2, 2, 2, 2, 1, 2, 2, 2]
    ];
    return this.findMatchingPattern(binaryPattern, patternsToCheck);
  }



  findMatchingPattern(binaryPattern, patterns) {
    for (const pattern of patterns) {
      if (this.endsWith(binaryPattern, pattern)) {
        return pattern;
      }
    }
    return null;
  }

  endsWith(array, pattern) {
    if (array.length < pattern.length) return false;
    const endSlice = array.slice(-pattern.length);
    return JSON.stringify(endSlice) === JSON.stringify(pattern);
  }

  executeBet(amount, bustResult, targetMultiplier = 2.0) {
    const profit = bustResult >= targetMultiplier ? amount * (targetMultiplier - 1) : -amount;
    this.balance += profit;
    
    const betRecord = {
      amount,
      bustResult,
      targetMultiplier,
      profit,
      balance: this.balance,
      timestamp: new Date().toISOString()
    };

    this.betHistory.push(betRecord);
    return betRecord;
  }

  getStats() {
    const totalBets = this.betHistory.length;
    const winningBets = this.betHistory.filter(bet => bet.profit > 0).length;
    const totalProfit = this.betHistory.reduce((sum, bet) => sum + bet.profit, 0);
    const winRate = totalBets > 0 ? (winningBets / totalBets * 100) : 0;

    return {
      totalBets,
      winningBets,
      totalProfit,
      winRate: winRate.toFixed(2),
      currentBalance: this.balance
    };
  }

  updateConfig(newConfig) {
    this.config = { ...this.config, ...newConfig };
  }
}

export const createMainBot = (initialBalance = 1000, config = {}) => {
  const bot = new MainBot(initialBalance);
  bot.updateConfig(config);
  return bot;
};

export default MainBot;