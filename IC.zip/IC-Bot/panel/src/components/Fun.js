// import React, { useState, useEffect } from 'react';
// // --- Define getHighBustResults here ---
// const getHighBustResults = () => {
//     const highFunResults = gameResults
//       .map((res, index) => ({
//         gameId: index + 1,
//         bust: res.bust,
//       }))
//       .filter(item => item.bust == 1.0);
//     const resultHashTable = {};
//     highFunResults.forEach(item => {
//       resultHashTable[item.gameId] = item.bust;
//     });
//     return resultHashTable;
//   };
