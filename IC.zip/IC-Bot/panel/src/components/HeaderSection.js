import React, { useMemo, useState } from 'react';

// Helper function to count pattern occurrences in a stream
const countPatternOccurrences = (stream, pattern) => {
  let count = 0;
  for (let i = 0; i <= stream.length - pattern.length; i++) {
    const segment = stream.slice(i, i + pattern.length);
    const isMatch = segment.every((bit, index) => bit === pattern[index]);
    if (isMatch) {
      count++;
    }
  }
  return count;
};

// Extension by adding last digit repeatedly
const findExtension1Patterns = (totalStream, basePattern) => {
  if (basePattern.length === 0) return [];
  
  const lastDigit = basePattern[basePattern.length - 1];
  const extensions = [];
  
  const patterns = [];
  
  for (let depth = 0; depth <= 4; depth++) {
    const extendedPattern = [...basePattern, ...Array(depth).fill(lastDigit)];
    const count = countPatternOccurrences(totalStream, extendedPattern);
    
    if (count === 0 && depth > 0) {
      break;
    }
    
    patterns.push({
      depth,
      pattern: [...extendedPattern],
      count,
      display: `${basePattern.join('')}${lastDigit.toString().repeat(depth)}`,
      isOriginal: depth === 0,
      isExtension: depth > 0
    });
  }
  
  const totalMatches = patterns.reduce((sum, p) => sum + p.count, 0);
  
  if (totalMatches > 0) {
    extensions.push({
      lastDigit,
      patterns,
      totalMatches
    });
  }
  
  return extensions;
};

function HeaderSection({ lastGeneratedBust, moonPercentResult, gameIdDifferences, gameResults }) {
  const diffEntries = Object.entries(gameIdDifferences || {});
  const last14Diffs = diffEntries.slice(0, 14);
  const last14GameResults = gameResults ? [...gameResults].slice(0,14).reverse() : [];

  const binaryStream = last14GameResults.map(result => {
    const bust = result.bust;
    if (bust > 4 || (bust >= 1.5 && bust <= 2)) {
      return 1;
    } else {
      return 0;
    }
  });

  const findPatternIndices = (stream) => {
    const pattern = [0, 0, 0, 0, 0, 0, 1, 0, 0];
    const indices = [];
    for (let i = 0; i <= stream.length - pattern.length; i++) {
      const segment = stream.slice(i, i + pattern.length);
      const isMatch = segment.every((bit, index) => bit === pattern[index]);
      if (isMatch) {
        indices.push(i);
      }
    }
    return indices;
  };

  const patternIndices = findPatternIndices(binaryStream);
  const [subStreamLength, setSubStreamLength] = useState(6);
  const [isPatternModalOpen, setIsPatternModalOpen] = useState(false);

  const streamAnalysis = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return null;
    }

    const totalStream = gameResults.map(result => 
      result.bust >= 2 ? 2 : 1
    );

    const subStream = gameResults.slice(0, subStreamLength).reverse().map(result => 
      result.bust >= 2 ? 2 : 1
    );

    const extendedPattern1 = [...subStream, 1];
    const extendedPattern2 = [...subStream, 2];

    const countPattern1 = countPatternOccurrences(totalStream, extendedPattern1);
    const countPattern2 = countPatternOccurrences(totalStream, extendedPattern2);

    const totalMatches = countPattern1 + countPattern2;
    const percentage1 = totalMatches > 0 ? ((countPattern1 / totalMatches) * 100).toFixed(1) : '0.0';
    const percentage2 = totalMatches > 0 ? ((countPattern2 / totalMatches) * 100).toFixed(1) : '0.0';

    const extension1Patterns = findExtension1Patterns(totalStream, subStream);

    return {
      totalStream,
      subStream,
      extendedPattern1,
      extendedPattern2,
      countPattern1,
      countPattern2,
      percentage1,
      percentage2,
      totalMatches,
      totalBits: totalStream.length,
      subStreamLength,
      extension1Patterns
    };
  }, [gameResults, subStreamLength]);

  const shouldShowNauseatedIcon = (bust) => {
    return bust < 1.5 || (bust >= 2 && bust <= 3);
  };

  const lastDiffValue = last14Diffs.length > 0 ? last14Diffs[0][1] : null;
  const shouldShowStopMoon = lastDiffValue > 14;

  const handleIncreaseSubStream = () => {
    setSubStreamLength(prev => Math.min(prev + 1, 15));
  };

  const handleDecreaseSubStream = () => {
    setSubStreamLength(prev => Math.max(prev - 1, 3));
  };

  const handleResetSubStream = () => {
    setSubStreamLength(6);
  };

  const togglePatternModal = () => {
    setIsPatternModalOpen(!isPatternModalOpen);
  };

  const renderExtension1 = () => {
    if (!streamAnalysis || !streamAnalysis.extension1Patterns || streamAnalysis.extension1Patterns.length === 0) {
      return null;
    }

    return (
      <div style={{ 
        marginTop: '10px',
        padding: '8px',
        backgroundColor: '#f0f8ff',
        borderRadius: '6px',
        border: '1px solid #d1e7ff'
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {streamAnalysis.extension1Patterns.map((extension, extIndex) => (
            <div key={extIndex} style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <div style={{ 
                fontSize: '10px', 
                fontWeight: 'bold', 
                color: '#28a745',
                padding: '2px 6px',
                backgroundColor: '#e6f7e6',
                borderRadius: '3px'
              }}>
                Last digit: {extension.lastDigit} | Adding series of {extension.lastDigit}
              </div>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '3px', marginLeft: '8px' }}>
                {extension.patterns.map((patternData, patternIndex) => (
                  <div key={patternIndex} style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '8px',
                    padding: '2px 4px',
                    backgroundColor: patternData.count > 0 ? '#f8f9fa' : '#f8f8f8',
                    borderRadius: '3px',
                    border: patternData.count > 0 ? '1px solid #e9ecef' : '1px solid #f1f1f1',
                    opacity: patternData.isOriginal ? 0.7 : 1
                  }}>
                    <span style={{ 
                      fontSize: '9px', 
                      fontWeight: 'bold', 
                      color: patternData.isOriginal ? '#6c757d' : '#495057',
                      minWidth: '40px'
                    }}>
                      {patternData.isOriginal ? 'Original' : `Ext ${patternData.depth}`}:
                    </span>
                    
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <div style={{ display: 'flex', gap: '1px' }}>
                        {patternData.pattern.map((bit, bitIndex) => {
                          const isBase = bitIndex < streamAnalysis.subStream.length;
                          const isExtension = bitIndex >= streamAnalysis.subStream.length;
                          
                          return (
                            <div
                              key={bitIndex}
                              style={{
                                width: '12px',
                                height: '12px',
                                borderRadius: '2px',
                                backgroundColor: bit === 2 ? '#28a745' : '#dc3545',
                                color: 'white',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '7px',
                                fontWeight: 'bold',
                                border: isExtension ? '1px solid #007bff' : 'none',
                                position: 'relative',
                                opacity: patternData.isOriginal ? 0.8 : 1
                              }}
                              title={
                                isBase ? `Base: ${bit}` : `Extension: ${bit}`
                              }
                            >
                              {bit}
                              {isExtension && (
                                <div style={{
                                  position: 'absolute',
                                  top: '-8px',
                                  fontSize: '6px',
                                  color: '#007bff',
                                  fontWeight: 'bold'
                                }}>
                                  +
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                      
                      <span style={{ 
                        fontSize: '8px', 
                        color: patternData.count > 0 ? '#28a745' : '#6c757d',
                        fontWeight: patternData.count > 0 ? 'bold' : 'normal',
                        minWidth: '45px'
                      }}>
                        {patternData.count} matches
                      </span>
                    </div>
                    
                    <div style={{ 
                      fontSize: '8px', 
                      color: patternData.isOriginal ? '#6c757d' : '#495057',
                      fontFamily: 'monospace',
                      marginLeft: 'auto',
                      fontWeight: patternData.isOriginal ? 'normal' : 'bold'
                    }}>
                      {patternData.display}
                    </div>
                  </div>
                ))}
              </div>
              
              <div style={{ 
                fontSize: '8px', 
                color: '#495057',
                fontWeight: 'bold',
                textAlign: 'right',
                paddingRight: '8px'
              }}>
                Total: {extension.totalMatches} matches
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 1000,
        background: 'linear-gradient(135deg, #fafafa 0%, #f5f5f5 100%)',
        borderBottom: '1px solid #e0e0e0',
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
        padding: '10px 20px',
      }}
    >
      {/* First Row: Last Bust + Percent Results */}
      <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', flexWrap: 'wrap', gap: '15px' }}>
        {lastGeneratedBust !== null && (
          <div style={{ padding: '10px 20px', backgroundColor: lastGeneratedBust > 2 ? '#28a745' : '#dc3545', color: 'white', borderRadius: '8px', fontWeight: 'bold', fontSize: '16px', minWidth: '120px', textAlign: 'center', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
            Last: {lastGeneratedBust.toFixed(2)}x
          </div>
        )}
        {moonPercentResult && moonPercentResult.length > 0 && (
          <div style={{ padding: '10px 20px', backgroundColor: '#f8fbfd', borderRadius: '8px', fontSize: '14px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', whiteSpace: 'nowrap' }}>
            {moonPercentResult.map((res) => `${res.total}: ${res.percentageOver10}`).join(' | ')}
          </div>
        )}
      </div>

      {/* Second Row: Last 14 Game Results */}
      {last14GameResults.length > 0 && (
        <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', flexWrap: 'wrap', gap: '15px', marginTop: '12px' }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: 1 }}>
            {last14GameResults.map((result, index) => {
              const showNauseatedIcon = shouldShowNauseatedIcon(result.bust);
              return (
                <div key={result.gameId || index} style={{ backgroundColor: result.bust >= 10 ? '#e0a800' : result.bust >= 2 ? '#198754' : '#c82333', color: 'white', borderRadius: '6px', padding: '6px 10px', fontWeight: 'bold', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', minWidth: '50px', textAlign: 'center', position: 'relative' }}>
                  {result.bust?.toFixed(2)}x
                  {showNauseatedIcon && (
                    <span style={{ position: 'absolute', top: '-6px', right: '-6px', fontSize: '14px', background: 'rgba(255, 255, 255, 0.9)', borderRadius: '50%', width: '18px', height: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 1px 2px rgba(0,0,0,0.2)' }}>🤢</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Third Row: Game ID Differences + 4V Section + Pattern Modal Toggle */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '15px', marginTop: '12px' }}>
        {/* Left Side: Game ID Differences and 4V Section */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1, minWidth: '300px' }}>
          {last14Diffs.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {last14Diffs.reverse().map(([gameId, diff], index) => (
                <div key={index} style={{ backgroundColor: diff > 10 ? 'orange' : '#e0e0e0', color: diff > 10 ? 'white' : '#333', borderRadius: '6px', padding: '6px 10px', fontWeight: 'bold', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', minWidth: '50px', textAlign: 'center' }}>
                  {diff}
                </div>
              ))}
            </div>
          )}

          {/* 4V Section */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', background: '#f8f9fa', padding: '8px 12px', borderRadius: '8px', border: '1px solid #dee2e6', position: 'relative' }}>
            <span style={{ fontSize: '12px', fontWeight: 'bold', color: '#495057', marginRight: '8px', whiteSpace: 'nowrap' }}>4V:</span>
            <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', position: 'relative' }}>
              {binaryStream.map((bit, index) => {
                const isInPattern = patternIndices.some(startIndex => index >= startIndex && index < startIndex + 9);
                return (
                  <div key={index} style={{ width: '20px', height: '20px', borderRadius: '4px', backgroundColor: bit === 1 ? '#28a745' : '#dc3545', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 'bold', boxShadow: '0 1px 2px rgba(0,0,0,0.1)', position: 'relative', zIndex: 2 }}>
                    {bit}
                    {isInPattern && <div style={{ position: 'absolute', bottom: '-2px', left: '0', width: '100%', height: '2px', backgroundColor: '#007bff', zIndex: 1 }} />}
                  </div>
                );
              })}
              {patternIndices.length > 0 && <div style={{ position: 'absolute', top: '-15px', left: `${patternIndices[0] * 24}px`, width: '216px', height: '2px', backgroundColor: '#007bff', zIndex: 1 }} />}
            </div>
            {patternIndices.length > 0 && <div style={{ position: 'absolute', top: '-8px', right: '8px', backgroundColor: '#007bff', color: 'white', fontSize: '9px', fontWeight: 'bold', padding: '2px 6px', borderRadius: '10px', zIndex: 3 }}>PATTERN FOUND</div>}
          </div>
        </div>

        {/* Right Side: Pattern Modal Toggle Button */}
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <button
            onClick={togglePatternModal}
            style={{
              padding: '8px 16px',
              backgroundColor: isPatternModalOpen ? '#dc3545' : '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '12px',
              fontWeight: 'bold',
              cursor: 'pointer',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              transition: 'all 0.3s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              whiteSpace: 'nowrap'
            }}
          >
            {isPatternModalOpen ? 'Close Pattern Analysis' : 'Open Pattern Analysis'}
            <span style={{ fontSize: '14px' }}>
              {isPatternModalOpen ? '▲' : '▼'}
            </span>
          </button>
        </div>
      </div>

      {/* Pattern Prediction Modal */}
      {isPatternModalOpen && streamAnalysis && (
        <div style={{
          marginTop: '15px',
          padding: '15px',
          backgroundColor: '#ffffff',
          borderRadius: '8px',
          border: '1px solid #dee2e6',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          animation: 'slideDown 0.3s ease-out'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '15px',
            paddingBottom: '10px',
            borderBottom: '2px solid #007bff'
          }}>
            <h3 style={{
              fontSize: '14px',
              fontWeight: 'bold',
              color: '#007bff',
              margin: 0
            }}>
              Pattern Prediction Analysis
            </h3>
            <button
              onClick={togglePatternModal}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                color: '#dc3545',
                cursor: 'pointer',
                fontWeight: 'bold',
                padding: '4px 8px'
              }}
              title="Close modal"
            >
              ×
            </button>
          </div>

          {/* Substream Controls */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '15px',
            marginBottom: '15px',
            padding: '10px',
            backgroundColor: '#f8f9fa',
            borderRadius: '6px',
            border: '1px solid #e9ecef'
          }}>
            <span style={{ fontSize: '12px', fontWeight: 'bold', color: '#495057', whiteSpace: 'nowrap' }}>
              Current Substream ({subStreamLength} bits):
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ display: 'flex', gap: '4px' }}>
                {streamAnalysis.subStream.map((bit, index) => (
                  <div key={index} style={{
                    width: '24px',
                    height: '24px',
                    borderRadius: '4px',
                    backgroundColor: bit === 2 ? '#28a745' : '#dc3545',
                    color: 'white',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '11px',
                    fontWeight: 'bold',
                    boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
                  }}>
                    {bit}
                  </div>
                ))}
              </div>
              
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <span style={{ fontSize: '10px', color: '#6c757d' }}>Length:</span>
                <div style={{ display: 'flex', gap: '4px' }}>
                  <button onClick={handleDecreaseSubStream} style={{
                    width: '24px',
                    height: '24px',
                    borderRadius: '4px',
                    backgroundColor: '#6c757d',
                    color: 'white',
                    border: 'none',
                    fontSize: '14px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }} title="Decrease length">-</button>
                  
                  <div style={{
                    padding: '4px 12px',
                    backgroundColor: '#e9ecef',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: 'bold',
                    minWidth: '40px',
                    textAlign: 'center'
                  }}>
                    {subStreamLength}
                  </div>
                  
                  <button onClick={handleIncreaseSubStream} style={{
                    width: '24px',
                    height: '24px',
                    borderRadius: '4px',
                    backgroundColor: '#007bff',
                    color: 'white',
                    border: 'none',
                    fontSize: '14px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }} title="Increase length">+</button>
                  
                  <button onClick={handleResetSubStream} style={{
                    padding: '4px 8px',
                    borderRadius: '4px',
                    backgroundColor: subStreamLength === 6 ? '#28a745' : '#6c757d',
                    color: 'white',
                    border: 'none',
                    fontSize: '10px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    whiteSpace: 'nowrap'
                  }} title="Reset to default">
                    Reset (6)
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Pattern Prediction Results */}
          <div style={{
            display: 'flex',
            gap: '15px',
            marginBottom: '15px',
            flexWrap: 'wrap'
          }}>
            {/* Pattern 1: Add 1 */}
            <div style={{
              flex: 1,
              minWidth: '200px',
              padding: '12px',
              backgroundColor: '#e8f4fd',
              borderRadius: '6px',
              border: '1px solid #b3d9ff'
            }}>
              <div style={{
                fontSize: '11px',
                fontWeight: 'bold',
                color: '#007bff',
                marginBottom: '8px',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}>
                <span>Pattern: Substream + 1</span>
                <div style={{
                  padding: '2px 6px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  borderRadius: '10px',
                  fontSize: '9px'
                }}>
                  {streamAnalysis.countPattern1} matches
                </div>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <div style={{ display: 'flex', gap: '2px' }}>
                  {streamAnalysis.extendedPattern1.map((bit, index) => {
                    const isBase = index < streamAnalysis.subStream.length;
                    const isExtension = index >= streamAnalysis.subStream.length;
                    return (
                      <div key={index} style={{
                        width: '20px',
                        height: '20px',
                        borderRadius: '4px',
                        backgroundColor: bit === 2 ? '#28a745' : '#dc3545',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '10px',
                        fontWeight: 'bold',
                        border: isExtension ? '2px solid #007bff' : 'none',
                        position: 'relative'
                      }}>
                        {bit}
                        {isExtension && (
                          <div style={{
                            position: 'absolute',
                            top: '-10px',
                            fontSize: '8px',
                            color: '#007bff',
                            fontWeight: 'bold'
                          }}>
                            +
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              
              <div style={{
                fontSize: '10px',
                color: '#495057',
                fontWeight: 'bold'
              }}>
                Probability: {streamAnalysis.percentage1}%
              </div>
            </div>

            {/* Pattern 2: Add 2 */}
            <div style={{
              flex: 1,
              minWidth: '200px',
              padding: '12px',
              backgroundColor: '#e8f9e8',
              borderRadius: '6px',
              border: '1px solid #a3d9a3'
            }}>
              <div style={{
                fontSize: '11px',
                fontWeight: 'bold',
                color: '#28a745',
                marginBottom: '8px',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}>
                <span>Pattern: Substream + 2</span>
                <div style={{
                  padding: '2px 6px',
                  backgroundColor: '#28a745',
                  color: 'white',
                  borderRadius: '10px',
                  fontSize: '9px'
                }}>
                  {streamAnalysis.countPattern2} matches
                </div>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <div style={{ display: 'flex', gap: '2px' }}>
                  {streamAnalysis.extendedPattern2.map((bit, index) => {
                    const isBase = index < streamAnalysis.subStream.length;
                    const isExtension = index >= streamAnalysis.subStream.length;
                    return (
                      <div key={index} style={{
                        width: '20px',
                        height: '20px',
                        borderRadius: '4px',
                        backgroundColor: bit === 2 ? '#28a745' : '#dc3545',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '10px',
                        fontWeight: 'bold',
                        border: isExtension ? '2px solid #28a745' : 'none',
                        position: 'relative'
                      }}>
                        {bit}
                        {isExtension && (
                          <div style={{
                            position: 'absolute',
                            top: '-10px',
                            fontSize: '8px',
                            color: '#28a745',
                            fontWeight: 'bold'
                          }}>
                            +
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              
              <div style={{
                fontSize: '10px',
                color: '#495057',
                fontWeight: 'bold'
              }}>
                Probability: {streamAnalysis.percentage2}%
              </div>
            </div>
          </div>

          {/* Extension Patterns Section */}
          {renderExtension1()}

          {/* Summary Footer */}
          <div style={{
            marginTop: '15px',
            paddingTop: '10px',
            borderTop: '1px solid #dee2e6',
            fontSize: '10px',
            color: '#6c757d',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div>
              Based on {streamAnalysis.totalBits} total games | {streamAnalysis.totalMatches} total pattern matches
            </div>
            <div style={{
              padding: '4px 8px',
              backgroundColor: '#e9ecef',
              borderRadius: '4px',
              fontWeight: 'bold'
            }}>
              Overall Confidence: {Math.max(streamAnalysis.percentage1, streamAnalysis.percentage2)}%
            </div>
          </div>
        </div>
      )}

      {shouldShowStopMoon && (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          marginTop: '12px',
          padding: '10px',
          backgroundColor: '#dc3545',
          color: 'white',
          borderRadius: '8px',
          fontWeight: 'bold',
          fontSize: '16px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
          animation: 'pulse 2s infinite'
        }}>
          ⚠️ Stop Moon and idle
        </div>
      )}

      <style>
        {`
          @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
          }
          
          @keyframes slideDown {
            from {
              opacity: 0;
              transform: translateY(-20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
        `}
      </style>
    </div>
  );
}

export default HeaderSection;