// components/RedBadBotPanel.js
import React, { useState, useMemo } from 'react';
import EmailService from './EmailService';
import FireSignalService from './FireSignalService';
import { isBotEnabled } from '../utils/botControl';

// UPDATED: Helper function with while loop for distinct groups
function findBadRedSequences(bustValues, badRedSequencesPanelLength) {
  // Apply length limit BEFORE any processing
  const maxLength = badRedSequencesPanelLength || 200;
  let analysisValues = [...bustValues];
  
  // Take only the most recent games (last 200 or specified length)
  if (analysisValues.length > maxLength) {
    analysisValues = bustValues.slice(0, maxLength);
  }
  
  const totalGames = analysisValues.length;
  
  // Reverse for analysis (newest first)
  analysisValues = analysisValues.reverse();
  
  const sequences = [];
  let i = 0;
  
  while (i < analysisValues.length) {
    // Check if current value is a bad red
    const isBadValue = analysisValues[i] < 1.5 || (analysisValues[i] >= 2 && analysisValues[i] < 3);
    
    if (isBadValue) {
      // Count how many consecutive bad reds starting from position i
      let consecutiveBadReds = 0;
      let j = i;
      
      while (j < analysisValues.length && 
             (analysisValues[j] < 1.5 || (analysisValues[j] >= 2 && analysisValues[j] < 3))) {
        consecutiveBadReds++;
        j++;
      }
      
      // If we have at least 3 consecutive bad reds
      if (consecutiveBadReds >= 3) {
        let foundQualifiedSequence = false;
        let currentPos = i;
        
        // Check groups of 3 starting from position i within this run
        while (currentPos <= j - 3) {
          if (foundQualifiedSequence) {
            break; // Exit as soon as we find first qualifying sequence
          }
          
          const firstThree = [
            analysisValues[currentPos],
            analysisValues[currentPos + 1],
            analysisValues[currentPos + 2]
          ];
          
          // Check how many of these 3 are < 1.5
          const lessThanOnePointFiveCount = firstThree.filter(value => value < 1.5).length;
          
          if (lessThanOnePointFiveCount >= 2) {
            // Get the next 2 values starting from the position AFTER the sequence
            const nextTwoValues = [];
            const startNextIndex = currentPos + 3; // Start from AFTER the first 3 bad reds
            let k = 0;
            
            while (k < 2) {
              const nextIndex = startNextIndex + k;
              if (nextIndex < analysisValues.length) {
                const nextGameNumber = totalGames - nextIndex;
                const nextValue = analysisValues[nextIndex];
                
                if (nextValue !== undefined && nextValue !== null) {
                  nextTwoValues.push({
                    value: nextValue,
                    gameNumber: nextGameNumber
                  });
                }
              }
              k++;
            }
            
            // Calculate bot results
            let botResults = 0;
            if (nextTwoValues.length === 2) {
              if (nextTwoValues.every(item => item.value >= 2)) {
                botResults = -1; // LOSS
              } else {
                botResults = 1; // WIN
              }
            }
            
            sequences.push({
              sequenceLength: 3,
              startGame: totalGames - currentPos,
              endGame: totalGames - (currentPos + 2),
              sequenceValues: firstThree.map(value => value.toFixed(2)),
              lessThanOnePointFiveCount: lessThanOnePointFiveCount,
              nextTwoValues: nextTwoValues,
              botResults: botResults,
              incomplete: nextTwoValues.length < 2
            });
            
            foundQualifiedSequence = true;
          }
          
          currentPos++; // Check next starting position
        }
        
        // If we found at least 1 qualified sequence in this run, skip entire run
        if (foundQualifiedSequence) {
          i = j; // j is the position AFTER the last consecutive bad red
          continue;
        }
      }
    }
    
    // If we get here, no qualifying sequence starting at position i
    i++;
  }
  
  // Return sequences in chronological order (oldest first)
  return sequences;
}

function RedBadBotPanel({ gameResults, mainBot, lastGeneratedBust, botStats, badRedSequencesPanelLength }) {
  const [isMinimized, setIsMinimized] = useState(true);
  const [manualFireSignal, setManualFireSignal] = useState(false);

  // Calculate sequences and bot signal
  const extendedSignal = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return { 
        status: 'Inactive', 
        amount: 0, 
        reason: 'No game data available',
        sequences: []
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    
    // Get sequences using the updated function
    const sequences = findBadRedSequences(bustValues, badRedSequencesPanelLength);
    const lastSequence = sequences[sequences.length - 1];
    
    // Check if last sequence resulted in LOSS
    const lastSequenceWasLoss = lastSequence && lastSequence.botResults === -1;
    
    // Bot is inactive when last sequence is WIN
    const lastSequenceWasWin = lastSequence && lastSequence.botResults === 1;

    // Bot is active ONLY if the most recent sequence resulted in LOSS
    if (lastSequenceWasLoss) {
      const betAmount = 10; // Base bet amount
      return {
        status: 'Active',
        amount: betAmount,
        reason: `Last Bad Red Sequence (Games ${lastSequence.startGame}-${lastSequence.endGame}) had ${lastSequence.lessThanOnePointFiveCount} values <1.5 and resulted in LOSS`,
        lastSequence: lastSequence,
        activationType: 'sequenceLoss'
      };
    } 

    // Bot becomes inactive when last sequence is WIN
    if (lastSequenceWasWin) {
      return {
        status: 'Inactive',
        amount: 0,
        reason: `Last sequence (Games ${lastSequence.startGame}-${lastSequence.endGame}) was WIN - bot deactivated`,
        lastSequence: lastSequence
      };
    }

    // Check if there are any sequences at all
    if (sequences.length === 0) {
      return {
        status: 'Inactive',
        amount: 0,
        reason: 'No qualifying Bad Red sequences detected (need at least 2 values <1.5 in sequence)',
        lastSequence: null
      };
    }

    // Bot is inactive when last sequence was DRAW or incomplete
    return {
      status: 'Inactive',
      amount: 0,
      reason: `Last sequence (Games ${lastSequence.startGame}-${lastSequence.endGame}) was ${lastSequence.incomplete ? 'INCOMPLETE' : 'DRAW'}`,
      lastSequence: lastSequence
    };
  }, [gameResults, badRedSequencesPanelLength]);

  // Check if bot is enabled from control panel
  const botEnabled = isBotEnabled('badRed');

  // Check for fire signal: bot is active AND 3 consecutive bad reds detected AND bot is enabled
  const fireSignalActive = useMemo(() => {
    if (!botEnabled) return false; // Bot disabled from control panel
    if (!gameResults || gameResults.length < 3) return false;
    
    const bustValues = gameResults.map(res => res.bust);
    
    // Check the LAST 3 values (most recent games)
    const lastThreeValues = bustValues.slice(-3);
    
    // All 3 must be "bad reds"
    const allThreeAreBadReds = lastThreeValues.every(value => 
      value < 1.5 || (value >= 2 && value < 3)
    );
    
    // Also need at least 2 values < 1.5 in these 3
    const lessThanOnePointFiveCount = lastThreeValues.filter(value => value < 1.5).length;
    
    return extendedSignal.status === 'Active' && 
           allThreeAreBadReds && 
           lessThanOnePointFiveCount >= 2;
  }, [gameResults, extendedSignal.status, botEnabled]);

  const handleManualExecute = () => {
    if (!botEnabled) {
      console.log('BadRed Bot is disabled from control panel');
      return;
    }
    console.log('Manual Execute button clicked');
    
    // Execute the bet
    if (mainBot && extendedSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(extendedSignal.amount, lastGeneratedBust, 2.0);
      console.log('Manual bet execution:', result);
    }
    
    // Trigger manual firesignal
    setManualFireSignal(true);
    
    // Reset manual firesignal after a short delay
    setTimeout(() => {
      setManualFireSignal(false);
    }, 1000);
  };

  return (
    <>
      {/* Email Service Component - Only if bot is enabled */}
      {botEnabled && (
        <EmailService 
          botStatus={extendedSignal?.status}
          botType="Bad Red Bot"
        />
      )}
      
      {/* Fire Signal Service Component - Only if bot is enabled */}
      {botEnabled && (
        <FireSignalService
          botName="BadRed"
          betValue={extendedSignal.amount || 10}
          fireSignal={fireSignalActive || manualFireSignal}
          onFireSignal={() => {
            if (mainBot && lastGeneratedBust && extendedSignal.amount > 0) {
              const result = mainBot.executeBet(extendedSignal.amount, lastGeneratedBust, 2.0);
              console.log('FireSignal: Auto-executing bet:', result);
            }
          }}
        />
      )}

      {/* Add loading state */}
      {(!gameResults || gameResults.length === 0) ? (
        <div style={{
          position: 'fixed',
          top: '150px',
          right: '320px',
          background: '#f8f9fa',
          border: '2px solid #6c757d',
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🤢⛈️ Bad Red Bot
              {!botEnabled && <span style={{ fontSize: '10px', color: '#dc3545', marginLeft: '6px' }}>(OFF)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                cursor: 'pointer',
                color: '#666'
              }}
            >
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>
            Waiting for game data...
          </div>
        </div>
      ) : isMinimized ? (
        // Minimized state
        <div style={{
          position: 'fixed',
          top: '10px',
          right: '580px',
          background: extendedSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${extendedSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '10px 15px',
          zIndex: 1000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          cursor: 'pointer'
        }}
        onClick={() => setIsMinimized(false)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🤢⛈️</span>
            <span style={{ fontSize: '12px' }}>
              {extendedSignal.status === 'Active' ? `$${extendedSignal.amount}` : 'Inactive'}
            </span>
            <span style={{ 
              fontSize: '10px', 
              color: extendedSignal.status === 'Active' ? '#4CAF50' : '#666',
              fontWeight: 'bold'
            }}>
              {extendedSignal.status === 'Active' ? 'ACTIVE' : 'IDLE'}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer',
                color: '#666',
                marginLeft: 'auto'
              }}
            >
              +
            </button>
          </div>
        </div>
      ) : (
        // Expanded state
        <div style={{
          position: 'fixed',
          top: '360px',
          right: '10px',
          background: extendedSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${extendedSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 3000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          maxHeight: '500px',
          overflow: 'auto'
        }}>
          {/* Header with minimize button */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🔴 Bad Red Bot
              {!botEnabled && <span style={{ fontSize: '12px', color: '#dc3545', marginLeft: '8px' }}>(DISABLED)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(true)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '18px',
                cursor: 'pointer',
                color: '#666',
                padding: '2px 8px',
                borderRadius: '3px'
              }}
              title="Minimize"
            >
              −
            </button>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {extendedSignal.status}</strong></div>
            <div>Bet Amount: <strong>${extendedSignal.amount}</strong></div>
            <div>Reason: {extendedSignal.reason}</div>
            
            {/* Display Bad Red Sequence info */}
            {extendedSignal.lastSequence && (
              <div style={{ 
                marginTop: '8px', 
                padding: '6px', 
                background: extendedSignal.lastSequence.incomplete ? '#fff3cd' : '#e2e3e5',
                borderRadius: '4px',
                border: `1px solid ${extendedSignal.lastSequence.incomplete ? '#ffeaa7' : '#d6d8db'}`
              }}>
                <div style={{ fontSize: '11px', fontWeight: 'bold' }}>
                  Last Bad Red Sequence:
                </div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>
                  Games: {extendedSignal.lastSequence.startGame}-{extendedSignal.lastSequence.endGame}
                </div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>
                  Values: [{extendedSignal.lastSequence.sequenceValues.join(', ')}]
                </div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>
                  Values &lt;1.5: {extendedSignal.lastSequence.lessThanOnePointFiveCount}
                </div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>
                  Next 2 Values: [{extendedSignal.lastSequence.nextTwoValues.map(v => v.value?.toFixed(2) || 'N/A').join(', ')}]
                </div>
                <div style={{ 
                  fontSize: '10px', 
                  fontWeight: 'bold',
                  color: extendedSignal.lastSequence.botResults === -1 ? '#dc3545' : 
                         extendedSignal.lastSequence.botResults === 1 ? '#28a745' : '#ffc107'
                }}>
                  Result: {extendedSignal.lastSequence.botResults === -1 ? 'HOLD' : 
                          extendedSignal.lastSequence.botResults === 1 ? 'WIN' : 'DRAW'}
                </div>
                {extendedSignal.lastSequence.incomplete && (
                  <div style={{ 
                    fontSize: '9px', 
                    color: '#856404', 
                    fontWeight: 'bold',
                    marginTop: '4px'
                  }}>
                    ⚠️ Incomplete sequence
                  </div>
                )}
              </div>
            )}

            {/* Execute Button - Only show when amount > 0 */}
            <div style={{ marginTop: '15px' }}>
              <button 
                onClick={handleManualExecute}
                style={{
                  background: extendedSignal.status === 'Active' ? '#4CAF50' : '#2196F3',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  width: '100%'
                }}
              >
                {extendedSignal.status === 'Active' ? '🚀 Execute & FireSignal' : '⚡ Manual Execute'} 
                ${extendedSignal.amount}
              </button>
              
              <div style={{ 
                fontSize: '10px', 
                color: '#666', 
                marginTop: '8px',
                textAlign: 'center'
              }}>
                {extendedSignal.status === 'Active' 
                  ? 'Places bet AND sends firesignal web request' 
                  : 'Manual execute (bot is currently inactive)'}
              </div>
            </div>
          </div>

          {/* Recent sequences info */}
          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>Activation Rules:</strong></div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              ✅ <strong>ACTIVE</strong>: Last sequence = HOLD (all next 2 values ≥ 2x)
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '2px' }}>
              ❌ <strong>INACTIVE</strong>: Last sequence = WIN (not all next 2 values ≥ 2x)
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '2px' }}>
              ⏸️ <strong>INACTIVE</strong>: Last sequence = DRAW/INCOMPLETE
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px', fontWeight: 'bold' }}>
              Sequence Requirements:
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '2px' }}>
              • Exactly 3 consecutive values in bad range (&lt;1.5 OR 2-3)
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '2px' }}>
              • At least 2 values must be &lt;1.5
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px', fontStyle: 'italic' }}>
              Status updates automatically with each new game
            </div>
            {badRedSequencesPanelLength && (
              <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
                Data limit: {badRedSequencesPanelLength} games
              </div>
            )}
          </div>

          {botStats && (
            <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export default RedBadBotPanel;