// components/RedThreeBotPanel.js
import React, { useState, useMemo, useEffect, useRef } from 'react';
import EmailService from './EmailService';
import FireSignalService from './FireSignalService';
import { isBotEnabled } from '../utils/botControl';

// Helper function to find sequences of 3+ games with bust < 2x followed by value > 2x
const findLowSequencesFollowedByHigh = (bustValues) => {
  bustValues = bustValues.reverse();
  const sequences = [];
  let currentLowSequence = [];
  
  for (let i = 0; i < bustValues.length - 1; i++) {
    const currentBust = bustValues[i];
    const nextBust = bustValues[i + 1];
    
    // If current bust is < 2, add to current low sequence
    if (currentBust < 2) {
      currentLowSequence.push({ 
        index: i, 
        value: currentBust,
        gameNumber: i + 1
      });
    } else {
      // If we have a sequence of 3+ low busts and next value is > 2
      if (currentLowSequence.length >= 3 && currentBust > 2) {
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: i + 1,
          nextValue: currentBust,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2))
        });
      }
      // Reset the sequence
      currentLowSequence = [];
    }
  }
  
  // Check if there's a sequence at the end of the array
  if (currentLowSequence.length >= 3) {
    sequences.push({
      lowSequenceLength: currentLowSequence.length,
      startGame: currentLowSequence[0].gameNumber,
      endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
      nextGame: 'N/A',
      nextValue: 'N/A',      
      lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2)),
      incomplete: true
    });
  }
  
  return sequences;
};

function RedThreeBotPanel({ gameResults, mainBot, lastGeneratedBust, botStats }) {
  const [isMinimized, setIsMinimized] = useState(true);
  const [fireSignalActive, setFireSignalActive] = useState(false);
  const [manualFireSignal, setManualFireSignal] = useState(false);
  
  // Track previous status to detect when bot becomes active
  const previousStatusRef = useRef(null);
  const previousBustRef = useRef(null);
  
  // Check if bot is enabled from control panel
  const botEnabled = isBotEnabled('threeRed');

  // Calculate sequences and bot signal
  const redThreeSignal = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return { 
        status: 'Inactive', 
        amount: 0, 
        reason: 'No game data available',
        sequences: []
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    const sequences = findLowSequencesFollowedByHigh(bustValues);
    
    // Filter out incomplete sequences and get the last 3 complete sequences
    const completeSequences = sequences.filter(seq => !seq.incomplete && seq.nextValue !== 'N/A');
    const lastThreeSequences = completeSequences.slice(-3);
    
    if (lastThreeSequences.length < 3) {
      return {
        status: 'Inactive',
        amount: 0,
        reason: `Need 3 complete sequences, found ${lastThreeSequences.length}`,
        sequences: lastThreeSequences
      };
    }

    // Check if all last three sequences have next values < 3
    const allBelowThree = lastThreeSequences.every(seq => seq.nextValue < 3);
    
    if (allBelowThree) {
      const betAmount = 10; // Base bet amount
      return {
        status: 'Active',
        amount: betAmount,
        reason: 'Last 3 consecutive sequences all have next values < 3x',
        sequences: lastThreeSequences,
        sequenceData: {
          sequence1: {
            length: lastThreeSequences[0].lowSequenceLength,
            nextValue: lastThreeSequences[0].nextValue
          },
          sequence2: {
            length: lastThreeSequences[1].lowSequenceLength,
            nextValue: lastThreeSequences[1].nextValue
          },
          sequence3: {
            length: lastThreeSequences[2].lowSequenceLength,
            nextValue: lastThreeSequences[2].nextValue
          }
        }
      };
    }

    return {
      status: 'Inactive',
      amount: 0,
      reason: `Not all last 3 sequences are below 3x`,
      sequences: lastThreeSequences,
      sequenceData: {
        sequence1: {
          length: lastThreeSequences[0].lowSequenceLength,
          nextValue: lastThreeSequences[0].nextValue
        },
        sequence2: {
          length: lastThreeSequences[1].lowSequenceLength,
          nextValue: lastThreeSequences[1].nextValue
        },
        sequence3: {
          length: lastThreeSequences[2].lowSequenceLength,
          nextValue: lastThreeSequences[2].nextValue
        }
      }
    };
  }, [gameResults]);

  // Effect to handle fire signal logic: trigger on each new game data until bust >= 2.0
  useEffect(() => {
    // Don't process if bot is disabled
    if (!botEnabled) {
      setFireSignalActive(false);
      return;
    }
    
    const isActive = redThreeSignal.status === 'Active';
    const wasActive = previousStatusRef.current === 'Active';
    const bustChanged = previousBustRef.current !== lastGeneratedBust;
    
    // When bot becomes active, start fire signal process
    if (isActive && !wasActive) {
      console.log('RedThree Bot: Activated, starting fire signal sequence');
      setFireSignalActive(true);
      previousBustRef.current = lastGeneratedBust;
    }
    
    // When bot is active and new game data arrives (bust changed)
    if (isActive && bustChanged && lastGeneratedBust !== null) {
      // Check if we should stop (bust >= 2.0)
      if (lastGeneratedBust >= 2.0) {
        console.log(`RedThree Bot: Stopping fire signal - bust value ${lastGeneratedBust} >= 2.0`);
        setFireSignalActive(false);
      } else {
        // Trigger fire signal for this new game data
        console.log(`RedThree Bot: New game data received (bust: ${lastGeneratedBust}), triggering fire signal`);
        // Toggle to trigger FireSignalService
        setFireSignalActive(false);
        setTimeout(() => setFireSignalActive(true), 10);
      }
      previousBustRef.current = lastGeneratedBust;
    }
    
    // When bot becomes inactive, stop fire signals
    if (!isActive && wasActive) {
      console.log('RedThree Bot: Deactivated, stopping fire signal sequence');
      setFireSignalActive(false);
      previousBustRef.current = null;
    }
    
    // Update previous status
    previousStatusRef.current = redThreeSignal.status;
  }, [redThreeSignal.status, lastGeneratedBust, botEnabled]);

  const executeRedThreeBet = () => {
    if (mainBot && redThreeSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
      console.log('RedThree bot bet executed:', result);
    }
  };

  const handleManualExecute = () => {
    if (!botEnabled) {
      console.log('ThreeRed Bot is disabled from control panel');
      return;
    }
    
    console.log('RedThree Bot: Manual Execute button clicked');
    
    // Execute the bet
    if (mainBot && redThreeSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
      console.log('Manual bet execution:', result);
    }
    
    // Trigger manual firesignal
    setManualFireSignal(true);
    
    // Reset manual firesignal after a short delay
    setTimeout(() => {
      setManualFireSignal(false);
    }, 1000);
  };

  return (
    <>
      {/* Email Service Component - Only if bot is enabled */}
      {botEnabled && (
        <EmailService 
          botStatus={redThreeSignal?.status}
          botType="RedThree Bot"
        />
      )}
      
      {/* Fire Signal Service Component - Only if bot is enabled */}
      {botEnabled && (
        <FireSignalService
          botName="ThreeRed"
          betValue={redThreeSignal.amount || 10}
          fireSignal={fireSignalActive || manualFireSignal}
          onFireSignal={() => {
            if (mainBot && lastGeneratedBust && redThreeSignal.amount > 0) {
              const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
              console.log('FireSignal: Auto-executing bet:', result);
            }
          }}
        />
      )}

      {/* Add loading state */}
      {(!gameResults || gameResults.length === 0) ? (
        <div style={{
          position: 'fixed',
          top: '120px',
          right: '320px',
          background: '#f8f9fa',
          border: '2px solid #6c757d',
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🔴👤👤👤 RedThree Bot
              {!botEnabled && <span style={{ fontSize: '12px', color: '#dc3545', marginLeft: '8px' }}>(DISABLED)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                cursor: 'pointer',
                color: '#666'
              }}
            >
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>
            Waiting for game data...
          </div>
        </div>
      ) : isMinimized ? (
        // Minimized state
        <div style={{
          position: 'fixed',
          top: '10px',
          right: '370px',
          background: redThreeSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${redThreeSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '10px 15px',
          zIndex: 1000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          cursor: 'pointer'
        }}
        onClick={() => setIsMinimized(false)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🔴👤👤👤</span>
            <span style={{ fontSize: '12px' }}>
              {redThreeSignal.status === 'Active' ? `$${redThreeSignal.amount}` : 'Inactive'}
            </span>
            <span style={{ 
              fontSize: '10px', 
              color: redThreeSignal.status === 'Active' ? '#4CAF50' : '#666',
              fontWeight: 'bold'
            }}>
              {redThreeSignal.status === 'Active' ? 'ACTIVE' : 'IDLE'}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer',
                color: '#666',
                marginLeft: 'auto'
              }}
            >
              +
            </button>
          </div>
        </div>
      ) : (
        // Expanded state
        <div style={{
          position: 'fixed',
          top: '240px',
          right: '10px',
          background: redThreeSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${redThreeSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 3000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          maxHeight: '500px',
          overflow: 'auto'
        }}>
          {/* Header with minimize button */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🔴 RedThree Bot
              {!botEnabled && <span style={{ fontSize: '12px', color: '#dc3545', marginLeft: '8px' }}>(DISABLED)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(true)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '18px',
                cursor: 'pointer',
                color: '#666',
                padding: '2px 8px',
                borderRadius: '3px'
              }}
              title="Minimize"
            >
              −
            </button>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {redThreeSignal.status}</strong></div>
            <div>Bet Amount: <strong>${redThreeSignal.amount}</strong></div>
            <div>Reason: {redThreeSignal.reason}</div>
            
            {redThreeSignal.sequenceData && (
              <div style={{ marginTop: '8px', fontFamily: 'monospace', fontSize: '11px' }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence1.nextValue < 3 ? '#ffebee' : '#f1f8e9',
                  borderRadius: '3px'
                }}>
                  <span>Seq 1 (L:{redThreeSignal.sequenceData.sequence1.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence1.nextValue < 3 ? '#f44336' : '#4CAF50',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence1.nextValue.toFixed(2)}x
                  </span>
                </div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence2.nextValue < 3 ? '#ffebee' : '#f1f8e9',
                  borderRadius: '3px'
                }}>
                  <span>Seq 2 (L:{redThreeSignal.sequenceData.sequence2.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence2.nextValue < 3 ? '#f44336' : '#4CAF50',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence2.nextValue.toFixed(2)}x
                  </span>
                </div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence3.nextValue < 3 ? '#ffebee' : '#f1f8e9',
                  borderRadius: '3px'
                }}>
                  <span>Seq 3 (L:{redThreeSignal.sequenceData.sequence3.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence3.nextValue < 3 ? '#f44336' : '#4CAF50',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence3.nextValue.toFixed(2)}x
                  </span>
                </div>
              </div>
            )}

            {/* Execute Button */}
            <div style={{ marginTop: '15px' }}>
              <button 
                onClick={handleManualExecute}
                style={{
                  background: redThreeSignal.status === 'Active' ? '#4CAF50' : '#2196F3',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  width: '100%'
                }}
              >
                {redThreeSignal.status === 'Active' ? '🚀 Execute & FireSignal' : '⚡ Manual Execute'} 
                ${redThreeSignal.amount}
              </button>
              
              <div style={{ 
                fontSize: '10px', 
                color: '#666', 
                marginTop: '8px',
                textAlign: 'center'
              }}>
                {redThreeSignal.status === 'Active' 
                  ? 'Places bet AND sends firesignal web request (repeats until bust ≥ 2.0)' 
                  : 'Manual execute (bot is currently inactive)'}
              </div>
              
              {fireSignalActive && (
                <div style={{ 
                  fontSize: '10px', 
                  color: '#4CAF50', 
                  marginTop: '4px',
                  textAlign: 'center',
                  fontWeight: 'bold'
                }}>
                  🔥 FireSignal Active - Waiting for bust ≥ 2.0
                </div>
              )}
            </div>
          </div>

          {/* Recent sequences info */}
          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>Last 3 Sequences Analysis:</strong></div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Looks for sequences of 3+ games &lt; 2x followed by &gt; 2x
            </div>
            <div style={{ fontSize: '9px', color: '#666' }}>
              Activates when last 3 sequences all have next values &lt; 3x
            </div>
          </div>

          {botStats && (
            <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export default RedThreeBotPanel;