// components/ResearchSectionBadReds.js
import React, { useMemo, useState } from 'react';

function findBadRedSequences(bustValues, badRedSequencesPanelLength) {
  // Apply length limit - take only the most recent games
  const maxLength = badRedSequencesPanelLength || 200;
  let analysisValues = [...bustValues];
  
  // Apply length limit - take only the most recent N games
  if (analysisValues.length > maxLength) {
    analysisValues = bustValues.slice(0, maxLength);
  }

  const totalGames = analysisValues.length;
  
  // Reverse for analysis (newest first) - this is correct for detection
  analysisValues = analysisValues.reverse();
  
  const sequences = [];
  let i = 0;
  
  while (i < analysisValues.length) {
    // Check if current value is a bad red
    if (analysisValues[i] < 1.5 || (analysisValues[i] >= 2 && analysisValues[i] < 3)) {
      // Count how many consecutive bad reds starting from position i
      let consecutiveBadReds = 0;
      let j = i;
      
      while (j < analysisValues.length && 
             (analysisValues[j] < 1.5 || (analysisValues[j] >= 2 && analysisValues[j] < 3))) {
        consecutiveBadReds++;
        j++;
      }
      
      // If we have at least 3 consecutive bad reds
      if (consecutiveBadReds >= 3) {
        let foundQualifiedSequence = false;
        let currentPos = i;
        
        // Check groups of 3 starting from position i within this run
        while (currentPos <= j - 3) {
          if (foundQualifiedSequence) {
            break; // Exit the inner loop as soon as we find first qualifying sequence
          }
          
          const firstThree = [
            analysisValues[currentPos],
            analysisValues[currentPos + 1],
            analysisValues[currentPos + 2]
          ];
          
          // Check how many of these 3 are < 1.5
          const lessThanOnePointFiveCount = firstThree.filter(value => value < 1.5).length;
          
          if (lessThanOnePointFiveCount >= 2) {
            // Get the next 2 values starting from the position AFTER the sequence
            const nextTwoValues = [];
            const startNextIndex = currentPos + 3;
            
            for (let k = 0; k < 2; k++) {
              const nextIndex = startNextIndex + k;
              if (nextIndex < analysisValues.length) {
                const nextGameNumber = totalGames - nextIndex;
                const nextValue = analysisValues[nextIndex];
                
                if (nextValue !== undefined && nextValue !== null) {
                  nextTwoValues.push({
                    value: nextValue,
                    gameNumber: nextGameNumber
                  });
                }
              }
            }
            
            // Calculate bot results
            let botResults = 0;
            if (nextTwoValues.length === 2) {
              if (nextTwoValues.every(item => item.value >= 2)) {
                botResults = -1; // LOSS/HOLD
              } else {
                botResults = 1; // WIN
              }
            }
            
            sequences.push({
              sequenceLength: 3,
              startGame: totalGames - currentPos,
              endGame: totalGames - (currentPos + 2),
              sequenceValues: firstThree.map(value => value.toFixed(2)),
              lessThanOnePointFiveCount: lessThanOnePointFiveCount,
              nextTwoValues: nextTwoValues,
              botResults: botResults,
              incomplete: nextTwoValues.length < 2
            });
            
            foundQualifiedSequence = true;
          }
          
          currentPos++; // Check next starting position
        }
        
        // If we found at least 1 qualified sequence in this run, skip entire run
        if (foundQualifiedSequence) {
          i = j; // j is the position AFTER the last consecutive bad red
          continue;
        }
      }
    }
    
    // If we get here, no qualifying sequence starting at position i
    i++;
  }
  
  // Return sequences in chronological order (oldest first)
  return sequences;
}

function ResearchSectionBadReds({ gameResults, badRedSequencesPanelLength: initialPanelLength }) {
  const [panelLength, setPanelLength] = useState(initialPanelLength || 200);
  
  // Research calculations
  const researchData = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return { badRedSequences: [] };
    }

    const bustValues = gameResults.map(res => res.bust);
    const badRedSequences = findBadRedSequences(bustValues, panelLength);
    return {badRedSequences: badRedSequences};
  }, [gameResults, panelLength]);

  const handlePanelLengthChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value > 0) {
      setPanelLength(value);
    }
  };

  if (!gameResults || gameResults.length === 0) {
    return (
      <div style={{
        marginTop: '40px',
        padding: '20px',
        background: '#f8f9fa',
        borderRadius: '8px',
        border: '1px solid #dee2e6'
      }}>
        <h2>Research Section - Bad Reds</h2>
        <p>No game data available for research.</p>
      </div>
    );
  }

  return (
    <div style={{
      marginTop: '40px',
      padding: '20px',
      background: '#f8f9fa',
      borderRadius: '8px',
      border: '1px solid #dee2e6'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2 style={{ margin: 0 }}>BR+</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <label htmlFor="panelLengthInput" style={{ fontSize: '14px', fontWeight: 'bold' }}>
            Analysis Length:
          </label>
          <input
            type="number"
            id="panelLengthInput"
            min="1"
            max="10000"
            value={panelLength}
            onChange={handlePanelLengthChange}
            style={{
              width: '80px',
              padding: '5px 8px',
              border: '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '14px'
            }}
          />
          <span style={{ fontSize: '12px', color: '#6c757d' }}>
            games
          </span>
        </div>
      </div>

      <p style={{ fontSize: '14px', color: '#6c757d', marginBottom: '20px' }}>
        Detects sequences of at least 3 consecutive bust values where: value &lt; 1.5 OR (value ≥ 2.0 AND value &lt; 3.0)<br/>
        <strong>NEW:</strong> Sequences must have at least 2 values &lt; 1.5
      </p>
      
      <div style={{ 
        fontSize: '12px', 
        color: '#666', 
        background: '#fff', 
        padding: '10px', 
        borderRadius: '4px',
        marginBottom: '15px',
        border: '1px solid #ddd'
      }}>
        <strong>Analysis Info:</strong> Total games analyzed: {Math.min(gameResults.length, panelLength)} | 
        Sequences found: {researchData.badRedSequences.length} |
        Showing {Math.min(researchData.badRedSequences.length, 15)} sequences
      </div>
      
      {researchData.badRedSequences.length > 0 ? (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
          gap: '15px',
          maxHeight: '500px',
          overflowY: 'auto',
          padding: '10px'
        }}>
           {researchData.badRedSequences.map((sequence, index) => {
            const sequenceIndex = researchData.badRedSequences.length + index;
            return (
              <div key={index} style={{ 
                padding: '15px', 
                background: sequence.incomplete ? '#fff3cd' : 
                           sequence.botResults === 1 ? '#d4edda' : 
                           sequence.botResults === -1 ? '#f8d7da' : '#e2e3e5',
                borderRadius: '8px',
                border: `2px solid ${sequence.incomplete ? '#ffeaa7' : 
                                  sequence.botResults === 1 ? '#c3e6cb' : 
                                  sequence.botResults === -1 ? '#f5c6cb' : '#d6d8db'}`,
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }}>
                <div style={{ marginBottom: '10px', fontSize: '16px', fontWeight: 'bold' }}>
                  Sequence #{sequenceIndex >= 0 ? sequenceIndex + 1 : index + 1}: {sequence.sequenceLength} values
                </div>
                
                <div style={{ fontSize: '14px', marginBottom: '8px' }}>
                  <strong>Games:</strong> {sequence.startGame} - {sequence.endGame} 
                  <span style={{ fontSize: '12px', color: '#666', marginLeft: '5px' }}>
                    (Game {sequence.startGame} is oldest)
                  </span>
                </div>

                <div style={{ fontSize: '14px', marginBottom: '8px' }}>
                  <strong>Values &lt;1.5:</strong> {sequence.lessThanOnePointFiveCount}
                </div>

                <div style={{ fontSize: '14px', marginBottom: '8px' }}>
                  <strong>Result:</strong> 
                  <span style={{ 
                    color: sequence.botResults === 1 ? '#28a745' : 
                           sequence.botResults === -1 ? '#dc3545' : '#6c757d',
                    fontWeight: 'bold',
                    marginLeft: '5px',
                    fontSize: '16px'
                  }}>
                    {sequence.botResults === 1 ? 'WIN' : 
                     sequence.botResults === -1 ? 'HOLD' : 'DRAW'}
                  </span>
                </div>
                
                {sequence.incomplete && (
                  <div style={{ fontSize: '14px', color: '#856404', fontWeight: 'bold' }}>
                    ⚠️ Incomplete sequence (missing next values)
                  </div>
                )}
                
                <div style={{ 
                  fontSize: '12px', 
                  color: '#6c757d', 
                  marginTop: '10px',
                  padding: '8px',
                  background: 'rgba(255,255,255,0.7)',
                  borderRadius: '4px'
                }}>
                  <strong>Sequence values (chronological order):</strong><br/>
                  [{sequence.sequenceValues.join(', ')}]
                </div>

                {sequence.nextTwoValues.length > 0 && (
                  <div style={{ 
                    fontSize: '12px', 
                    color: '#6c757d', 
                    marginTop: '8px',
                    padding: '8px',
                    background: 'rgba(255,255,255,0.7)',
                    borderRadius: '4px'
                  }}>
                    <strong>Next 2 values after sequence:</strong><br/>
                    [{sequence.nextTwoValues.map(item => item.value?.toFixed(2) || 'N/A').join(', ')}]
                    <div style={{ fontSize: '10px', color: '#999', marginTop: '4px' }}>
                      (Games: {sequence.nextTwoValues.map(item => item.gameNumber).join(', ')})
                    </div>
                  </div>
                )}                

              </div>
            );
          })}
        </div>
      ) : (
        <div style={{ 
          padding: '20px', 
          textAlign: 'center',
          background: 'white',
          borderRadius: '8px',
          border: '1px solid #dee2e6'
        }}>
          <p style={{ fontSize: '16px', color: '#6c757d' }}>
            No qualifying sequences found in current data.
          </p>
          <p style={{ fontSize: '12px', color: '#999', marginTop: '10px' }}>
            Looking for at least 3 consecutive values where: value &lt; 1.5 OR (value ≥ 2.0 AND value &lt; 3.0)<br/>
            <strong>AND</strong> at least 2 values must be &lt; 1.5
          </p>
        </div>
      )}
    </div>
  );
}

export default ResearchSectionBadReds;