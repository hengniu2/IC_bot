// components/FireSignalService.js
import React, { useEffect, useRef } from 'react';

// Webhook URLs for different bots
// NOTE: Update the webhook ID after creating the n8n workflow
// The webhook ID can be found in the n8n workflow webhook node settings
const WEBHOOK_URLS = {
  'BadRed': 'http://localhost:5678/webhook/937ad9c1-19be-4a95-a9f3-615eb4b68fb5/',
  'ThreeRed': 'http://localhost:5678/webhook/e180aa1d-bf2c-4901-9a74-96c63003a209/',
  // Add more bots as needed
};

// Default webhook URL (for backward compatibility)
const DEFAULT_WEBHOOK_URL = 'http://localhost:5678/webhook/937ad9c1-19be-4a95-a9f3-615eb4b68fb5/';

function FireSignalService({ botName, betValue, fireSignal, onFireSignal }) {
  // Get webhook URL for this bot
  const webhookUrl = WEBHOOK_URLS[botName] || DEFAULT_WEBHOOK_URL;
  const fireSignalSentRef = useRef(false);
  const previousFireSignalRef = useRef(false);

  // Function to send firesignal web request
const sendFireSignal = async () => {
  try {
    const query = new URLSearchParams({
      bot: String(botName ?? ""),
      bet: String(betValue ?? ""),
    }).toString();

    const url = `${webhookUrl}?${query}`;
    console.log("Sending FireSignal request to:", url);

    const response = await fetch(url, {
      method: "GET",
      mode: "cors",
      headers: { "Content-Type": "application/json" },
    });

    if (response.ok) {
      console.log(`FireSignal sent for ${botName} with bet $${betValue}`);
      return true;
    } else {
      console.error("FireSignal failed:", response.status);
      return false;
    }
  } catch (error) {
    console.error("Error sending FireSignal:", error);
    return false;
  }
};

  // Effect for firesignal web requests
  useEffect(() => {
    // For ThreeRed bot, allow multiple sends (triggered on each new game data)
    // For other bots (like BadRed), send only once per activation
    const allowMultipleSends = botName === 'ThreeRed';
    const fireSignalJustBecameTrue = fireSignal && !previousFireSignalRef.current;
    
    if (fireSignal) {
      // For ThreeRed: send when fireSignal becomes true (new game data received)
      // For others: send only once when first activated
      if (allowMultipleSends ? fireSignalJustBecameTrue : !fireSignalSentRef.current) {
        sendFireSignal().then(success => {
          if (success) {
            if (!allowMultipleSends) {
              fireSignalSentRef.current = true;
            }
            console.log(`${botName} FireSignal web request sent`);
            
            // Call the callback to auto-execute bet if provided
            if (onFireSignal) {
              onFireSignal();
            }
          }
        });
      }
    }
      
    // Reset fireSignalSent when fireSignal becomes false (for non-ThreeRed bots)
    if (!fireSignal && fireSignalSentRef.current && !allowMultipleSends) {
      fireSignalSentRef.current = false;
      console.log(`${botName} FireSignal reset`);
    }
    // Update previous fireSignal state
    previousFireSignalRef.current = fireSignal;
  }, [fireSignal, botName, betValue, onFireSignal, webhookUrl]);

  // This component doesn't render anything visible
  return null;
}

export default FireSignalService;