import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import CryptoJS from 'crypto-js';
import Chart from 'chart.js/auto';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import Graph from './components/Graph';
import Fun from './components/Fun';
import HeaderSection from './components/HeaderSection';

import MoonPairBotPanel from './components/MoonPairBotPanel';
import MoonTouchBotPanel from './components/MoonTouchBotPanel';
import RedThreeBotPanel from './components/ThreeRedBotPanel';
import RedBadBotPanel from './components/BadRedBotPanel';
import SwingBotPanel from './components/SwingBotPanel';
import FourVBotPanel from './components/FourVBotPanel';
import FloatingChecklistButton from './components/FloatingChecklistButton';
import BotControlPanel from './components/BotControlPanel';

import ResearchSectionThreeReds from './components/ResearchSectionThreeReds';
import ResearchSectionBadReds from './components/ResearchSectionBadReds';
import ResearchSectionNeutralReds from './components/ResearchSectionNeutralReds';

import annotationPlugin from 'chartjs-plugin-annotation';

import { createMainBot } from './bot';
// Constants
const EXTENSION_ID = 'ahjgmndfihjelimnaogkboiimppbhmgl';
const SALT = '0000000000000000000301e2801a9a9598bfb114e574a91a887f2132f33047e6';
const COUNTS = [2000, 100, 200, 400, 800, 1000];

const badRedSequencesPanelLength = 200; 
const swingLength = 20;

// Register Chart.js plugins
Chart.register(ChartDataLabels, annotationPlugin);

// Utility functions
const gameResult = (seed, salt, h = 1) => {
  const nBits = 52;
  
  if (salt) {
    const hmac = CryptoJS.HmacSHA256(CryptoJS.enc.Hex.parse(seed), salt);
    seed = hmac.toString(CryptoJS.enc.Hex);
  }
  
  seed = seed.slice(0, nBits / 4);
  const r = parseInt(seed, 16);
  let X = r / Math.pow(2, nBits);
  X = (100 - h) / (1 - X);
  X = parseFloat(X.toPrecision(9));
  const result = Math.floor(X);
  return Math.max(1, result / 100);
};

const calculateSBForArray = (array) => {
  if (!array || array.length === 0) return 0;

  const last16 = array.slice(-16);
  const last16_g = last16.map(val => (val >= 2 ? 1 : -1));

  const s1 = 4 * last16_g.slice(-4).reduce((sum, v) => sum + v, 0);
  const s2 = 2 * last16_g.slice(-8).reduce((sum, v) => sum + v, 0);
  const s3 = last16_g.reduce((sum, v) => sum + v, 0);

  return s1 + s2 + s3;
};

function App() {
  // State
  const [gameData, setGameData] = useState(null);
  const [gameAmount, setGameAmount] = useState(6048);
  const [gameResults, setGameResults] = useState([]);
  const [lastGeneratedBust, setLastGeneratedBust] = useState(null);
  const [SbTrendResults128, setSbTrendResults128] = useState([]);
  const [SbTrendUpPrediction, setSbTrendUpPrediction] = useState([]);
  const [SbTrendDownPrediction, setSbTrendDownPrediction] = useState([]);
  const [initial6154ResultsReversed, setInitial6154ResultsReversed] = useState([]);
  const [moonSeriesLength, setMoonSeriesLength] = useState(6);
  const [moonSeriesLength2, setMoonSeriesLength2] = useState(60); // Second MSS chart series length
  const [mssItemsCount, setMssItemsCount] = useState(2000); // MSS1 default count
  const [mssItemsCount2, setMssItemsCount2] = useState(6000); // MSS2 default count
  const [isMssFullScreen, setIsMssFullScreen] = useState(false);
  const [sbTrendItemsCount, setSbTrendItemsCount] = useState(125); // New state for SbTrend items count
  const [isSbTrendFullScreen, setIsSbTrendFullScreen] = useState(false); // New state for full screen

  const [mainBot, setMainBot] = useState(null);
  const [betSignal, setBetSignal] = useState(null);
  const [botStats, setBotStats] = useState(null);

  // Initialize bot
  useEffect(() => {
    const bot = createMainBot(1000, {
      baseBet: 10,
      maxSeriesLength: 8
    });
    setMainBot(bot);
    setBotStats(bot.getStats());
  }, []);

  useEffect(() => {
    if (gameResults.length > 0) {
      handleLoadData();
    }
  }, [gameResults]);

  // Refs
  const chartRefs = {
    sbTrendResults: useRef(null),
    mainChart: useRef(null),
    moonSeries: useRef(null),
    moonSeries2: useRef(null), // Add for second MSS chart
    nextValues: useRef(null),
    mssFullScreen: useRef(null),
    sbTrendFullScreen: useRef(null) // New ref for full screen chart
  };

  const chartInstances = {
    sbTrendResults: useRef(null),
    mainChart: useRef(null),
    moonSeries: useRef(null),
    moonSeries2: useRef(null), // Add for second MSS chart
    nextValues: useRef(null),
    mssFullScreen: useRef(null),
    sbTrendFullScreen: useRef(null) // New instance for full screen chart
  };

  // Event listeners
  useEffect(() => {
    const handleWindowMessage = (event) => {
      if (event.source !== window) return;
      if (event.data?.type === 'NEW_BCGAME_DATA') {
        setGameData(event.data.data);
      }
    };

    window.addEventListener('message', handleWindowMessage);
    return () => window.removeEventListener('message', handleWindowMessage);
  }, []);

  // Game results generation
  const generateGameResults = useCallback((amount) => {
    if (!gameData?.hash) return [];

    const results = [];
    let prevHash = gameData.hash;

    for (let i = 0; i < amount; i++) {
      const hash = i === 0 ? prevHash : CryptoJS.SHA256(prevHash).toString();
      const bust = gameResult(hash, SALT, 1);
      results.push({ hash, bust });
      prevHash = hash;
    }

    return results;
  }, [gameData]);

  useEffect(() => {
    if (gameData?.hash) {
      const results = generateGameResults(gameAmount);
      setGameResults(results);
      setLastGeneratedBust(results[0]?.bust || null);
    } else {
      setGameResults([]);
      setLastGeneratedBust(null);
    }
  }, [gameData, gameAmount, generateGameResults]);

  // Memoized data computations
  const initial128ResultsReversed = useMemo(() => 
    gameResults.slice(0, sbTrendItemsCount).map(res => res.bust).reverse(),
    [gameResults, sbTrendItemsCount] // Add sbTrendItemsCount dependency
  );

  const moonNextPairs = useMemo(() => {
    const tempResults = gameResults.slice(0, 2400).map(res => res.bust).reverse();
    const pairResults = [];

    for (let i = 0; i < tempResults.length - 1; i++) {
      if (tempResults[i] > 9.9) {
        pairResults.push(tempResults[i + 1]);
      }
    }

    return pairResults;
  }, [gameResults]);

    // Calculate bet when moonNextPairs updates
  useEffect(() => {
    if (mainBot && moonNextPairs.length >= 5) {
      const signal = mainBot.calculateBetAmount(moonNextPairs);
      setBetSignal(signal);
    }
  }, [mainBot, moonNextPairs]);

  const gameIdDifferences = useMemo(() => {
    const highBustResults = gameResults
      .slice(0, mssItemsCount)
      .map((res, index) => ({ gameId: index + 1, bust: res.bust }))
      .filter(item => item.bust > 9.99);

    const gameIds = highBustResults.map(item => item.gameId).sort((a, b) => a - b);
    const result = {};

    gameIds.forEach((gameId, index) => {
      result[gameId] = index === 0 ? gameId : gameId - gameIds[index - 1];
    });

    return result;
  }, [gameResults, mssItemsCount]);

  // Add memo for second MSS chart gameIdDifferences
  const gameIdDifferences2 = useMemo(() => {
    const highBustResults = gameResults
      .slice(0, mssItemsCount2)
      .map((res, index) => ({ gameId: index + 1, bust: res.bust }))
      .filter(item => item.bust > 9.99);

    const gameIds = highBustResults.map(item => item.gameId).sort((a, b) => a - b);
    const result = {};

    gameIds.forEach((gameId, index) => {
      result[gameId] = index === 0 ? gameId : gameId - gameIds[index - 1];
    });

    return result;
  }, [gameResults, mssItemsCount2]);

  const moonSeriesTableData = useMemo(() => {
    if (!gameData) return [];

    return Object.keys(gameIdDifferences).map((key) => ({
      key,
      sum: moonSumSeries(key, gameIdDifferences, moonSeriesLength),
    }));
  }, [gameResults, gameData, gameIdDifferences, moonSeriesLength]);

  // Add memo for second MSS chart table data (Series 60)
  const moonSeriesTableData2 = useMemo(() => {
    if (!gameData) return [];

    return Object.keys(gameIdDifferences2).map((key) => ({
      key,
      sum: moonSumSeries(key, gameIdDifferences2, moonSeriesLength2), // Use series length 60
    }));
  }, [gameResults, gameData, gameIdDifferences2, moonSeriesLength2]);

  // Calculate 6 packs of 60 sums for gameIdDifferences2
  const sixPacksOf60 = useMemo(() => {
    return calculateSixPacksOf60(gameIdDifferences2);
  }, [gameIdDifferences2]);

  // Calculate trend (UP or DOWN) based on 6 pack values
  const packTrend = useMemo(() => {
    if (!sixPacksOf60 || sixPacksOf60.length < 2) return 'N/A';
    
    // Compare first value (Pack 6, leftmost) with last value (Pack 1, rightmost)
    const firstValue = sixPacksOf60[sixPacksOf60.length - 1]; // Pack 6 (index 5)
    const lastValue = sixPacksOf60[0]; // Pack 1 (index 0)
    
    if (firstValue > lastValue) return 'DOWN';
    if (firstValue < lastValue) return 'UP';
    return 'FLAT';
  }, [sixPacksOf60]);

  const moonPercentResult = useMemo(() => 
    COUNTS.map(count => {
      const slicedResults = gameResults.slice(0, count);
      const bustOverTen = slicedResults.filter(res => res.bust > 10);
      const percentage = (bustOverTen.length / count) * 100;
      
      return {
        total: count,
        bustOverTenCount: bustOverTen.length,
        percentageOver10: percentage.toFixed(2) + '%'
      };
    }),
    [gameResults]
  );

  // SbTrend calculations
  useEffect(() => {
    const sbTrendResults128 = initial128ResultsReversed.map((_, index) => {
      const startIdx = Math.max(0, index - 15);
      const window = initial128ResultsReversed.slice(startIdx, index + 1);
      return calculateSBForArray(window);
    });

    setSbTrendResults128(sbTrendResults128);

    const sbTrendUp = calculateSBForArray(initial128ResultsReversed.slice(-15).concat(2));
    const sbTrendDown = calculateSBForArray(initial128ResultsReversed.slice(-15).concat(1));
    
    const len = sbTrendResults128.length;
    setSbTrendUpPrediction(Array(len).fill(sbTrendUp));
    setSbTrendDownPrediction(Array(len).fill(sbTrendDown));
  }, [initial128ResultsReversed]);

  // Chart effects
useChartEffect({
  chartRef: chartRefs.sbTrendResults,
  instanceRef: chartInstances.sbTrendResults,
  data: {
    labels: SbTrendResults128.map((_, index) => ` ${sbTrendItemsCount - index}`),
    datasets: [
      {
        label: 'SB Trend',
        data: SbTrendResults128,
        borderColor: () => {
          // Check if last 9 items are less than 0
          const last9Items = SbTrendResults128.slice(-9);
          const allNegative = last9Items.length >= 9 && last9Items.every(item => item < 0);
          return allNegative ? 'black' : 'rgb(255, 99, 132)';
        },
        backgroundColor: () => {
          // Check if last 9 items are less than 0
          const last9Items = SbTrendResults128.slice(-9);
          const allNegative = last9Items.length >= 9 && last9Items.every(item => item < 0);
          return allNegative ? 'rgba(0, 0, 0, 0.2)' : 'rgba(255, 99, 132, 0.2)';
        },
        pointRadius: 2,
        pointBorderWidth: 1,
        pointBackgroundColor: 'black',
        pointBorderColor: 'blue',
        tension: 0.2,
      },
      {
        label: 'Up Prediction', 
        data: SbTrendUpPrediction,
        borderColor: 'green',
        borderDash: [5, 5],
        fill: false,
        pointRadius: 0,
      },
      { 
        label: 'Down Prediction',
        data: SbTrendDownPrediction,
        borderColor: 'red',
        borderDash: [5, 5],
        fill: false,
        pointRadius: 0,
      },
    ],
  },
  options: {
    ...sbTrendChartOptions,
    plugins: {
      ...sbTrendChartOptions.plugins,
      annotation: {
        annotations: {
          yZeroLine: {
            type: 'line',
            yMin: 0,
            yMax: 0,
            borderColor: 'rgba(0, 0, 0, 0.5)',
            borderWidth: 2,
            borderDash: [3, 3],
          }
        }
      }
    }
  },
  dependencies: [SbTrendResults128, SbTrendUpPrediction, SbTrendDownPrediction, sbTrendItemsCount]
});

  useChartEffect({
    chartRef: chartRefs.mainChart,
    instanceRef: chartInstances.mainChart,
    data: mainChartData(initial128ResultsReversed),
    options: mainChartOptions,
    dependencies: [gameResults, initial128ResultsReversed]
  });

  useChartEffect({
    chartRef: chartRefs.moonSeries,
    instanceRef: chartInstances.moonSeries,
    data: moonSeriesChartData(moonSeriesTableData, moonSeriesLength, mssItemsCount),
    options: moonSeriesChartOptions,
    dependencies: [moonSeriesTableData, moonSeriesLength, mssItemsCount]
  });

  // Add chart effect for the second MSS chart (Series 60)
  useChartEffect({
    chartRef: chartRefs.moonSeries2,
    instanceRef: chartInstances.moonSeries2,
    data: moonSeriesChartData(moonSeriesTableData2, moonSeriesLength2, mssItemsCount2), // Series length 60
    options: moonSeriesChartOptions,
    dependencies: [moonSeriesTableData2, moonSeriesLength2, mssItemsCount2]
  });

  // Full screen MSS chart effect
  useChartEffect({
    chartRef: chartRefs.mssFullScreen,
    instanceRef: chartInstances.mssFullScreen,
    data: moonSeriesChartData(moonSeriesTableData, moonSeriesLength, mssItemsCount),
    options: {
      ...moonSeriesChartOptions,
      maintainAspectRatio: false,
      plugins: {
        ...moonSeriesChartOptions.plugins,
        legend: {
          display: true,
          position: 'top',
          labels: {
            font: {
              size: 16
            }
          }
        }
      },
      scales: {
        ...moonSeriesChartOptions.scales,
        x: {
          ...moonSeriesChartOptions.scales.x,
          ticks: {
            font: {
              size: 12
            }
          }
        },
        y: {
          ...moonSeriesChartOptions.scales.y,
          ticks: {
            font: {
              size: 12
            }
          }
        }
      }
    },
    dependencies: [moonSeriesTableData, moonSeriesLength, mssItemsCount, isMssFullScreen]
  });

  // Full screen SbTrend chart effect
  useChartEffect({
    chartRef: chartRefs.sbTrendFullScreen,
    instanceRef: chartInstances.sbTrendFullScreen,
    data: {
      labels: SbTrendResults128.map((_, index) => ` ${sbTrendItemsCount - index}`),
      datasets: [
        {
          label: 'SB Trend',
          data: SbTrendResults128,
          borderColor: 'rgb(255, 99, 132)',
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          pointRadius: 2,
          pointBorderWidth: 1,
          pointBackgroundColor: 'black',
          pointBorderColor: 'blue',
          tension: 0.2,
        },
        {
          label: 'Up Prediction', 
          data: SbTrendUpPrediction,
          borderColor: 'green',
          borderDash: [5, 5],
          fill: false,
          pointRadius: 0,
        },
        { 
          label: 'Down Prediction',
          data: SbTrendDownPrediction,
          borderColor: 'red',
          borderDash: [5, 5],
          fill: false,
          pointRadius: 0,
        },
      ],
    },
    options: {
      ...sbTrendChartOptions,
      maintainAspectRatio: false,
      plugins: {
        ...sbTrendChartOptions.plugins,
        legend: {
          display: true,
          position: 'top',
          labels: {
            font: {
              size: 16
            }
          }
        }
      },
      scales: {
        ...sbTrendChartOptions.scales,
        x: {
          ...sbTrendChartOptions.scales.x,
          ticks: {
            font: {
              size: 12
            }
          }
        },
        y: {
          ...sbTrendChartOptions.scales.y,
          ticks: {
            font: {
              size: 12
            }
          }
        }
      }
    },
    dependencies: [SbTrendResults128, SbTrendUpPrediction, SbTrendDownPrediction, sbTrendItemsCount, isSbTrendFullScreen]
  });

  useNextValuesChart({
    chartRef: chartRefs.nextValues,
    instanceRef: chartInstances.nextValues,
    initial6154ResultsReversed,
    lastGeneratedBust,
    dependencies: [initial6154ResultsReversed, lastGeneratedBust]
  });

  // Helper functions
  const handleLoadData = () => {
    const lastResults = gameResults.map(res => res.bust).reverse();
    setInitial6154ResultsReversed(lastResults);
  };

  const handleTrenballClick = () => {
    console.log('Sending message to extension...');
    window.postMessage({ type: 'CLICK_TRENBALL' }, '*');
  };

  const handleMssExtend = () => {
    setIsMssFullScreen(true);
  };

  const handleMssCloseFullScreen = () => {
    setIsMssFullScreen(false);
  };

  const handleSbTrendExtend = () => {
    setIsSbTrendFullScreen(true);
  };

  const handleSbTrendCloseFullScreen = () => {
    setIsSbTrendFullScreen(false);
  };

  // Close full screen on Escape key
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        if (isMssFullScreen) setIsMssFullScreen(false);
        if (isSbTrendFullScreen) setIsSbTrendFullScreen(false);
      }
    };

    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isMssFullScreen, isSbTrendFullScreen]);


  return (
    <>
      <Router>
        <ConditionalHeader
          lastGeneratedBust={lastGeneratedBust}
          moonPercentResult={moonPercentResult}
          gameIdDifferences={gameIdDifferences}
          gameResults={gameResults}
        />
        <Routes>
          <Route path="/" element={
            <MainContent
              moonPercentResult={moonPercentResult}
              gameData={gameData}
              gameAmount={gameAmount}
              onGameAmountChange={setGameAmount}
              moonSeriesTableData={moonSeriesTableData}
              moonSeriesTableData2={moonSeriesTableData2}
              gameIdDifferences={gameIdDifferences}
              gameIdDifferences2={gameIdDifferences2}
              sixPacksOf60={sixPacksOf60}
              packTrend={packTrend}
              lastGeneratedBust={lastGeneratedBust}
              onLastBustChange={setLastGeneratedBust}
              chartRefs={chartRefs}
              moonNextPairs={moonNextPairs}
              onTrenballClick={handleTrenballClick}
              gameResults={gameResults}
              moonSeriesLength={moonSeriesLength}
              onMoonSeriesLengthChange={setMoonSeriesLength}
              moonSeriesLength2={moonSeriesLength2}
              onMoonSeriesLength2Change={setMoonSeriesLength2}
              mssItemsCount={mssItemsCount}
              onMssItemsCountChange={setMssItemsCount}
              mssItemsCount2={mssItemsCount2}
              onMssItemsCount2Change={setMssItemsCount2}
              onMssExtend={handleMssExtend}
              sbTrendItemsCount={sbTrendItemsCount}
              onSbTrendItemsCountChange={setSbTrendItemsCount}
              onSbTrendExtend={handleSbTrendExtend}
            />
          } />
          
          <Route path="/graph" element={<Graph />} />
          <Route path="/fun" element={<Fun />} />
          <Route path="/bot-control" element={
            <BotControlPanel
              mainBot={mainBot}
              lastGeneratedBust={lastGeneratedBust}
            />
          } />
        </Routes>
      </Router>

      {/* Full Screen MSS Modal */}
      {isMssFullScreen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          backgroundColor: 'rgba(0, 0, 0, 0.9)',
          zIndex: 1000,
          display: 'flex',
          flexDirection: 'column',
          padding: '20px'
        }}>
          {/* Header */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px',
            color: 'white'
          }}>
            <h2 style={{ margin: 0, color: 'white' }}>
              MSS - Full Screen View
            </h2>
            <button
              onClick={handleMssCloseFullScreen}
              style={{
                padding: '10px 20px',
                backgroundColor: '#ff4444',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: 'bold'
              }}
            >
              Close (ESC)
            </button>
          </div>

          {/* Controls */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: '20px',
            marginBottom: '20px',
            color: 'white'
          }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <label htmlFor="moonSeriesLengthFull" style={{ marginRight: '8px', fontWeight: 'bold', fontSize: '16px' }}>
                Series Length: 
              </label>
              <input
                type="number"
                id="moonSeriesLengthFull"
                min="1"
                max="20"
                value={moonSeriesLength}
                onChange={(e) => setMoonSeriesLength(parseInt(e.target.value) || 6)}
                style={{
                  width: '80px',
                  padding: '8px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  textAlign: 'center',
                  fontSize: '16px'
                }}
              />
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <label htmlFor="mssItemsCountFull" style={{ marginRight: '8px', fontWeight: 'bold', fontSize: '16px' }}>
                Items Count: 
              </label>
              <input
                type="number"
                id="mssItemsCountFull"
                min="100"
                max="10000"
                step="100"
                value={mssItemsCount}
                onChange={(e) => setMssItemsCount(parseInt(e.target.value) || 2000)}
                style={{
                  width: '100px',
                  padding: '8px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  textAlign: 'center',
                  fontSize: '16px'
                }}
              />
            </div>
          </div>

          {/* Chart Container */}
          <div style={{
            flex: 1,
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            position: 'relative'
          }}>
            <canvas ref={chartRefs.mssFullScreen}></canvas>
          </div>

          {/* Footer Info */}
          <div style={{
            color: 'white',
            textAlign: 'center',
            marginTop: '10px',
            fontSize: '14px'
          }}>
            Showing {moonSeriesTableData.length} data points | Series: {moonSeriesLength} | Items: {mssItemsCount}
          </div>
        </div>
      )}

      {/* Full Screen SbTrend Modal */}
      {isSbTrendFullScreen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          backgroundColor: 'rgba(0, 0, 0, 0.9)',
          zIndex: 1000,
          display: 'flex',
          flexDirection: 'column',
          padding: '20px'
        }}>
          {/* Header */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px',
            color: 'white'
          }}>
            <h2 style={{ margin: 0, color: 'white' }}>
              SbTrend - Full Screen View
            </h2>
            <button
              onClick={handleSbTrendCloseFullScreen}
              style={{
                padding: '10px 20px',
                backgroundColor: '#ff4444',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: 'bold'
              }}
            >
              Close (ESC)
            </button>
          </div>

          {/* Controls */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: '20px',
            marginBottom: '20px',
            color: 'white'
          }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <label htmlFor="sbTrendItemsCountFull" style={{ marginRight: '8px', fontWeight: 'bold', fontSize: '16px' }}>
                Items Count: 
              </label>
              <input
                type="number"
                id="sbTrendItemsCountFull"
                min="50"
                max="1000"
                step="25"
                value={sbTrendItemsCount}
                onChange={(e) => setSbTrendItemsCount(parseInt(e.target.value) || 125)}
                style={{
                  width: '100px',
                  padding: '8px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  textAlign: 'center',
                  fontSize: '16px'
                }}
              />
            </div>
          </div>

          {/* Chart Container */}
          <div style={{
            flex: 1,
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            position: 'relative'
          }}>
            <canvas ref={chartRefs.sbTrendFullScreen}></canvas>
          </div>

          {/* Footer Info */}
          <div style={{
            color: 'white',
            textAlign: 'center',
            marginTop: '10px',
            fontSize: '14px'
          }}>
            Showing {sbTrendItemsCount} data points
          </div>
        </div>
      )}

    {moonNextPairs.length > 0 && (
      <MoonPairBotPanel 
        betSignal={betSignal} 
        mainBot={mainBot}
        lastGeneratedBust={lastGeneratedBust}
        botStats={botStats}
      />
    )}
    {moonSeriesTableData.length > 0 && (
      <MoonTouchBotPanel 
        moonSeriesTableData={moonSeriesTableData}
        gameIdDifferences={gameIdDifferences} 
        mainBot={mainBot}
        lastGeneratedBust={lastGeneratedBust}
        botStats={botStats}
      />
    )}
    { <RedThreeBotPanel 
        gameResults={gameResults}
        mainBot={mainBot}
        lastGeneratedBust={lastGeneratedBust}
        botStats={botStats}
      />
    }
    { <RedBadBotPanel 
        gameResults={gameResults}
        mainBot={mainBot}
        lastGeneratedBust={lastGeneratedBust}
        botStats={botStats}
      />
    }
    { <SwingBotPanel 
        SbTrendResults128 ={SbTrendResults128}
        mainBot={mainBot}
        lastGeneratedBust={lastGeneratedBust}
        botStats={botStats}
        swingLengh = {swingLength}
      />      
    }
    { <FourVBotPanel  
        gameResults={gameResults}      
        mainBot={mainBot}
        lastGeneratedBust={lastGeneratedBust}
        botStats={botStats}   
      />      
    }
    <FloatingChecklistButton />
    </>
  );
}

// Helper functions
function moonSumSeries(startKey, differencesObj, seriesLength = 6) {
  const keys = Object.keys(differencesObj).map(Number);
  const startIndex = keys.indexOf(Number(startKey));
  
  if (startIndex === -1) return null;

  let sum = 0;
  for (let i = startIndex; i < startIndex + seriesLength && i < keys.length; i++) {
    const value = differencesObj[keys[i]];
    if (value != null) sum += value;
  }
  
  return sum;
}

function calculateExclusiveSum(gameIdDifferences) {
  if (!gameIdDifferences || Object.keys(gameIdDifferences).length === 0) return 0;
  
  const exclusiveKeys = Object.keys(gameIdDifferences)
    .filter((_, index) => [0, 6, 12, 18, 24, 30, 36, 42, 48, 54].includes(index));
  
  let exclusiveSum = 0;
  exclusiveKeys.forEach(key => {
    const sum = moonSumSeries(key, gameIdDifferences, 6); // Always use series length 6
    if (sum !== null) {
      exclusiveSum += sum;
    }
  });
  
  return exclusiveSum;
}

function calculateSixPacksOf60(gameIdDifferences) {
  if (!gameIdDifferences || Object.keys(gameIdDifferences).length === 0) {
    return [0, 0, 0, 0, 0, 0];
  }
  
  const keys = Object.keys(gameIdDifferences).map(Number).sort((a, b) => a - b);
  const packs = [];
  
  // Calculate 6 packs based on array indices: 0-59, 1-60, 2-61, 3-62, 4-63, 5-65
  const packRanges = [
    { startIdx: 0, endIdx: 59 },   // Pack 1: indices 0 to 59 (60 items)
    { startIdx: 1, endIdx: 60 },   // Pack 2: indices 1 to 60 (60 items)
    { startIdx: 2, endIdx: 61 },   // Pack 3: indices 2 to 61 (60 items)
    { startIdx: 3, endIdx: 62 },   // Pack 4: indices 3 to 62 (60 items)
    { startIdx: 4, endIdx: 63 },   // Pack 5: indices 4 to 63 (60 items)
    { startIdx: 5, endIdx: 65 }    // Pack 6: indices 5 to 65 (61 items)
  ];
  
  packRanges.forEach(({ startIdx, endIdx }) => {
    let sum = 0;
    for (let i = startIdx; i <= endIdx && i < keys.length; i++) {
      const key = keys[i];
      const value = gameIdDifferences[key];
      if (value != null) {
        sum += value;
      }
    }
    packs.push(sum);
  });
  
  return packs;
}



// Chart options and data configs
const sbTrendChartOptions = {
  responsive: true,
  plugins: {
    datalabels: { display: false },
    legend: { labels: { color: 'blue' }, display: true },
    tooltip: { 
      backgroundColor: 'lightgray',
      bodyColor: 'black',
      titleColor: 'red',
      mode: 'index', 
      intersect: false 
    },
  },
  scales: {
    x: { borderColor: 'black', borderWidth: 4 },
    y: { beginAtZero: true },
  },
};

const mainChartOptions = {
  responsive: true,
  plugins: { legend: { display: false }, datalabels: { display: false } },
  scales: {
    x: { ticks: { padding: 20 } },
    y: { type: 'logarithmic', min: 1, max: 150 }
  },
};

const moonSeriesChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    datalabels: { display: false },
    tooltip: { 
      mode: 'index', 
      intersect: false,
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      titleColor: '#fff',
      bodyColor: '#fff',
      borderColor: '#007bff',
      borderWidth: 1,
      cornerRadius: 8,
      displayColors: false
    },
  },
  scales: { 
    x: {
      grid: {
        color: 'rgba(0, 0, 0, 0.1)',
        borderColor: 'rgba(0, 0, 0, 0.2)'
      },
      ticks: {
        color: '#666',
        font: {
          size: 11
        }
      }
    },
    y: { 
      beginAtZero: true,
      grid: {
        color: 'rgba(0, 0, 0, 0.1)',
        borderColor: 'rgba(0, 0, 0, 0.2)'
      },
      ticks: {
        color: '#666',
        font: {
          size: 11
        }
      }
    } 
  },
  elements: {
    line: {
      tension: 0.4,
      borderWidth: 2
    },
    point: {
      radius: 2, // Smaller default radius
      hoverRadius: 5, // Reduced hover radius
      hoverBackgroundColor: '#ff0000',
      hoverBorderColor: '#ff0000',
      hoverBorderWidth: 1 // Thinner border on hover
    }
  },
  interaction: {
    mode: 'index',
    intersect: false
  },
  hover: {
    mode: 'index',
    intersect: false
  }
};

function mainChartData(data) {
  const pointColors = data.map(bust => {
    if (bust >= 10) return 'orange';
    if (bust >= 4 && bust < 10) return 'brown';
    if (bust < 2) return 'red';
    return 'green';
  });

  return {
    labels: data.map((_, idx) => `${idx + 1}`),
    datasets: [{
      data,
      fill: false,
      borderColor: '#4CAF50',
      backgroundColor: '#81C784',
      tension: 0.4,
      pointBackgroundColor: pointColors,
    }],
  };
}

function moonSeriesChartData(tableData, seriesLength, itemsCount) {
  const reversedData = [...tableData].reverse();
  const labels = reversedData.map(item => item.key);
  const dataPoints = reversedData.map(item => item.sum !== null ? item.sum : 0);

  // Create point background colors array - last point will be red, others default
  const pointBackgroundColors = dataPoints.map((_, index) => 
    index === dataPoints.length - 1 ? '#ff0000' : 'rgba(55, 12, 82, 1)' // Pure red for last point
  );

  // Create point border colors array - last point will have red border, others default
  const pointBorderColors = dataPoints.map((_, index) => 
    index === dataPoints.length - 1 ? '#ff0000' : 'rgba(75, 192, 192, 1)'
  );

  // Create point radii array - last point slightly smaller and consistent
  const pointRadii = dataPoints.map((_, index) => 
    index === dataPoints.length - 1 ? 3 : 2 // Smaller radius for all points
  );

  // Create point border widths - last point has thinner border
  const pointBorderWidths = dataPoints.map((_, index) => 
    index === dataPoints.length - 1 ? 1 : 1 // Consistent border width
  );

  return {
    labels,
    datasets: [{
      label: `Sum of ${seriesLength}-Series (${itemsCount} items)`,
      data: dataPoints,
      fill: false,
      borderColor: 'rgba(75, 192, 192, 1)',
      backgroundColor: 'rgba(75, 192, 192, 0.4)',
      tension: 0.4,
      pointRadius: pointRadii,
      pointBackgroundColor: pointBackgroundColors,
      pointBorderColor: pointBorderColors,
      pointBorderWidth: pointBorderWidths,
      pointHoverRadius: 6, // Slightly larger on hover but not too big
      pointHoverBackgroundColor: '#ff0000',
      pointHoverBorderColor: '#ff0000',
      pointHoverBorderWidth: 2
    }],
  };
}
// Custom hooks
function useChartEffect({ chartRef, instanceRef, data, options, dependencies }) {
  useEffect(() => {
    if (!chartRef.current) return;

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    if (instanceRef.current) {
      instanceRef.current.destroy();
    }

    instanceRef.current = new Chart(ctx, {
      type: 'line',
      data,
      options,
    });
  }, dependencies);
}

function useNextValuesChart({ chartRef, instanceRef, initial6154ResultsReversed, lastGeneratedBust, dependencies }) {
  useEffect(() => {
    const series = getNextValuesAfterLastBust(initial6154ResultsReversed, lastGeneratedBust);

    if (series.length === 0) {
      if (instanceRef.current) {
        instanceRef.current.destroy();
        instanceRef.current = null;
      }
      return;
    }

    if (chartRef.current) {
      const ctx = chartRef.current.getContext('2d');

      if (instanceRef.current) {
        instanceRef.current.destroy();
      }

      const maxItems = 30;
      const limitedSeries = series.length > maxItems ? series.slice(0, maxItems) : series;

      instanceRef.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels: limitedSeries.map((_, idx) => ` ${idx + 1}`),
          datasets: [{
            label: 'VFB',
            data: limitedSeries,
            fill: false,
            borderColor: 'blue',
            backgroundColor: 'lightblue',
            tension: 0.4,
            pointRadius: 4,
            datalabels: {
              display: true,
              align: 'start',
              anchor: 'end',
              color: (context) => context.dataset.data[context.dataIndex] > 2 ? 'green' : 'red',
              font: { size: 16, weight: 'bold' },
              padding: { right: 10 },
              formatter: (value) => value.toFixed(1),
            },
          }],
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false }, datalabels: { display: true } },
          scales: { y: { type: 'logarithmic', min: 1 } },
        },
      });
    }
  }, dependencies);
}

function getNextValuesAfterLastBust(initial6154ResultsReversed, lastGeneratedBust) {
  if (initial6154ResultsReversed.length === 0 || lastGeneratedBust === null) return [];

  const series = [];
  for (let i = 0; i < initial6154ResultsReversed.length - 1; i++) {
    if (initial6154ResultsReversed[i] === lastGeneratedBust && i + 1 < initial6154ResultsReversed.length) {
      series.push(initial6154ResultsReversed[i + 1]);
    }
  }
  return series;
}

// Conditional Header Component - only shows when not on bot-control page
function ConditionalHeader({ lastGeneratedBust, moonPercentResult, gameIdDifferences, gameResults }) {
  const location = useLocation();
  
  // Debug: log the current pathname
  useEffect(() => {
    console.log('Current pathname:', location.pathname);
  }, [location.pathname]);
  
  // Don't show header on bot-control page
  if (location.pathname === '/bot-control' || location.pathname.includes('/bot-control')) {
    return null;
  }
  
  return (
    <HeaderSection 
      lastGeneratedBust={lastGeneratedBust}
      moonPercentResult={moonPercentResult}
      gameIdDifferences={gameIdDifferences}
      gameResults={gameResults}
    />
  );
}

// Component sections
function MainContent({
  gameData,
  gameAmount,
  onGameAmountChange,
  moonSeriesTableData,
  moonSeriesTableData2,
  gameIdDifferences,
  gameIdDifferences2, 
  lastGeneratedBust,
  onLastBustChange,
  chartRefs,
  moonNextPairs,
  onTrenballClick,
  gameResults,
  moonSeriesLength,
  onMoonSeriesLengthChange,
  moonSeriesLength2,
  onMoonSeriesLength2Change,
  mssItemsCount,
  onMssItemsCountChange,
  mssItemsCount2,
  onMssItemsCount2Change,
  onMssExtend,
  sbTrendItemsCount,
  onSbTrendItemsCountChange,
  onSbTrendExtend,
  sixPacksOf60,
  packTrend
}) {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', width: '100%', maxWidth: '100vw', overflowX: 'hidden' }}>
      {/* Top row: SbTrend, BVH and Classic View charts - 3 graphs side by side */}
      <div style={{
        display: 'flex',
        flexDirection: 'row',
        padding: '10px',
        gap: '10px',
        width: '100%',
        marginTop: '40px',
        boxSizing: 'border-box'
      }}>
        {/* SbTrend Chart - 1/3 width */}
        <div style={{ 
          flex: '1 1 33.333%',
          minWidth: 0, // Prevents flex items from overflowing
          boxSizing: 'border-box'
        }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between', 
            marginBottom: '10px',
            padding: '0 5px'
          }}>
            <h3 style={{ margin: 0, fontSize: '16px' }}>SbTrend</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <button
                onClick={onSbTrendExtend}
                style={{
                  padding: '4px 8px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '11px',
                  fontWeight: 'bold',
                  whiteSpace: 'nowrap'
                }}
                title="Expand to full screen"
              >
                Extend
              </button>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <label htmlFor="sbTrendItemsCount" style={{ marginRight: '4px', fontWeight: 'bold', fontSize: '12px', whiteSpace: 'nowrap' }}>
                  Items: 
                </label>
                <input
                  type="number"
                  id="sbTrendItemsCount"
                  min="50"
                  max="1000"
                  step="25"
                  value={sbTrendItemsCount}
                  onChange={(e) => onSbTrendItemsCountChange(parseInt(e.target.value) || 125)}
                  style={{
                    width: '60px',
                    padding: '2px 4px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    textAlign: 'center',
                    fontSize: '12px'
                  }}
                />
              </div>
            </div>
          </div>
          <div style={{ 
            width: '100%',
            height: '350px',
            border: '1px solid #ddd',        
            borderRadius: '8px',          
            backgroundColor: 'white',
            boxSizing: 'border-box'
          }}>
            <canvas ref={chartRefs.sbTrendResults}></canvas>
          </div>
        </div>

        {/* BVH Chart - 1/3 width */}
        <div style={{ 
          flex: '1 1 33.333%',
          minWidth: 0,
          boxSizing: 'border-box'
        }}>
          <h3 style={{ marginBottom: '10px', fontSize: '16px', padding: '0 5px' }}>BVH</h3>
          <div style={{ 
            width: '100%',
            height: '350px',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '10px',
            backgroundColor: 'white',
            boxSizing: 'border-box'
          }}>
            <canvas ref={chartRefs.nextValues}></canvas>
            <LastBustInput value={lastGeneratedBust} onChange={onLastBustChange} />
          </div>
        </div>

        {/* Classic View Chart - 1/3 width */}
        <div style={{ 
          flex: '1 1 33.333%',
          minWidth: 0,
          boxSizing: 'border-box'
        }}>
          <h3 style={{ marginBottom: '10px', fontSize: '16px', padding: '0 5px' }}>Classic View</h3>
          <div style={{ 
            width: '100%', 
            height: '350px',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '5px',
            backgroundColor: 'white',
            position: 'relative',
            boxSizing: 'border-box'
          }}>
            <canvas ref={chartRefs.mainChart}></canvas>
          </div>
        </div>
      </div>
     
      {/* Middle row: Two MSS charts side by side */}
      <div style={{
        display: 'flex',
        flexDirection: 'row',        
        padding: '10px',
        width: '100%',        
        marginTop: '20px',
        gap: '10px',
        boxSizing: 'border-box'
      }}>
        {/* MSS Chart 1 (Series 6) */}
        <div style={{ 
          flex: '1 1 50%',
          minWidth: 0,
          height: '500px',
          boxSizing: 'border-box'
        }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between', 
            marginBottom: '10px',
            flexWrap: 'wrap',
            gap: '10px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <h3 style={{ margin: 0, fontSize: '16px' }}>MSS (Series 6)</h3>
              <button
                onClick={onMssExtend}
                style={{
                  padding: '4px 8px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '11px',
                  fontWeight: 'bold'
                }}
                title="Expand to full screen"
              >
                Extend
              </button>
            </div>
            
            {/* Controls Container */}
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '10px',
              flexWrap: 'wrap'
            }}>
              {/* Exclusive Number Display */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center',
                backgroundColor: '#f8f9fa',
                padding: '4px 8px',
                borderRadius: '4px',
                border: '1px solid #dee2e6'
              }}>
                <span style={{ 
                  fontWeight: 'bold', 
                  fontSize: '12px', 
                  marginRight: '4px',
                  color: '#495057'
                }}>
                  Exclusive:
                </span>
                <span style={{ 
                  fontWeight: 'bold', 
                  fontSize: '12px',
                  color: '#e83e8c'
                }}>
                  {calculateExclusiveSum(gameIdDifferences)}
                </span>
              </div>
              
              {/* Moon Series Length Input */}
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <label htmlFor="moonSeriesLength" style={{ marginRight: '4px', fontWeight: 'bold', fontSize: '12px', whiteSpace: 'nowrap' }}>
                  Series: 
                </label>
                <input
                  type="number"
                  id="moonSeriesLength"
                  min="1"
                  max="20"
                  value={moonSeriesLength}
                  onChange={(e) => onMoonSeriesLengthChange(parseInt(e.target.value) || 6)}
                  style={{
                    width: '50px',
                    padding: '2px 4px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    textAlign: 'center',
                    fontSize: '12px'
                  }}
                />
              </div>
              
              {/* MSS Items Count Input */}
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <label htmlFor="mssItemsCount" style={{ marginRight: '4px', fontWeight: 'bold', fontSize: '12px', whiteSpace: 'nowrap' }}>
                  Items: 
                </label>
                <input
                  type="number"
                  id="mssItemsCount"
                  min="100"
                  max="10000"
                  step="100"
                  value={mssItemsCount}
                  onChange={(e) => onMssItemsCountChange(parseInt(e.target.value) || 2000)}
                  style={{
                    width: '70px',
                    padding: '2px 4px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    textAlign: 'center',
                    fontSize: '12px'
                  }}
                />
              </div>
            </div>
          </div>
          
          <div style={{ 
            width: '100%', 
            height: '400px',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '10px',
            backgroundColor: 'white',
            boxSizing: 'border-box'
          }}>
            <canvas ref={chartRefs.moonSeries}></canvas>
          </div>
          
          <div style={{ fontSize: '11px', color: '#666', marginTop: '5px', textAlign: 'center' }}>
            Showing {moonSeriesTableData.length} data points | Series: {moonSeriesLength} | Items: {mssItemsCount} | Exclusive: {calculateExclusiveSum(gameIdDifferences)}
          </div>
        </div>

        {/* MSS Chart 2 (Series 60) */}
        <div style={{ 
          flex: '1 1 50%',
          minWidth: 0,
          height: '500px',
          boxSizing: 'border-box'
        }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between', 
            marginBottom: '10px',
            flexWrap: 'wrap',
            gap: '10px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
              <h3 style={{ margin: 0, fontSize: '16px' }}>MSS (Series 60)</h3>
              <button
                onClick={onMssExtend}
                style={{
                  padding: '4px 8px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '11px',
                  fontWeight: 'bold'
                }}
                title="Expand to full screen"
              >
                Extend
              </button>
              
              {/* 6 Packs of 60 Display */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '4px',
                flexWrap: 'wrap',
                marginLeft: '10px'
              }}>
                {sixPacksOf60.slice().reverse().map((sum, reversedIndex) => {
                  const originalIndex = sixPacksOf60.length - 1 - reversedIndex;
                  const packRanges = [
                    { start: 0, end: 59 },
                    { start: 1, end: 60 },
                    { start: 2, end: 61 },
                    { start: 3, end: 62 },
                    { start: 4, end: 63 },
                    { start: 5, end: 65 }
                  ];
                  const range = packRanges[originalIndex];
                  const reversedArray = sixPacksOf60.slice().reverse();
                  const isLast = reversedIndex === reversedArray.length - 1;
                  const nextValue = !isLast ? reversedArray[reversedIndex + 1] : null;
                  const showArrow = !isLast && nextValue !== null;
                  const arrowDirection = showArrow ? (sum > nextValue ? '↓' : '↑') : '';
                  const arrowColor = showArrow ? (sum > nextValue ? '#dc3545' : '#28a745') : '';
                  
                  return (
                    <React.Fragment key={originalIndex}>
                      <div
                        style={{
                          padding: '4px 8px',
                          backgroundColor: '#f8f9fa',
                          border: '1px solid #dee2e6',
                          borderRadius: '4px',
                          fontSize: '11px',
                          fontWeight: 'bold',
                          color: '#495057',
                          minWidth: '45px',
                          textAlign: 'center'
                        }}
                        title={`Pack ${originalIndex + 1}: ${range.start} to ${range.end}`}
                      >
                        {sum}
                      </div>
                      {showArrow && (
                        <div
                          style={{
                            fontSize: '14px',
                            fontWeight: 'bold',
                            color: arrowColor,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: '20px'
                          }}
                          title={sum > nextValue ? 'Down' : 'Up'}
                        >
                          {arrowDirection}
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
                
                {/* Trend Status */}
                <div
                  style={{
                    padding: '4px 10px',
                    backgroundColor: packTrend === 'UP' ? '#d4edda' : packTrend === 'DOWN' ? '#f8d7da' : '#e2e3e5',
                    border: `1px solid ${packTrend === 'UP' ? '#c3e6cb' : packTrend === 'DOWN' ? '#f5c6cb' : '#d6d8db'}`,
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: 'bold',
                    color: packTrend === 'UP' ? '#155724' : packTrend === 'DOWN' ? '#721c24' : '#383d41',
                    marginLeft: '8px'
                  }}
                  title={`Trend: ${packTrend}`}
                >
                  {packTrend}
                </div>
              </div>
            </div>
            
            {/* Controls Container */}
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '10px',
              flexWrap: 'wrap'
            }}>
              {/* Moon Series Length Input for Series 60 */}
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <label htmlFor="moonSeriesLength2" style={{ marginRight: '4px', fontWeight: 'bold', fontSize: '12px', whiteSpace: 'nowrap' }}>
                  Series: 
                </label>
                <input
                  type="number"
                  id="moonSeriesLength2"
                  min="1"
                  max="100"
                  value={moonSeriesLength2}
                  onChange={(e) => onMoonSeriesLength2Change(parseInt(e.target.value) || 60)}
                  style={{
                    width: '50px',
                    padding: '2px 4px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    textAlign: 'center',
                    fontSize: '12px'
                  }}
                />
              </div>

              {/* MSS Items Count Input for Series 60 */}
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <label htmlFor="mssItemsCount2" style={{ marginRight: '4px', fontWeight: 'bold', fontSize: '12px', whiteSpace: 'nowrap' }}>
                  Items: 
                </label>
                <input
                  type="number"
                  id="mssItemsCount2"
                  min="100"
                  max="10000"
                  step="100"
                  value={mssItemsCount2}
                  onChange={(e) => onMssItemsCount2Change(parseInt(e.target.value) || 6000)}
                  style={{
                    width: '70px',
                    padding: '2px 4px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    textAlign: 'center',
                    fontSize: '12px'
                  }}
                />
              </div>
            </div>
          </div>
  
          <div style={{ 
            width: '100%', 
            height: '400px',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '10px',
            backgroundColor: 'white',
            boxSizing: 'border-box'
          }}>
            <canvas ref={chartRefs.moonSeries2}></canvas>
          </div>
  
          <div style={{ fontSize: '11px', color: '#666', marginTop: '5px', textAlign: 'center' }}>
            Showing {moonSeriesTableData2.length} data points | Series: {moonSeriesLength2} | Items: {mssItemsCount2}
          </div>
        </div>
      </div>

      <AdditionalContent
        lastGeneratedBust={lastGeneratedBust}
        onLastBustChange={onLastBustChange}
        gameIdDifferences={gameIdDifferences}
        moonNextPairs={moonNextPairs}
      />

      <ResearchSectionThreeReds gameResults={gameResults} />
      <ResearchSectionBadReds gameResults={gameResults} 
      badRedSequencesPanelLength = {badRedSequencesPanelLength} />
      <ResearchSectionNeutralReds  gameResults={gameResults} />
    </div>
  );
}

// ... (rest of the components remain the same - GameAmountInput, GameDataSections, GameDifferences, AdditionalContent, LastBustInput, GameDifferencesGrid, MoonPercentResult, MoonNextPairsSection)

function GameAmountInput({ value, onChange }) {
  return (
    <div style={{ marginBottom: '20px' }}>
      <label htmlFor="gameAmountInput">Amount of Games: </label>
      <input
        type="number"
        id="gameAmountInput"
        min={1}
        max={10000}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value, 10))}
        style={{ width: '80px', marginLeft: '10px' }}
      />
    </div>
  );
}

function GameDataSections({ moonSeriesTableData, gameIdDifferences }) {
  return (
    <div>      
      <GameDifferences differences={gameIdDifferences} />
    </div>
  );
}

function GameDifferences({ differences }) {
  const [isCollapsed, setIsCollapsed] = useState(true);

  return (
    <>
      <div 
        style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '10px', 
          cursor: 'pointer',
          padding: '12px 16px',
          backgroundColor: isCollapsed ? '#e9ecef' : '#007bff',
          color: isCollapsed ? '#495057' : 'white',
          borderRadius: '8px',
          border: `2px solid ${isCollapsed ? '#dee2e6' : '#0056b3'}`,
          transition: 'all 0.3s ease',
          marginBottom: isCollapsed ? '0' : '10px'
        }}
        onClick={() => setIsCollapsed(!isCollapsed)}
      >
        <span style={{ 
          transform: isCollapsed ? 'rotate(0deg)' : 'rotate(90deg)', 
          transition: 'transform 0.3s ease',
          fontSize: '14px'
        }}>
          ▶
        </span>
        <h3 style={{ margin: 0, fontSize: '16px' }}>Moon Id Diff </h3>
        <span style={{ 
          fontSize: '12px', 
          backgroundColor: isCollapsed ? '#6c757d' : 'rgba(255,255,255,0.2)',
          color: isCollapsed ? 'white' : 'white',
          padding: '2px 8px',
          borderRadius: '12px',
          marginLeft: 'auto'
        }}>
          {Object.keys(differences).length} items
        </span>
      </div>
      
      {!isCollapsed && (
        <div style={{
          maxHeight: '200px',
          overflow: 'auto',
          transition: 'all 0.3s ease',
          border: '1px solid #dee2e6',
          borderRadius: '4px'
        }}>
          <pre style={{ 
            background: '#f8f9fa', 
            padding: '15px', 
            margin: 0,
            fontSize: '12px'
          }}>
            {JSON.stringify(differences, null, 2)}
          </pre>
        </div>
      )}
    </>
  );
}

function AdditionalContent({
  lastGeneratedBust,
  onLastBustChange,
  gameIdDifferences,
  moonNextPairs
}) {
  return (
    <div style={{
      marginTop: '30px',
      position: 'relative',
      width: '100%',
      background: '#e0e0e0',
      borderRadius: '12px',
      boxShadow: '0 0 24px rgba(0,0,0,0.25)',
      padding: '10px',
    }}>
      <div style={{
        display: 'flex',
        flexDirection: 'row',
        padding: '20px',
        gap: '20px'
      }}>
        <div style={{ width: '50%' }}>
          <MoonNextPairsSection pairs={moonNextPairs} />
        </div>
        
        <div style={{ width: '50%' }}>
          <GameDifferencesGrid differences={gameIdDifferences} />
        </div>
      </div>
    </div>
  );
}

function LastBustInput({ value, onChange }) {
  return (
    <div style={{ marginTop: '20px' }}>
      <label>Bust Value History BVH:</label>
      <input
        type="number"
        step="any"
        value={value !== null ? value : ''}
        onChange={(e) => {
          const val = e.target.value.trim();
          const numVal = parseFloat(val);
          onChange(!isNaN(numVal) ? numVal : null);
        }}
        style={{ width: '200px', padding: '4px', marginLeft: '10px' }}
      />
    </div>
  );
}

function GameDifferencesGrid({ differences }) {
  return (
    <div style={{ maxWidth: '100%', marginTop: '10px' }}>
      {/* MID Label with icon */}
      <div style={{
        display: 'flex',   
        alignItems: 'left',
        justifyContent: 'left',
        gap: '8px',
        fontWeight: 'bold',
        fontSize: '18px',
        color: '#2c3e50',
        marginBottom: '12px',
        padding: '8px 16px',
        backgroundColor: '#f8f9fa',
        border: '2px solid #dee2e6',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <span>📊</span>
        <span>MID </span>
      </div>
      
      {/* Grid */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
        {Object.entries(differences).map(([gameId, diff]) => (
          <div
            key={gameId}
            style={{
              padding: '4px 8px',
              backgroundColor: diff > 10 ? 'orange' : '#f0f0f0',
              borderRadius: '4px',
              border: '1px solid #ccc',
              fontWeight: diff > 10 ? 'bold' : 'normal',
            }}
          >
            {diff}
          </div>
        ))}
      </div>
    </div>
  );
}

function MoonPercentResult({ results }) {
  return (
    <p>
      {results.map(res => `${res.total}: ${res.percentageOver10}  `).join(' | ')}
    </p>
  );
}

function MoonNextPairsSection({ pairs }) {
  const containerRef = useRef(null);

  // Scroll to bottom when pairs update
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [pairs]);

  return (
    <div style={{ marginTop: '10px' }}>
      {/* MID Label with icon */}
      <div style={{
        display: 'flex',   
        alignItems: 'left',
        justifyContent: 'left',
        gap: '8px',
        fontWeight: 'bold',
        fontSize: '18px',
        color: '#2c3e50',
        marginBottom: '12px',
        padding: '8px 16px',
        backgroundColor: '#f8f9fa',
        border: '2px solid #dee2e6',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <span>📊</span>
        <span>MNP </span>
      </div>      
      <div 
        ref={containerRef}
        style={{ 
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(70px, 1fr))',
          gap: '8px',
          maxWidth: '100%',
          maxHeight: '200px',
          overflowY: 'auto',
          padding: '10px',
          border: '1px solid #ccc',
          borderRadius: '8px',
          backgroundColor: '#f8f9fa'
        }}
      >
        {pairs.map((value, index) => (
          <div
            key={index}
            style={{
              padding: '8px 6px',
              backgroundColor: value > 2 ? '#28a745' : '#dc3545',
              color: 'white',
              borderRadius: '4px',
              fontWeight: 'bold',
              fontSize: '12px',
              textAlign: 'center'
            }}
          >
            {value.toFixed(2)}
          </div>
        ))}
      </div>
      <div style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
        Total: {pairs.length} pairs
      </div>
    </div>
  );
}

export default App;