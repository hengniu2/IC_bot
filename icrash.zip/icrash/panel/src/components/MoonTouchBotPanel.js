// components/MoonTouchBotPanel.js
import React, { useState, useMemo, useRef, useEffect } from 'react';
import EmailService from './EmailService';

function MoonTouchBotPanel({ moonSeriesTableData, gameIdDifferences, mainBot, lastGeneratedBust, botStats }) {
  const [isMinimized, setIsMinimized] = useState(true);
  const [resetTrigger, setResetTrigger] = useState(0);
  const [lastActiveStatus, setLastActiveStatus] = useState(false);
  const [isBotActive, setIsBotActive] = useState(true);

  // Calculate moon series data with fixed length 6 for the bot
  const moonSeriesTableDataFixed6 = useMemo(() => {
    if (!gameIdDifferences || Object.keys(gameIdDifferences).length === 0) {
      return moonSeriesTableData || []; // Fallback to the original data
    }

    // Recalculate moon series with fixed length 6
    return Object.keys(gameIdDifferences).map((key) => ({
      key,
      sum: moonSumSeriesFixed6(key, gameIdDifferences),
    }));
  }, [gameIdDifferences, moonSeriesTableData, resetTrigger]);

  // Calculate bot signal based on fixed series length 6 data
  const calculateMoonTouchSignal = () => {
    // If bot is manually reset to inactive, return inactive signal
    if (!isBotActive) {
      return { 
        status: 'Inactive', 
        amount: 0, 
        reason: 'Bot manually reset' 
      };
    }

    const dataToUse = moonSeriesTableDataFixed6.length > 0 ? moonSeriesTableDataFixed6 : moonSeriesTableData;
    
    if (!dataToUse || dataToUse.length < 2) {
      return { 
        status: 'Inactive', 
        amount: 0, 
        reason: 'Insufficient moon series data' 
      };
    }

    const lastItem = dataToUse[0];
    const secondLastItem = dataToUse[1];
    
    // Fixed exclusive item calculation - always use indices for series length 6
    const exclusiveItem = dataToUse
      .filter((_, index) => [0, 6, 12, 18, 24, 30, 36, 42, 48, 54].includes(index))
      .reduce((sum, item) => sum + (item?.sum || 0), 0);



    // Check if both last and second last are less than 40
    if (lastItem.sum < 40 && secondLastItem.sum < 40) {
      const betAmount = 10; // Base bet amount
      return {
        status: 'Active',
        amount: betAmount,
        reason: `Moon series pattern detected (${secondLastItem.sum}, ${lastItem.sum})`,
        data: {
          lastSum: lastItem.sum,
          secondLastSum: secondLastItem.sum, // FIXED: Changed secondItem to secondLastItem
          lastKey: lastItem.key,
          secondLastKey: secondLastItem.key, // FIXED: Changed secondItem to secondLastItem
          exclusiveSum: exclusiveItem,
          seriesLength: 6 // Indicate fixed series length
        }
      };
    }
    
    // Fixed exclusive item condition (checking if out of range)
    if (exclusiveItem < 500) {
      const betAmount = 10; // Base bet amount
      return {
        status: 'Active',
        amount: betAmount,
        reason: `Exclusive Moon series pattern detected (${exclusiveItem})`,
        data: {
          lastSum: lastItem.sum,
          secondLastSum: secondLastItem.sum,
          exclusiveSum: exclusiveItem,
          lastKey: lastItem.key,
          secondLastKey: secondLastItem.key,
          seriesLength: 6 // Indicate fixed series length
        }
      };
    } 

    return {
      status: 'Inactive',
      amount: 0,
      reason: `No pattern (${secondLastItem.sum}, ${lastItem.sum}, Exclusive: ${exclusiveItem})`
    };
  };

  const moonTouchSignal = calculateMoonTouchSignal();

  // Track status changes for email service
  useEffect(() => {
    const currentIsActive = moonTouchSignal.status === 'Active';
    
    // Only update lastActiveStatus if there's an actual change
    if (currentIsActive !== lastActiveStatus) {
      setLastActiveStatus(currentIsActive);
    }
  }, [moonTouchSignal.status, lastActiveStatus]);

  const executeMoonTouchBet = () => {
    if (mainBot && moonTouchSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(moonTouchSignal.amount, lastGeneratedBust, 2.0);
      console.log('MoonTouch bot bet executed:', result);
    }
  };

  const resetBot = () => {
    setIsBotActive(false);
    setResetTrigger(prev => prev + 1);
    setLastActiveStatus(false);
    console.log('MoonTouch bot reset and deactivated');
  };

  const activateBot = () => {
    setIsBotActive(true);
    console.log('MoonTouch bot activated');
  };

  // Helper function for fixed series length 6
  function moonSumSeriesFixed6(startKey, differencesObj) {
    const keys = Object.keys(differencesObj).map(Number);
    const startIndex = keys.indexOf(Number(startKey));
    
    if (startIndex === -1) return null;

    let sum = 0;
    for (let i = startIndex; i < startIndex + 6 && i < keys.length; i++) {
      const value = differencesObj[keys[i]];
      if (value != null) sum += value;
    }
    
    return sum;
  }

  return (
    <>
      {/* Email Service Component - Only trigger when status changes from inactive to active */}
      <EmailService 
        botStatus={moonTouchSignal?.status === 'Active' && lastActiveStatus === false ? 'Active' : 'Inactive'}
        botType="MoonTouch Bot"
      />

      {/* Rest of the JSX remains the same, just update the data display */}
      {(!moonSeriesTableDataFixed6 || moonSeriesTableDataFixed6.length === 0) ? (
        <div style={{
          position: 'fixed',
          top: '120px',
          right: '10px',
          background: '#f8f9fa',
          border: '2px solid #6c757d',
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>🌙🖐🏼MoonTouch Bot </h3>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                cursor: 'pointer',
                color: '#666'
              }}
            >
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>
            Waiting for moon series data...
          </div>
        </div>
      ) : isMinimized ? (
        // Minimized state - Updated title
        <div style={{
          position: 'fixed',
          top: '10px',
          right: '10px',
          background: moonTouchSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${moonTouchSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '10px 15px',
          zIndex: 1000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          cursor: 'pointer'
        }}
        onClick={() => setIsMinimized(false)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🌙🖐🏼</span>
            <span style={{ fontSize: '12px' }}>
              {moonTouchSignal.status === 'Active' ? `$${moonTouchSignal.amount}` : 'Inactive'}
            </span>
            <span style={{ 
              fontSize: '10px', 
              color: moonTouchSignal.status === 'Active' ? '#4CAF50' : '#666',
              fontWeight: 'bold'
            }}>
              {moonTouchSignal.status === 'Active' ? 'ACTIVE' : 'IDLE'}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer',
                color: '#666',
                marginLeft: 'auto'
              }}
            >
              +
            </button>
          </div>
        </div>
      ) : (
        // Expanded state - Updated to show it's using fixed series 6
        <div style={{
          position: 'fixed',
          top: '120px',
          right: '10px',
          background: moonTouchSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${moonTouchSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 2000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          maxHeight: '400px',
          overflow: 'auto'
        }}>
          {/* Header with reset and minimize buttons */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🌙 MoonTouch Bot (Series 6) 
              {!isBotActive && <span style={{ color: '#ff4444', fontSize: '12px', marginLeft: '8px' }}>[RESET]</span>}
            </h3>
            <div>
              {isBotActive ? (
                <button 
                  onClick={resetBot} 
                  style={{ 
                    background: '#ffc107', 
                    color: 'black', 
                    border: 'none', 
                    padding: '2px 6px', 
                    borderRadius: '3px', 
                    fontSize: '10px', 
                    marginRight: '5px', 
                    cursor: 'pointer' 
                  }} 
                  title="Reset and Deactivate Bot"
                >
                  Reset
                </button>
              ) : (
                <button 
                  onClick={activateBot} 
                  style={{ 
                    background: '#4CAF50', 
                    color: 'white', 
                    border: 'none', 
                    padding: '2px 6px', 
                    borderRadius: '3px', 
                    fontSize: '10px', 
                    marginRight: '5px', 
                    cursor: 'pointer' 
                  }} 
                  title="Activate Bot"
                >
                  Activate
                </button>
              )}
              <button
                onClick={() => setIsMinimized(true)}
                style={{
                  background: 'none',
                  border: 'none',
                  fontSize: '18px',
                  cursor: 'pointer',
                  color: '#666',
                  padding: '2px 8px',
                  borderRadius: '3px'
                }}
                title="Minimize"
              >
                −
              </button>
            </div>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {moonTouchSignal.status}</strong></div>
            <div>Bot State: <strong>{isBotActive ? 'ACTIVE' : 'RESET'}</strong></div>
            <div>Bet Amount: <strong>${moonTouchSignal.amount}</strong></div>
            <div>Reason: {moonTouchSignal.reason}</div>
            
            {moonTouchSignal.data && (
              <div style={{ marginTop: '8px', fontFamily: 'monospace', fontSize: '11px' }}>
                <div>Last: {moonTouchSignal.data.secondLastKey} = {moonTouchSignal.data.secondLastSum}</div>
                <div>Current: {moonTouchSignal.data.lastKey} = {moonTouchSignal.data.lastSum}</div>
                {moonTouchSignal.data.exclusiveSum && (
                  <div>Exclusive (Series 6): {moonTouchSignal.data.exclusiveSum}</div>
                )}
              </div>
            )}

            {moonTouchSignal.status === 'Active' && isBotActive && (
              <button 
                onClick={executeMoonTouchBet}
                style={{
                  background: '#4CAF50',
                  color: 'white',
                  border: 'none',
                  padding: '6px 12px',
                  borderRadius: '4px',
                  marginTop: '8px',
                  cursor: 'pointer',
                  fontSize: '12px'
                }}
              >
                Execute Bet ${moonTouchSignal.amount}
              </button>
            )}

            {!isBotActive && (
              <div style={{ 
                marginTop: '8px', 
                padding: '8px', 
                background: '#fff3cd', 
                border: '1px solid #ffeaa7',
                borderRadius: '4px',
                fontSize: '11px'
              }}>
                Bot is reset. Click "Activate" to enable betting.
              </div>
            )}
          </div>

          {/* Recent moon series data for reference */}
          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>Recent Moon Series (Fixed to Series 6):</strong></div>
            {moonSeriesTableDataFixed6.slice(0,4).map((item, index) => (
              <div key={index} style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Game {item.key}:</span>
                <span style={{ 
                  color: item.sum < 40 ? '#4CAF50' : '#f44336',
                  fontWeight: item.sum < 40 ? 'bold' : 'normal'
                }}>
                  {item.sum}
                </span>
              </div>
            ))}
          </div>

          {botStats && (
            <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export default MoonTouchBotPanel;