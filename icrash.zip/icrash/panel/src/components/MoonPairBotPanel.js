// components/BotPanel.js
import React, { useState } from 'react';
import EmailService from './EmailService';

function MoonPairBotPanel({ betSignal, mainBot, lastGeneratedBust, botStats }) {
  const [isMinimized, setIsMinimized] = useState(true);

  const executeBotBet = () => {
    if (mainBot && betSignal && betSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(betSignal.amount, lastGeneratedBust, 2.0);
      console.log('Bot bet executed:', result);
    }
  };

  // Add loading state
  if (!betSignal) {
    return (
      <div style={{
        position: 'fixed',
        top: '10px',
        right: '10px',
        background: '#f8f9fa',
        border: '2px solid #6c757d',
        borderRadius: '8px',
        padding: '15px',
        minWidth: '300px',
        zIndex: 1000,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
          <h3 style={{ margin: '0', fontSize: '16px' }}>🌙💤 MoonNextPairs Bot</h3>
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '16px',
              cursor: 'pointer',
              color: '#666'
            }}
          >
            −
          </button>
        </div>
        
        {/* Email Service Component */}
        <EmailService 
          botStatus={betSignal?.status}
          botType="MoonNextPairs Bot"
        />
        
        <div style={{ fontSize: '12px', color: '#666' }}>
          Initializing bot...
        </div>
      </div>
    );
  }

  // Minimized state
  if (isMinimized) {
    return (
      <div style={{
        position: 'fixed',
        top: '10px',
        right: '190px',
        background: betSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
        border: `2px solid ${betSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
        borderRadius: '8px',
        padding: '10px 15px',
        zIndex: 1000,
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        cursor: 'pointer'
      }}
      onClick={() => setIsMinimized(false)}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🌙💤</span>
          <span style={{ fontSize: '12px' }}>
            {betSignal.status === 'Active' ? `$${betSignal.amount}` : 'Inactive'}
          </span>
          <span style={{ 
            fontSize: '10px', 
            color: betSignal.status === 'Active' ? '#4CAF50' : '#666',
            fontWeight: 'bold'
          }}>
            {betSignal.status === 'Active' ? 'ACTIVE' : 'IDLE'}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsMinimized(false);
            }}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '14px',
              cursor: 'pointer',
              color: '#666',
              marginLeft: 'auto'
            }}
          >
            +
          </button>
        </div>
      </div>
    );
  }

  // Expanded state
  return (
    <div style={{
      position: 'fixed',
      top: '10px',
      right: '10px',
      background: betSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
      border: `2px solid ${betSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
      borderRadius: '8px',
      padding: '15px',
      minWidth: '300px',
      zIndex: 1500,
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      maxHeight: '400px',
      overflow: 'auto'
    }}>
      {/* Header with minimize button */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h3 style={{ margin: '0', fontSize: '16px' }}>🌙💤 MoonNextPairs Bot</h3>
        <button
          onClick={() => setIsMinimized(true)}
          style={{
            background: 'none',
            border: 'none',
            fontSize: '18px',
            cursor: 'pointer',
            color: '#666',
            padding: '2px 8px',
            borderRadius: '3px'
          }}
          title="Minimize"
        >
          −
        </button>
      </div>
      
      {/* Email Service Component */}
      {/* <EmailService 
        botStatus={betSignal?.status}
        botType="MoonNextPairs Bot"
      /> */}
      
      {betSignal && (
        <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
          <div><strong>Status: {betSignal.status}</strong></div>
          <div>Bet Amount: <strong>${betSignal.amount}</strong></div>
          <div>Reason: {betSignal.reason}</div>
          
          {betSignal.binaryPattern && (
            <div style={{ marginTop: '8px', fontFamily: 'monospace' }}>
              Pattern: [{betSignal.binaryPattern.join(', ')}]
            </div>
          )}

          {betSignal.status === 'Active' && (
            <button 
              onClick={executeBotBet}
              style={{
                background: '#4CAF50',
                color: 'white',
                border: 'none',
                padding: '6px 12px',
                borderRadius: '4px',
                marginTop: '8px',
                cursor: 'pointer',
                fontSize: '12px'
              }}
            >
              Execute Bet ${betSignal.amount}
            </button>
          )}
        </div>
      )}

      {botStats && (
        <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
          <div>Balance: <strong>${botStats.currentBalance}</strong></div>
          <div>Total Bets: {botStats.totalBets}</div>
          <div>Win Rate: {botStats.winRate}%</div>
          <div>Total Profit: <strong>${botStats.totalProfit}</strong></div>
        </div>
      )}
    </div>
  );
}

export default MoonPairBotPanel;