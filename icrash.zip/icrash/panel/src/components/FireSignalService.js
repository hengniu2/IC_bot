// components/FireSignalService.js
import React, { useEffect, useRef } from 'react';
import { signalLogger } from '../services/signalLogger';

// Webhook URLs for different bots
// NOTE: Update the webhook ID after creating the n8n workflow
// The webhook ID can be found in the n8n workflow webhook node settings
const WEBHOOK_URLS = {
  'BadRed': 'http://localhost:5678/webhook/937ad9c1-19be-4a95-a9f3-615eb4b68fb5/',
  'ThreeRed': 'http://localhost:5678/webhook/e180aa1d-bf2c-4901-9a74-96c63003a209/',
  // Add more bots as needed
};

// Default webhook URL (for backward compatibility)
const DEFAULT_WEBHOOK_URL = 'http://localhost:5678/webhook/937ad9c1-19be-4a95-a9f3-615eb4b68fb5/';

// FireSignalService - Sends webhook signals to n8n
// gameHash: The unique game hash that triggered the webhook (current/most recent game hash)
// lastValue: The bust value that triggered the webhook (for display/debugging)
function FireSignalService({ botName, betValue, fireSignal, onFireSignal, gameHash, lastValue }) {
  // Get webhook URL for this bot
  const webhookUrl = WEBHOOK_URLS[botName] || DEFAULT_WEBHOOK_URL;
  const fireSignalSentRef = useRef(false);
  const previousFireSignalRef = useRef(false);
  const lastSentSignalIdRef = useRef(null); // Track unique signal ID to prevent duplicates
  const lastSentGameHashRef = useRef(null); // Track gameHash to prevent duplicate sends for same game hash
  const lastSentLastValueRef = useRef(null); // Track lastValue to ensure it matches the hash

  // Function to send firesignal web request (no retry - fetch once)
  const sendFireSignal = async () => {
    // Debug: Track when this function is called
    if (botName === 'ThreeRed') {
      console.log(`[FireSignalService] sendFireSignal() called - gameHash: ${gameHash}`);
    }
    
    try {
      const betValueStr = String(betValue ?? "");
      const query = new URLSearchParams({
        bot: String(botName ?? ""),
        bet: betValueStr,
      }).toString();

      const url = `${webhookUrl}?${query}`;
      
      const response = await fetch(url, {
        method: "GET",
        mode: "cors",
        headers: { "Content-Type": "application/json" },
      });

      if (response.ok) {
        const responseText = await response.text();
        
        // Log success (only for ThreeRed-R)
        if (botName === 'ThreeRed') {
          signalLogger.logSignal({
            botName,
            betValue: betValueStr,
            webhookUrl: url,
            status: 'success',
            retryCount: 0,
            timestamp: new Date(),
            gameHash: gameHash ?? null,
            lastValue: lastValue ?? null
          });
          console.log('sendFireSignal completed');
        }
        
        return true;
      } else {
        const errorText = await response.text();
        const errorMessage = `HTTP ${response.status}: ${response.statusText}${errorText ? ` - ${errorText}` : ''}`;
        
        // Log error (only for ThreeRed-R)
        if (botName === 'ThreeRed') {
          signalLogger.logSignal({
            botName,
            betValue: betValueStr,
            webhookUrl: url,
            status: 'error',
            error: errorMessage,
            retryCount: 0,
            timestamp: new Date(),
            gameHash: gameHash ?? null,
            lastValue: lastValue ?? null
          });
          console.log('sendFireSignal completed');
        }

        return false;
      }
    } catch (error) {
      const errorMessage = `${error.name}: ${error.message}`;
      
      // Build full URL for error logging
      const betValueStr = String(betValue ?? "");
      const query = new URLSearchParams({
        bot: String(botName ?? ""),
        bet: betValueStr,
      }).toString();
      const url = `${webhookUrl}?${query}`;
      
      // Log error (only for ThreeRed-R)
      if (botName === 'ThreeRed') {
        signalLogger.logSignal({
          botName,
          betValue: betValueStr,
          webhookUrl: url,
          status: 'error',
          error: errorMessage,
          retryCount: 0,
          timestamp: new Date(),
          gameHash: gameHash ?? null,
          lastValue: lastValue ?? null
        });
        console.log('sendFireSignal completed');
      }

      return false;
    }
  };

  // Effect for firesignal web requests
  // IMPORTANT: Only depend on fireSignal to prevent duplicate sends when other dependencies change
  useEffect(() => {
    // Debug logging for ThreeRed
    if (botName === 'ThreeRed') {
      console.log('[FireSignalService] useEffect triggered (fireSignal changed):', {
        fireSignal,
        previousFireSignal: previousFireSignalRef.current,
        betValue,
        gameHash,
        timestamp: new Date().toISOString()
      });
    }
    
    // For ThreeRed bot, allow multiple sends (triggered on each new game data)
    // For other bots (like BadRed), send only once per activation
    const allowMultipleSends = botName === 'ThreeRed';
    
    if (fireSignal) {
      // For ThreeRed: send when fireSignal is true AND gameHash has changed
      // For others: send only once when first activated
      // Check if gameHash has changed to prevent duplicate sends
      const gameHashChanged = allowMultipleSends && gameHash !== null && gameHash !== lastSentGameHashRef.current;
      
      // For ThreeRed: Ensure lastValue has been updated when hash changes
      // Don't send if hash changed but lastValue hasn't been updated yet (still matches old hash's value)
      // Also check that lastValue < 2.0 (the condition for firing signals)
      let lastValueReady = true;
      if (botName === 'ThreeRed' && allowMultipleSends && gameHashChanged) {
        // If hash changed but lastValue hasn't changed from what we sent before, don't send yet
        // This means lastValue hasn't been updated from the new hash yet
        if (lastValue !== null && lastValue !== undefined && 
            lastSentLastValueRef.current !== null && 
            lastValue === lastSentLastValueRef.current) {
          lastValueReady = false;
          console.log('[FireSignalService] ⚠️ gameHash changed but lastValue not updated yet - skipping send', {
            gameHash,
            lastValue,
            lastSentHash: lastSentGameHashRef.current
          });
        }
        
        // IMPORTANT: Do not send if lastValue >= 2.0 (condition requires all last 3 busts < 2.0)
        // The current lastValue must be < 2.0 to be part of the "last 3 all < 2.0" condition
        if (lastValue !== null && lastValue !== undefined && lastValue >= 2.0) {
          lastValueReady = false;
          console.log('[FireSignalService] ⚠️ lastValue >= 2.0 - skipping send (condition requires last 3 busts all < 2.0)', {
            gameHash,
            lastValue,
            lastSentHash: lastSentGameHashRef.current
          });
        }
      }
      
      const shouldSend = allowMultipleSends 
        ? (gameHashChanged && lastValueReady)  // Send when gameHash changes AND lastValue is ready
        : (!fireSignalSentRef.current);
      
      if (shouldSend) {
        // Mark this gameHash and lastValue as sent to prevent duplicates
        if (gameHash !== null) {
          lastSentGameHashRef.current = gameHash;
        }
        if (lastValue !== null && lastValue !== undefined) {
          lastSentLastValueRef.current = lastValue;
        }
        
        if (botName === 'ThreeRed') {
          console.log('[FireSignalService] ✅ CALLING sendFireSignal() - reason: gameHash changed', {
            gameHashChanged,
            allowMultipleSends,
            betValue,
            gameHash,
            timestamp: new Date().toISOString()
          });
        }
        sendFireSignal().then(success => {
          if (botName === 'ThreeRed') {
            console.log('[FireSignalService] sendFireSignal() COMPLETED - success:', success, 'gameHash:', gameHash);
          }
          if (success) {
            if (!allowMultipleSends) {
              fireSignalSentRef.current = true;
            }
            // Call the callback to auto-execute bet if provided
            if (onFireSignal) {
              onFireSignal();
            }
          }
        });
      } else {
        if (botName === 'ThreeRed') {
          console.log('[FireSignalService] ⏭️ Skipping send:', {
            gameHashChanged,
            fireSignalSentRef: fireSignalSentRef.current,
            allowMultipleSends,
            gameHash,
            lastSentGameHash: lastSentGameHashRef.current,
            reason: allowMultipleSends 
              ? `gameHash unchanged (${gameHash} === ${lastSentGameHashRef.current})`
              : 'already sent'
          });
        }
      }
    }
      
    // Reset fireSignalSent when fireSignal becomes false (for non-ThreeRed bots)
    if (!fireSignal && fireSignalSentRef.current && !allowMultipleSends) {
      fireSignalSentRef.current = false;
    }
    
    // Reset lastSentGameHash and lastSentLastValue when fireSignal becomes false (for ThreeRed bot)
    if (!fireSignal && allowMultipleSends) {
      lastSentGameHashRef.current = null;
      lastSentLastValueRef.current = null;
    }
    
    // Update previous fireSignal state
    previousFireSignalRef.current = fireSignal;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fireSignal, gameHash, lastValue]); // Depend on fireSignal, gameHash, and lastValue - send when gameHash changes AND lastValue matches

  // This component doesn't render anything visible
  return null;
}

export default FireSignalService;