import React, { useState, useEffect } from 'react';

function GridDots() {
  const [seriesInput, setSeriesInput] = useState('');
  const [dots, setDots] = useState([]);
  const [previousValuesPerSequence, setPreviousValuesPerSequence] = useState([]);
  const [diffFunSequence, setDiffFunSequence] = useState([]);
  
  const handleInputChange = (e) => {
    setSeriesInput(e.target.value);
  };

  const handleGenerate = () => {
    const parsedSeries = seriesInput
      .split(/[,\s]+/)
      .map(str => parseFloat(str))
      .filter(num => !isNaN(num));

    const dotsData = parsedSeries.map((value) => {
      let color;
      if (value >= 10) {
        color = 'yellow'; // high values in yellow
      } else if (value < 2) {
        color = 'orange'; // low values in red
      } else if ((1.5 < value) && (value < 2)) {
        color = 'brown'; // low values in red
      } else  {
        color = 'lightgreen'; // middle values in green
      }
      return { value, color };
    });

    setDots(dotsData);
  };
  useEffect(() => {
    if (dots.length > 0) {
      const results = getAllPrecedingValuesPerSequence(dots);
      setPreviousValuesPerSequence(results);
    } else {
      setPreviousValuesPerSequence([]);
    }

    const diffFunSequence = [];
    let previousSequenceIndex = 0; // Initialize to 0 or the first sequence index

    previousValuesPerSequence.forEach((item, index) => {
      const currentIndex = item.sequenceIndex; // Make sure 'sequenceIndex' is correctly spelled
      const diff = currentIndex - previousSequenceIndex;
      diffFunSequence.push(diff);
      previousSequenceIndex = currentIndex;
      
      // Update for next iteration
   
    });
    setDiffFunSequence(diffFunSequence);
 

  }, [dots]);

  // Automatically generate dots whenever seriesInput changes
  useEffect(() => {
    if (seriesInput.trim() === '') {
      setDots([]);
      return;
    }
    const parsedSeries = seriesInput
      .split(/[,\s]+/)
      .map(str => parseFloat(str))
      .filter(num => !isNaN(num));

    const dotsData = parsedSeries.map((value) => {
      let color;
      if (value === 1.0) {
        color = 'red'; // special color for value == 1.0
      }
      else if (value >= 10) {
        color = 'yellow'; // high values in yellow
      } else if (value <= 1.5) {
        color = 'orange'; // low values in red
      } else if ((1.5 < value) && (value < 2)) {
        color = 'white'; // low values in red
      } else {
        color = 'lightgreen'; // middle values in green
      }
      return { value, color };
    });
    setDots(dotsData);
  }, [seriesInput]);

  // Function to check if two colors are considered the same group
  const isSameGroupColor = (color1, color2) => {
    const greenColors = ['lightgreen', 'yellow'];
    const redColors = ['orange', 'red', 'white'];
    if (greenColors.includes(color1) && greenColors.includes(color2)) {
      return true;
    }
    if (redColors.includes(color1) && redColors.includes(color2)) {
      return true;
    }
    return color1 === color2;
  };

  // Process input series to identify sequences of same color (treating yellow and green as same)
  const sequences = [];
  let currentSequence = [];
  for (let i = 0; i < dots.length; i++) {
    const dot = dots[i];
    if (currentSequence.length === 0) {
      currentSequence.push({ ...dot, startIndex: i });
    } else {
      if (isSameGroupColor(dot.color, currentSequence[currentSequence.length - 1].color)) {
        currentSequence.push({ ...dot, startIndex: i });
      } else {
        sequences.push(currentSequence);
        currentSequence = [{ ...dot, startIndex: i }];
      }
    }
  }
  if (currentSequence.length > 0) {
    sequences.push(currentSequence);
  }

  // Assign X positions per sequence
  const spacingX = 40; // horizontal spacing
  const spacingY = 20; // vertical spacing
  const positionedDots = [];

  // Track max height (number of dots in the tallest sequence)
  let maxSequenceLength = 0;
  sequences.forEach((sequence) => {
    if (sequence.length > maxSequenceLength) maxSequenceLength = sequence.length;
  });

  // Cap maxSequenceLength at 11
  const displayHeightInDots = Math.min(maxSequenceLength, 11);

  sequences.forEach((sequence, seqIndex) => {
    const xPos = seqIndex * spacingX;
    sequence.forEach((dot, index) => {
      const yPos = index * spacingY;
      // Only include dots up to max 11 for display
      if (index < displayHeightInDots) {
        positionedDots.push({
          ...dot,
          x: xPos / 2,
          y: yPos,
        });
      }
    });
  });
// Function to find 12 previous values before each 1.0 in each sequence
const getAllPrecedingValuesPerSequence = (seqDots) => {
  const results = [];

  seqDots.forEach((dot, index) => {
    if (dot.value === 1.0) {
      const startIdx = Math.max(0, index - 20);
      const prevValues = seqDots.slice(startIdx, index + 1).map(d => d.value);
      results.push({ sequenceIndex: index, previousValues: prevValues });
      
    }
  });

  return results; // return the array of results
};



  const backgroundSize = '20px 20px';

  return (
    <div
      style={{
        backgroundColor: 'white', // main background
        minHeight: '100vh',
        position: 'relative',
        fontFamily: 'Arial, sans-serif',
        padding: '20px',
      }}
    >
      {/* Input box at top-left */}
      <div
        style={{
          position: 'absolute',
          top: '10px',
          left: '10px',
          width: '600px',
          padding: '10px',
          backgroundColor: '#f0f0f0',
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          zIndex: 1,
        }}
      >
        <h4 style={{ fontSize: '0.8rem', margin: '0 0 10px 0' }}>Enter Series of Numbers (around 50):</h4>
        <textarea
          placeholder="e.g., 1.04, 1.17, 1.67, 2.55, 3.94, ..."
          value={seriesInput}
          onChange={handleInputChange}
          rows={4}
          style={{
            width: '100%',
            padding: '8px',
            fontSize: '0.8rem',
            borderRadius: '4px',
            border: '1px solid #ccc',
            resize: 'vertical',
            marginBottom: '10px',
          }}
        />
        {/* Optional: keep the button if you want manual generate too */}
        {/* <button
          onClick={handleGenerate}
          style={{
            padding: '6px 12px',
            fontSize: '0.8rem',
            borderRadius: '4px',
            border: 'none',
            backgroundColor: '#007bff',
            color: 'white',
            cursor: 'pointer',
          }}
        >
          Generate
        </button> */}
      </div>


      {/* Grid container with lighter background and grid lines */}
      <div
        style={{
          position: 'absolute',
          top: '180px',
          left: '20px',
          width: 'calc(100% - 40px)',
          height: `${(11 - 1) * 20 + 10}px`, // height for max 11 dots
          maxHeight: `${(11 - 1) * 20 + 10}px`,
          overflow: 'auto',
          backgroundColor: '#555', // lighter gray background
          backgroundImage:
            `linear-gradient(to right, #888 1px, transparent 1px),
             linear-gradient(to bottom, #888 1px, transparent 1px)`,
          backgroundSize: backgroundSize,
        }}
      >
        {positionedDots.map((dot, index) => (
          <div
            key={index}
            title={`Value: ${dot.value}`}
            style={{
              position: 'absolute',
              left: `${dot.x + 3}px`,
              top: `${dot.y + 8}px`,
              width: '10px',
              height: '10px',
              borderRadius: '70%',
              backgroundColor: dot.color,
            }}
          />
        ))}
      </div>
      <div style={{ marginTop: '350px', padding: '10px', backgroundColor: '#eee', borderRadius: '8px' }}>
      
      {Array.isArray(diffFunSequence) && (
        <p>{diffFunSequence.join(', ')}</p>
      )}
      <h4>Values before each 1.0 (Grouped per Sequence)</h4>
      {previousValuesPerSequence.length === 0 ? (
        <p>No 1.0 values found.</p>
      ) : (
        previousValuesPerSequence.map((item, index) => (
          <div key={index} style={{ marginBottom: '8px' }}>
            <strong>Sequence {item.sequenceIndex + 1}:</strong> {item.previousValues.length > 0 ? (
              item.previousValues.join(', ')
            ) : (
              <em>No previous values</em>
            )}
          </div>
        ))
      )}
    </div>
    </div>
  );
}

export default GridDots;