// components/ThreeRedRBotPanel.js
import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import EmailService from './EmailService';
import FireSignalService from './FireSignalService';
import { isBotEnabled } from '../utils/botControl';
import { startBettingRound, endBettingRound } from '../services/bettingHistoryService';
import { generateThreeRedSyncSeries } from '../utils/threeRedSyncSeries';

function ThreeRedRBotPanel({ gameResults, mainBot, lastGeneratedBust, botStats, botConfig, gameData }) {
  const [isMinimized, setIsMinimized] = useState(true);
  const [fireSignalActive, setFireSignalActive] = useState(false);
  const [manualFireSignal, setManualFireSignal] = useState(false);
  
  // Track previous status to detect when bot becomes active
  const previousStatusRef = useRef(null);
  const previousBustRef = useRef(null);
  
  // Fire signal tracking
  const firingSignalsRef = useRef(false);
  const currentBetAmountRef = useRef(null); // Current bet amount based on milestone pattern
  const lastTriggeredBustRef = useRef(null); // Track last bust value we triggered fireSignal for
  const previousConditionMetRef = useRef(null); // Track previous condition state to log only on changes
  
  // Betting history tracking
  const currentRoundRef = useRef(null); // Store current round tracking data
  
  // Track if round is in progress - once round starts, keep bot Active until round completes
  const roundInProgressRef = useRef(false);
  
  // State for UI display
  const [firingSignals, setFiringSignals] = useState(false);
  const [currentBetAmount, setCurrentBetAmount] = useState(null);
  
  // Effective status: combines sequence-based status with round-in-progress status
  const [effectiveStatus, setEffectiveStatus] = useState('Inactive');
  
  // Check if bot is enabled from control panel
  const botEnabled = isBotEnabled('threeRedR');
  
  // Get bet amount (click count for DoubleAmount) based on milestone pattern length (from Firebase config)
  // Note: The config values (v_1_1, v_2_1, v_3_1) are treated as CLICK COUNTS for DoubleAmount button
  // These will be passed directly to AHK script which clicks DoubleAmount that many times
  const getBetAmountForRetry = (patternLevel) => {
    if (!botConfig) {
      console.warn('ThreeRedR Bot: No botConfig available, using default click count');
      return 0; // Default fallback - no clicks
    }
    
    // patternLevel: 0 = 4 digits "1000" (v_1_1), 1 = 5 digits "10000" (v_2_1), 2 = 6 digits "100000" (v_3_1)
    // Note: The parameter name "retryNum" is misleading - it's actually the pattern level/milestone length
    const betFieldMap = {
      0: 'v_1_1', // 4 digits pattern: 1000
      1: 'v_2_1', // 5 digits pattern: 10000
      2: 'v_3_1'  // 6 digits pattern: 100000
    };
    
    const fieldName = betFieldMap[patternLevel];
    const clickCount = botConfig[fieldName];
    
    if (clickCount === undefined || clickCount === null) {
      return 0;
    }
    
    // Convert to number and ensure it's a valid non-negative integer
    const clickCountNum = Math.max(0, Math.floor(Number(clickCount)) || 0);
    
    return clickCountNum;
  };

  // Calculate bot signal based on ThreeRedSyncSeries patterns
  const redThreeSignal = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return { 
        status: 'Inactive', 
        amount: 0, 
        reason: 'No game data available',
        milestonePattern: null,
        patternLength: null
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    
    // Generate ThreeRedSyncSeries
    const threeRedSyncSeriesResult = generateThreeRedSyncSeries(bustValues);
    const threeRedSyncSeries = threeRedSyncSeriesResult.binaryString;
    
    if (threeRedSyncSeries.length < 4) {
      return {
        status: 'Inactive',
        amount: 0,
        reason: `ThreeRedSyncSeries too short (${threeRedSyncSeries.length} < 4)`,
        milestonePattern: null,
        patternLength: null
      };
    }

    // Check last 4-7 digits for milestone patterns
    // ACTIVE (Positive): 1000 (4), 10000 (5), 100000 (6)
    // INACTIVE (Negative): 10001 (5), 100001 (6), 1000001 (7), 1000000 (7)
    
    const last7 = threeRedSyncSeries.slice(-7);
    const last6 = threeRedSyncSeries.slice(-6);
    const last5 = threeRedSyncSeries.slice(-5);
    const last4 = threeRedSyncSeries.slice(-4);
    
    // Check for negative milestone patterns first (longest first) - these deactivate
    if (last7 === '1000000') {
      return {
        status: 'Inactive',
        amount: 0,
        reason: 'Negative milestone: last 7 digits = 1000000',
        milestonePattern: '1000000',
        patternLength: 7
      };
    }
    
    if (last7 === '1000001') {
      return {
        status: 'Inactive',
        amount: 0,
        reason: 'Negative milestone: last 7 digits = 1000001',
        milestonePattern: '1000001',
        patternLength: 7
      };
    }
    
    // Check for 6-digit patterns (positive vs negative)
    if (last6 === '100001') {
      return {
        status: 'Inactive',
        amount: 0,
        reason: 'Negative milestone: last 6 digits = 100001',
        milestonePattern: '100001',
        patternLength: 6
      };
    }
    
    if (last6 === '100000') {
      return {
        status: 'Active',
        amount: getBetAmountForRetry(2), // v_3_1 for 6 digits
        reason: 'Positive milestone: last 6 digits = 100000',
        milestonePattern: '100000',
        patternLength: 6
      };
    }
    
    // Check for 5-digit patterns (positive vs negative)
    if (last5 === '10001') {
      return {
        status: 'Inactive',
        amount: 0,
        reason: 'Negative milestone: last 5 digits = 10001',
        milestonePattern: '10001',
        patternLength: 5
      };
    }
    
    if (last5 === '10000') {
      return {
        status: 'Active',
        amount: getBetAmountForRetry(1), // v_2_1 for 5 digits
        reason: 'Positive milestone: last 5 digits = 10000',
        milestonePattern: '10000',
        patternLength: 5
      };
    }
    
    // Check for 4-digit pattern (positive)
    if (last4 === '1000') {
      return {
        status: 'Active',
        amount: getBetAmountForRetry(0), // v_1_1 for 4 digits
        reason: 'Positive milestone: last 4 digits = 1000',
        milestonePattern: '1000',
        patternLength: 4
      };
    }
    
    // Default: Inactive (no matching milestone pattern)
    console.log(`[ThreeRedR] ❌ No milestone pattern matched. Last 4 digits: ${last4}`);
    return {
      status: 'Inactive',
      amount: 0,
      reason: 'No matching milestone pattern',
      milestonePattern: null,
      patternLength: null
    };
  }, [gameResults, botConfig]); // Add botConfig as dependency for getBetAmountForRetry
  
  // Calculate effective status: use milestone-based status (negative patterns deactivate even during round)
  useEffect(() => {
    // Always use milestone-based status - negative patterns should deactivate immediately
    console.log(`[ThreeRedR] Setting status to: ${redThreeSignal.status} (milestone pattern: ${redThreeSignal.milestonePattern})`);
    setEffectiveStatus(redThreeSignal.status);
    
    // Update bet amount based on milestone pattern
    if (redThreeSignal.status === 'Active' && redThreeSignal.amount > 0) {
      currentBetAmountRef.current = redThreeSignal.amount;
      setCurrentBetAmount(redThreeSignal.amount);
    }
  }, [redThreeSignal.status, redThreeSignal.amount, redThreeSignal.milestonePattern]);

  // Effect to handle fire signal logic: fire on every new game data while active, but only when last 3 busts < 2
  useEffect(() => {
    const isActive = effectiveStatus === 'Active';
    const wasActive = previousStatusRef.current === 'Active';
    const bustChanged = previousBustRef.current !== lastGeneratedBust;
    
    // Debug logging - execute early to see what's happening

    
    // Don't process if bot is disabled
    if (!botEnabled) {
      setFireSignalActive(false);
      firingSignalsRef.current = false;
      setFiringSignals(false);
      roundInProgressRef.current = false;
      return;
    }
    
    // When bot becomes inactive (milestone pattern no longer matches), stop firing and end round
    // IMPORTANT: Handle deactivation BEFORE activation to ensure clean state transitions
    if (!isActive && wasActive) {
      const deactivationReason = redThreeSignal.reason || 'milestone pattern no longer matches';
      console.log(`ThreeRedR Bot: Deactivated - ${deactivationReason}`);
      
      // End betting history tracking
      if (currentRoundRef.current) {
        const endHash = gameData?.hash || gameResults[0]?.hash || '';
        const lastBalance = botStats?.currentBalance || mainBot?.balance || 0;
        const startHash = currentRoundRef.current.startHash;
        
        console.log('[BettingHistory] Round ending:', {
          startHash,
          endHash,
          endHashSource: gameData?.hash ? 'gameData.hash' : (gameResults[0]?.hash ? 'gameResults[0].hash' : 'none'),
          lastBalance,
          previousBalance: currentRoundRef.current.previousBalance
        });
        
        endBettingRound({
          roundData: currentRoundRef.current,
          endHash,
          lastBalance,
          isSuccess: false // Pattern ended, not a success
        }).then(() => {
          currentRoundRef.current = null;
        });
      }
      
      // Reset flags
      roundInProgressRef.current = false;
      firingSignalsRef.current = false;
      setFiringSignals(false);
      setFireSignalActive(false);
      currentBetAmountRef.current = null;
      setCurrentBetAmount(null);
      lastTriggeredBustRef.current = null; // Reset last triggered bust tracking
    }
    
    // When bot becomes active, start firing signals
    if (isActive && !wasActive) {
      console.log('ThreeRedR Bot: Activated based on ThreeRedSyncSeries milestone pattern');
      roundInProgressRef.current = true;
      firingSignalsRef.current = true;
      setFiringSignals(true);
      
      // Start betting history tracking
      if (!currentRoundRef.current && gameData) {
              const startHash = gameData?.hash || gameResults[0]?.hash || '';
              const previousBalance = botStats?.currentBalance || mainBot?.balance || 0;
              const botId = botConfig?.id || '';
              const userId = botConfig?.userId || '';
              const budget = botConfig?.budget || '0';
              
              if (startHash && botId) {
                const roundTracking = startBettingRound({
                  botId,
                  userId,
                  budget,
                  startHash,
                  previousBalance
                });
                currentRoundRef.current = roundTracking.roundData;
                console.log('[BettingHistory] Round started:', {
                  roundId: roundTracking.roundId,
                  botId,
                  startHash,
                  startHashSource: gameData?.hash ? 'gameData.hash' : (gameResults[0]?.hash ? 'gameResults[0].hash' : 'none'),
                  previousBalance
                });
              }
            }
            
      previousBustRef.current = lastGeneratedBust;
    }
    
    // When bot is active, check fire signal condition on every game data update
    if (isActive && lastGeneratedBust !== null && firingSignalsRef.current) {
      // Check if newest 3 busts are < 2.0
      // IMPORTANT: Include lastGeneratedBust (current/newest bust) in the newest 3 busts
      const bustValues = gameResults.map(res => res.bust);
      
      // Build newest 3 busts: [current/newest (lastGeneratedBust), second-newest, third-newest]
      // lastGeneratedBust is the current/newest bust value (from current gameData.hash)
      // gameResults[0] is the same as lastGeneratedBust in live mode (both from gameData.hash)
      // gameResults[1] is second-newest (from second hash)
      // gameResults[2] is third-newest (from third hash)
      const newestBust = lastGeneratedBust; // Current/newest bust
      const secondNewest = bustValues.length > 1 ? bustValues[1] : null; // Second hash result
      const thirdNewest = bustValues.length > 2 ? bustValues[2] : null; // Third hash result
      
      // Build array with newest 3 busts (filter out nulls)
      const newestThreeBusts = [newestBust, secondNewest, thirdNewest].filter(b => b !== null);
      
      // Console log last three values
      console.log('(last three values ----', newestThreeBusts.map(b => b !== null ? b.toFixed(2) : 'null').join(', '));
      
      // Ensure we have at least 3 busts before checking
      const allNewestThreeLessThan2 = newestThreeBusts.length >= 3 && newestThreeBusts.every(bust => bust < 2.0);
      
      // Debug: Log the condition check
      if (bustChanged) {
        console.log(`ThreeRedR Bot: Condition check - newest 3 busts: [${newestThreeBusts.map(b => b.toFixed(2)).join(', ')}], all < 2.0: ${allNewestThreeLessThan2}, current bust: ${lastGeneratedBust.toFixed(2)}x`);
      }
      
      // Only log when condition state changes (not on every useEffect run)
      const conditionJustChanged = previousConditionMetRef.current !== null && previousConditionMetRef.current !== allNewestThreeLessThan2;
      
      if (allNewestThreeLessThan2) {
        // Continue firing while active AND newest 3 busts are < 2.0
        // Only trigger fireSignal when bust changes (new game data)
        if (bustChanged && lastTriggeredBustRef.current !== lastGeneratedBust) {
          console.log(`ThreeRedR Bot: ✅ Firing signal - newest 3 busts are < 2 (${newestThreeBusts.map(b => b.toFixed(2)).join(', ')}) - bust: ${lastGeneratedBust.toFixed(2)}x`);
          
          // Mark this bust value as triggered
          lastTriggeredBustRef.current = lastGeneratedBust;
          
          // Set fireSignal to trigger FireSignalService
          // FireSignalService will send when fireSignal is true and lastValue has changed
          setFireSignalActive(true);

        } else if (bustChanged && lastTriggeredBustRef.current === lastGeneratedBust) {
          console.log(`ThreeRedR Bot: ⚠️ Skipping - already triggered fireSignal for bust value: ${lastGeneratedBust.toFixed(2)}x`);
        }
      } else {
        // Condition NOT met - explicitly stop firing and reset tracking
        // Only log when condition just changed from true to false
        if (conditionJustChanged || previousConditionMetRef.current === null) {
          console.log(`ThreeRedR Bot: ❌ Condition NOT met - newest 3 busts NOT all < 2 (${newestThreeBusts.map(b => b.toFixed(2)).join(', ')}) - stopping fire signal`);
        }
        
        // Explicitly set fireSignalActive to false to stop any pending signals
        if (fireSignalActive) {
          setFireSignalActive(false);
        }
        
        // Reset to allow firing again if condition becomes true later
        lastTriggeredBustRef.current = null;
      }
      
      // Update previous condition state
      previousConditionMetRef.current = allNewestThreeLessThan2;
      
      // Update previous bust after processing
      if (bustChanged) {
      previousBustRef.current = lastGeneratedBust;
      }
    }
    
    // Update previous status
    previousStatusRef.current = effectiveStatus;
  }, [effectiveStatus, lastGeneratedBust, gameResults, botEnabled, gameData, botStats, mainBot, botConfig]);

  const executeRedThreeBet = () => {
    if (mainBot && redThreeSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
      console.log('ThreeRedR bot bet executed:', result);
    }
  };

  const handleManualExecute = () => {
    if (!botEnabled) {
      console.log('ThreeRedR Bot is disabled from control panel');
      return;
    }
    
    console.log('ThreeRedR Bot: Manual Execute button clicked');
    
    // Execute the bet
    if (mainBot && redThreeSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
      console.log('Manual bet execution:', result);
    }
    
    // Trigger manual firesignal
    setManualFireSignal(true);
    
    // Reset manual firesignal after a short delay
    setTimeout(() => {
      setManualFireSignal(false);
    }, 1000);
  };

  // Memoize onFireSignal callback to prevent unnecessary re-renders
  const handleFireSignal = useCallback(() => {
    // For mainBot.executeBet, we need actual bet amount, but for AHK we pass click count
    // Since we don't know the base amount after InitializeAmount, we'll use a default for executeBet
    const clickCount = currentBetAmountRef.current ?? currentBetAmount ?? redThreeSignal.amount ?? 0;
    const betAmount = 10; // Placeholder for executeBet calculation
    if (mainBot && lastGeneratedBust && betAmount > 0) {
      const result = mainBot.executeBet(betAmount, lastGeneratedBust, 2.0);
      console.log('FireSignal: Auto-executing bet:', result);
    }
  }, [mainBot, lastGeneratedBust, currentBetAmount, redThreeSignal.amount]);

  return (
    <>
      {/* Email Service Component - Always render for debugging, but only function when bot is enabled */}
      <EmailService 
        botStatus={effectiveStatus}
        botType="ThreeRedR Bot"
        botEnabled={botEnabled}
      />

      {/* Add loading state */}
      {(!gameResults || gameResults.length === 0) ? (
        <div style={{
          position: 'fixed',
          top: '120px',
          right: '320px',
          background: '#f8f9fa',
          border: '2px solid #6c757d',
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🔴👤👤👤 ThreeRedR Bot
              {!botEnabled && <span style={{ fontSize: '12px', color: '#dc3545', marginLeft: '8px' }}>(DISABLED)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                cursor: 'pointer',
                color: '#666'
              }}
            >
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>
            Waiting for game data...
          </div>
        </div>
      ) : isMinimized ? (
        // Minimized state
        <div style={{
          position: 'fixed',
          top: '10px',
          right: '1150px',
          background: effectiveStatus === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${effectiveStatus === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '10px 15px',
          zIndex: 1000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          cursor: 'pointer'
        }}
        onClick={() => setIsMinimized(false)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🔴👤👤👤</span>
            <span style={{ fontSize: '12px' }}>
              {effectiveStatus === 'Active' ? `$${redThreeSignal.amount}` : 'Inactive'}
            </span>
            <span style={{ 
              fontSize: '10px', 
              color: effectiveStatus === 'Active' ? '#4CAF50' : '#666',
              fontWeight: 'bold'
            }}>
              {effectiveStatus === 'Active' ? 'ACTIVE' : 'IDLE'}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer',
                color: '#666',
                marginLeft: 'auto'
              }}
            >
              +
            </button>
          </div>
        </div>
      ) : (
        // Expanded state
        <div style={{
          position: 'fixed',
          top: '240px',
          right: '10px',
          background: effectiveStatus === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${effectiveStatus === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 3000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          maxHeight: '500px',
          overflow: 'auto'
        }}>
          {/* Header with minimize button */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🔴 ThreeRedR Bot
              {!botEnabled && <span style={{ fontSize: '12px', color: '#dc3545', marginLeft: '8px' }}>(DISABLED)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(true)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '18px',
                cursor: 'pointer',
                color: '#666',
                padding: '2px 8px',
                borderRadius: '3px'
              }}
              title="Minimize"
            >
              −
            </button>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {effectiveStatus}</strong></div>
            <div>Bet Amount: <strong>${redThreeSignal.amount}</strong></div>
            <div>Reason: {redThreeSignal.reason}</div>

            {/* Execute Button */}
            <div style={{ marginTop: '15px' }}>
              <button 
                onClick={handleManualExecute}
                style={{
                  background: effectiveStatus === 'Active' ? '#4CAF50' : '#2196F3',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  width: '100%'
                }}
              >
                {effectiveStatus === 'Active' ? '🚀 Execute & FireSignal' : '⚡ Manual Execute'} 
                ${redThreeSignal.amount}
              </button>
              
              <div style={{ 
                fontSize: '10px', 
                color: '#666', 
                marginTop: '8px',
                textAlign: 'center'
              }}>
                {effectiveStatus === 'Active' 
                  ? 'Waits for 3 sequential reds, then fires until green' 
                  : 'Manual execute (bot is currently inactive)'}
              </div>
              
              {firingSignals && (
                <div style={{ 
                  fontSize: '10px', 
                  color: '#4CAF50', 
                  marginTop: '4px',
                  textAlign: 'center',
                  fontWeight: 'bold'
                }}>
                  🔥 FireSignal Active - Firing on new game data (last 3 busts &lt; 2)
                  {currentBetAmount && (
                    <span style={{ display: 'block', marginTop: '2px' }}>
                      Bet: {currentBetAmount} clicks
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* ThreeRedSyncSeries Milestone Info */}
          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>ThreeRedSyncSeries Milestone:</strong></div>
            {redThreeSignal.milestonePattern && (
              <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
                Pattern: <strong>{redThreeSignal.milestonePattern}</strong> ({redThreeSignal.patternLength} digits)
              </div>
            )}
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Positive: 1000 (4), 10001 (5), 100001 (6), 1000001 (7)
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Negative: 1000 (4), 10000 (5), 100000 (6), 1000000 (7)
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Fires on every new game data while active (last 3 busts &lt; 2)
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Bet: 4 digits = {botConfig?.v_1_1 ?? 'v_1_1'} clicks | 5 digits = {botConfig?.v_2_1 ?? 'v_2_1'} clicks | 6 digits = {botConfig?.v_3_1 ?? 'v_3_1'} clicks
            </div>
          </div>

          {botStats && (
            <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
      
      {/* Fire Signal Service Component - Only if bot is enabled, render after state is set */}
      {botEnabled && (() => {
        // Calculate gameHash and matching lastValue
        const currentGameHash = gameData?.hash || gameResults[0]?.hash || null;
        
        // Calculate lastValue that matches the gameHash
        let lastValueToUse = null;
        if (currentGameHash) {
          if (currentGameHash === gameData?.hash) {
            // gameHash is from live gameData, use lastGeneratedBust (calculated from gameData.hash)
            lastValueToUse = lastGeneratedBust;
          } else if (gameResults && gameResults.length > 0 && gameResults[0]?.hash === currentGameHash) {
            // gameHash is from gameResults, use the corresponding bust value
            lastValueToUse = gameResults[0].bust;
          }
        }
        
        // Fallback to lastGeneratedBust if nothing found
        if (lastValueToUse === null) {
          lastValueToUse = lastGeneratedBust;
        }
        
        return (
          <FireSignalService
            botName="ThreeRed"
            betValue={currentBetAmountRef.current ?? currentBetAmount ?? redThreeSignal.amount ?? 0}
            fireSignal={fireSignalActive || manualFireSignal}
            onFireSignal={handleFireSignal}
            gameHash={currentGameHash}
            lastValue={lastValueToUse}
          />
        );
      })()}
    </>
  );
}

export default ThreeRedRBotPanel;


