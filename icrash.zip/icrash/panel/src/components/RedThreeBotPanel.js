// components/RedThreeBotPanel.js
import React, { useState, useMemo } from 'react';
import EmailService from './EmailService';

// Helper function to find sequences of 3+ games with bust < 2x followed by value > 2x
const findLowSequencesFollowedByHigh = (bustValues) => {
  bustValues = bustValues.reverse();
  const sequences = [];
  let currentLowSequence = [];
  
  for (let i = 0; i < bustValues.length - 1; i++) {
    const currentBust = bustValues[i];
    const nextBust = bustValues[i + 1];
    
    // If current bust is < 2, add to current low sequence
    if (currentBust < 2) {
      currentLowSequence.push({ 
        index: i, 
        value: currentBust,
        gameNumber: i + 1
      });
    } else {
      // If we have a sequence of 3+ low busts and next value is > 2
      if (currentLowSequence.length >= 3 && currentBust > 2) {
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: i + 1,
          nextValue: currentBust,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2))
        });
      }
      // Reset the sequence
      currentLowSequence = [];
    }
  }
  
  // Check if there's a sequence at the end of the array
  if (currentLowSequence.length >= 3) {
    sequences.push({
      lowSequenceLength: currentLowSequence.length,
      startGame: currentLowSequence[0].gameNumber,
      endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
      nextGame: 'N/A',
      nextValue: 'N/A',      
      lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2)),
      incomplete: true
    });
  }
  
  return sequences;
};

function RedThreeBotPanel({ gameResults, mainBot, lastGeneratedBust, botStats }) {
  const [isMinimized, setIsMinimized] = useState(true);

  // Calculate sequences and bot signal
  const redThreeSignal = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return { 
        status: 'Inactive', 
        amount: 0, 
        reason: 'No game data available',
        sequences: []
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    const sequences = findLowSequencesFollowedByHigh(bustValues);
    
    // Filter out incomplete sequences and get the last 3 complete sequences
    const completeSequences = sequences.filter(seq => !seq.incomplete && seq.nextValue !== 'N/A');
    const lastThreeSequences = completeSequences.slice(-3);
    
    if (lastThreeSequences.length < 3) {
      return {
        status: 'Inactive',
        amount: 0,
        reason: `Need 3 complete sequences, found ${lastThreeSequences.length}`,
        sequences: lastThreeSequences
      };
    }

    // Check if all last three sequences have next values < 3
    const allBelowThree = lastThreeSequences.every(seq => seq.nextValue < 3);
    
    if (allBelowThree) {
      const betAmount = 10; // Base bet amount
      return {
        status: 'Active',
        amount: betAmount,
        reason: 'Last 3 consecutive sequences all have next values < 3x',
        sequences: lastThreeSequences,
        sequenceData: {
          sequence1: {
            length: lastThreeSequences[0].lowSequenceLength,
            nextValue: lastThreeSequences[0].nextValue
          },
          sequence2: {
            length: lastThreeSequences[1].lowSequenceLength,
            nextValue: lastThreeSequences[1].nextValue
          },
          sequence3: {
            length: lastThreeSequences[2].lowSequenceLength,
            nextValue: lastThreeSequences[2].nextValue
          }
        }
      };
    }

    return {
      status: 'Inactive',
      amount: 0,
      reason: `Not all last 3 sequences are below 3x`,
      sequences: lastThreeSequences,
      sequenceData: {
        sequence1: {
          length: lastThreeSequences[0].lowSequenceLength,
          nextValue: lastThreeSequences[0].nextValue
        },
        sequence2: {
          length: lastThreeSequences[1].lowSequenceLength,
          nextValue: lastThreeSequences[1].nextValue
        },
        sequence3: {
          length: lastThreeSequences[2].lowSequenceLength,
          nextValue: lastThreeSequences[2].nextValue
        }
      }
    };
  }, [gameResults]);

  const executeRedThreeBet = () => {
    if (mainBot && redThreeSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
      console.log('RedThree bot bet executed:', result);
    }
  };

  return (
    <>
      {/* Email Service Component */}
      <EmailService 
        botStatus={redThreeSignal?.status}
        botType="RedThree Bot"
      />

      {/* Add loading state */}
      {(!gameResults || gameResults.length === 0) ? (
        <div style={{
          position: 'fixed',
          top: '120px',
          right: '320px',
          background: '#f8f9fa',
          border: '2px solid #6c757d',
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>🔴👤👤👤 RedThree Bot</h3>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                cursor: 'pointer',
                color: '#666'
              }}
            >
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>
            Waiting for game data...
          </div>
        </div>
      ) : isMinimized ? (
        // Minimized state
        <div style={{
          position: 'fixed',
          top: '10px',
          right: '370px',
          background: redThreeSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${redThreeSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '10px 15px',
          zIndex: 1000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          cursor: 'pointer'
        }}
        onClick={() => setIsMinimized(false)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🔴👤👤👤</span>
            <span style={{ fontSize: '12px' }}>
              {redThreeSignal.status === 'Active' ? `$${redThreeSignal.amount}` : 'Inactive'}
            </span>
            <span style={{ 
              fontSize: '10px', 
              color: redThreeSignal.status === 'Active' ? '#4CAF50' : '#666',
              fontWeight: 'bold'
            }}>
              {redThreeSignal.status === 'Active' ? 'ACTIVE' : 'IDLE'}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer',
                color: '#666',
                marginLeft: 'auto'
              }}
            >
              +
            </button>
          </div>
        </div>
      ) : (
        // Expanded state
        <div style={{
          position: 'fixed',
          top: '240px',
          right: '10px',
          background: redThreeSignal?.status === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${redThreeSignal?.status === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 3000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          maxHeight: '500px',
          overflow: 'auto'
        }}>
          {/* Header with minimize button */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>🔴 RedThree Bot</h3>
            <button
              onClick={() => setIsMinimized(true)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '18px',
                cursor: 'pointer',
                color: '#666',
                padding: '2px 8px',
                borderRadius: '3px'
              }}
              title="Minimize"
            >
              −
            </button>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {redThreeSignal.status}</strong></div>
            <div>Bet Amount: <strong>${redThreeSignal.amount}</strong></div>
            <div>Reason: {redThreeSignal.reason}</div>
            
            {redThreeSignal.sequenceData && (
              <div style={{ marginTop: '8px', fontFamily: 'monospace', fontSize: '11px' }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence1.nextValue < 3 ? '#ffebee' : '#f1f8e9',
                  borderRadius: '3px'
                }}>
                  <span>Seq 1 (L:{redThreeSignal.sequenceData.sequence1.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence1.nextValue < 3 ? '#f44336' : '#4CAF50',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence1.nextValue.toFixed(2)}x
                  </span>
                </div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence2.nextValue < 3 ? '#ffebee' : '#f1f8e9',
                  borderRadius: '3px'
                }}>
                  <span>Seq 2 (L:{redThreeSignal.sequenceData.sequence2.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence2.nextValue < 3 ? '#f44336' : '#4CAF50',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence2.nextValue.toFixed(2)}x
                  </span>
                </div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence3.nextValue < 3 ? '#ffebee' : '#f1f8e9',
                  borderRadius: '3px'
                }}>
                  <span>Seq 3 (L:{redThreeSignal.sequenceData.sequence3.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence3.nextValue < 3 ? '#f44336' : '#4CAF50',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence3.nextValue.toFixed(2)}x
                  </span>
                </div>
              </div>
            )}

            {redThreeSignal.status === 'Active' && (
              <button 
                onClick={executeRedThreeBet}
                style={{
                  background: '#4CAF50',
                  color: 'white',
                  border: 'none',
                  padding: '6px 12px',
                  borderRadius: '4px',
                  marginTop: '8px',
                  cursor: 'pointer',
                  fontSize: '12px'
                }}
              >
                Execute Bet ${redThreeSignal.amount}
              </button>
            )}
          </div>

          {/* Recent sequences info */}
          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>Last 3 Sequences Analysis:</strong></div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Looks for sequences of 3+ games &lt; 2x followed by &gt; 2x
            </div>
            <div style={{ fontSize: '9px', color: '#666' }}>
              Activates when last 3 sequences all have next values &lt; 3x
            </div>
          </div>

          {botStats && (
            <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export default RedThreeBotPanel;