import React, { useState, useMemo, useRef, useEffect } from 'react';
import Chart from 'chart.js/auto';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import annotationPlugin from 'chartjs-plugin-annotation';

// Register plugins
Chart.register(ChartDataLabels, annotationPlugin);

function ClassicView({ gameResults }) {
  const [chartView, setChartView] = useState('line'); // 'line' or 'bar'
  const [chartPage, setChartPage] = useState(0); // For pagination of chart data
  const [dotsPerHour, setDotsPerHour] = useState(100); // How many dots represent 1 hour
  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null);
  
  const CHART_ITEMS_PER_PAGE = 500;

  // Calculate statistics
  const stats = useMemo(() => {
    if (!gameResults || gameResults.length === 0) return null;

    const total = gameResults.length;
    const reds = gameResults.filter(r => r.bust < 2).length;
    const greens = gameResults.filter(r => r.bust >= 2 && r.bust < 10).length;
    const golds = gameResults.filter(r => r.bust >= 10).length;

    return {
      total,
      reds,
      greens,
      golds,
      redPercent: ((reds / total) * 100).toFixed(1),
      greenPercent: ((greens / total) * 100).toFixed(1),
      goldPercent: ((golds / total) * 100).toFixed(1),
    };
  }, [gameResults]);

  // Get color based on bust value (same logic as HeaderSection)
  const getColor = (bust) => {
    if (bust >= 10) return '#e0a800'; // Gold/Yellow
    if (bust >= 2) return '#198754';   // Green
    return '#c82333';                   // Red
  };

  // Calculate time for a game index (GMT+9)
  const getTimeForGame = (gameIndex, totalGames) => {
    // Current time in GMT+9
    const now = new Date();
    const gmtPlus9Offset = 9 * 60; // GMT+9 in minutes
    const localOffset = now.getTimezoneOffset(); // Local offset in minutes (negative for ahead of UTC)
    const offsetDiff = gmtPlus9Offset + localOffset; // Difference in minutes
    
    const currentTimeGMT9 = new Date(now.getTime() + offsetDiff * 60 * 1000);
    
    // Calculate how many hours ago this game was
    // gameIndex 0 is the newest (current time), higher index = older
    const gamesAgo = totalGames - gameIndex - 1;
    const hoursAgo = gamesAgo / dotsPerHour;
    
    // Calculate the time for this game
    return new Date(currentTimeGMT9.getTime() - hoursAgo * 60 * 60 * 1000);
  };

  // Format time as "9am" or "4pm" with optional date
  const formatTime = (date, includeDate = false) => {
    const hours = date.getHours();
    let timeStr = '';
    if (hours === 0) timeStr = '12am';
    else if (hours < 12) timeStr = `${hours}am`;
    else if (hours === 12) timeStr = '12pm';
    else timeStr = `${hours - 12}pm`;
    
    if (includeDate) {
      const month = date.getMonth() + 1;
      const day = date.getDate();
      return `${month}/${day} ${timeStr}`;
    }
    
    return timeStr;
  };

  // Chart data preparation with pagination (500 per page)
  const chartData = useMemo(() => {
    if (!gameResults || gameResults.length === 0) return null;

    // Use reversed results (newest first) for chart
    const results = [...gameResults].reverse();
    
    // Paginate: show 500 items per page
    const startIndex = chartPage * CHART_ITEMS_PER_PAGE;
    const endIndex = Math.min(startIndex + CHART_ITEMS_PER_PAGE, results.length);
    const pageResults = results.slice(startIndex, endIndex);
    
    return {
      labels: pageResults.map((_, index) => {
        const globalIndex = startIndex + index;
        const gameNumber = results.length - globalIndex;
        const gameTime = getTimeForGame(globalIndex, results.length);
        
        // Check if date changed from previous
        let includeDate = false;
        if (index > 0) {
          const prevTime = getTimeForGame(startIndex + index - 1, results.length);
          if (prevTime.getDate() !== gameTime.getDate()) {
            includeDate = true;
          }
        } else if (startIndex === 0 && index === 0) {
          // Always show date for the first (newest) game
          includeDate = true;
        }
        
        // Store both game number and time in the label
        return {
          gameNumber,
          time: gameTime,
          timeString: formatTime(gameTime, includeDate),
          globalIndex,
          hour: gameTime.getHours()
        };
      }),
      datasets: [{
        label: 'Bust Values',
        data: pageResults.map(r => r.bust),
        fill: false,
        borderColor: '#4CAF50',
        backgroundColor: '#81C784',
        borderWidth: chartView === 'line' ? 2 : 1,
        pointRadius: chartView === 'line' ? 3 : 0,
        pointHoverRadius: 6,
        pointBorderWidth: 2,
        pointBackgroundColor: pageResults.map(r => getColor(r.bust)),
        pointBorderColor: pageResults.map(r => getColor(r.bust)),
        tension: 0.4
      }],
      pageResultsCount: pageResults.length // Store count for width calculation
    };
  }, [gameResults, chartPage, CHART_ITEMS_PER_PAGE, chartView, dotsPerHour]);
  
  // Calculate total pages for chart
  const totalChartPages = useMemo(() => {
    if (!gameResults || gameResults.length === 0) return 0;
    return Math.ceil(gameResults.length / CHART_ITEMS_PER_PAGE);
  }, [gameResults, CHART_ITEMS_PER_PAGE]);

  // Calculate width ratio based on actual data points
  const chartWidthRatio = useMemo(() => {
    if (!chartData || !chartData.pageResultsCount) return 1;
    return Math.max(0.2, chartData.pageResultsCount / CHART_ITEMS_PER_PAGE);
  }, [chartData, CHART_ITEMS_PER_PAGE]);

  // Calculate hour boundary annotations
  const hourAnnotations = useMemo(() => {
    if (!chartData || !chartData.labels) return {};
    
    const annotations = {};
    const labels = chartData.labels;
    let lastHour = null;
    
    labels.forEach((label, index) => {
      if (label && label.hour !== undefined && label.hour !== lastHour) {
        annotations[`hour_${index}`] = {
          type: 'line',
          xMin: index,
          xMax: index,
          borderColor: 'rgba(0, 123, 255, 0.3)',
          borderWidth: 2,
          borderDash: [5, 5],
          label: {
            display: true,
            content: label.timeString,
            position: 'start',
            backgroundColor: 'rgba(0, 123, 255, 0.8)',
            color: 'white',
            font: {
              size: 10
            }
          }
        };
        lastHour = label.hour;
      }
    });
    
    return annotations;
  }, [chartData]);

  // Chart rendering effect
  useEffect(() => {
    if (!chartRef.current || !chartData) return;

    // Destroy existing chart
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    
    // Capture dotsPerHour for use in callbacks
    const currentDotsPerHour = dotsPerHour;
    
    chartInstanceRef.current = new Chart(ctx, {
      type: chartView,
      data: chartData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          datalabels: {
            display: false
          },
          tooltip: {
            enabled: true,
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleColor: '#fff',
            bodyColor: '#fff',
            borderColor: '#007bff',
            borderWidth: 1,
            cornerRadius: 8,
            callbacks: {
              title: (context) => {
                const label = context[0].label;
                if (label && typeof label === 'object' && label.gameNumber) {
                  return `Time: ${label.timeString} | Game #${label.gameNumber}`;
                }
                return context[0].label;
              },
              label: (context) => {
                return `Bust: ${context.parsed.y?.toFixed(2)}x`;
              }
            }
          },
          annotation: {
            annotations: {
              line1: {
                type: 'line',
                yMin: 2,
                yMax: 2,
                borderColor: 'rgba(0, 123, 255, 0.5)',
                borderWidth: 2,
                borderDash: [5, 5],
                label: {
                  display: true,
                  content: '2.0x',
                  position: 'end',
                  backgroundColor: 'rgba(0, 123, 255, 0.8)',
                  color: 'white'
                }
              },
              line2: {
                type: 'line',
                yMin: 10,
                yMax: 10,
                borderColor: 'rgba(255, 193, 7, 0.5)',
                borderWidth: 2,
                borderDash: [5, 5],
                label: {
                  display: true,
                  content: '10.0x',
                  position: 'end',
                  backgroundColor: 'rgba(255, 193, 7, 0.8)',
                  color: 'white'
                }
              },
              ...hourAnnotations
            }
          }
        },
        scales: {
          y: {
            type: 'logarithmic',
            min: 1,
            max: 150,
            grid: {
              color: 'rgba(0, 0, 0, 0.1)',
              borderColor: 'rgba(0, 0, 0, 0.2)'
            },
            ticks: {
              color: '#666',
              font: {
                size: 11
              }
            }
          },
          x: {
            title: {
              display: true,
              text: 'Game # / Time (GMT+9)',
              color: '#666',
              font: {
                size: 11,
                weight: 'bold'
              }
            },
            grid: {
              color: 'rgba(0, 0, 0, 0.1)',
              borderColor: 'rgba(0, 0, 0, 0.2)'
            },
            ticks: {
              color: '#666',
              font: {
                size: 9
              },
              padding: 10,
              maxRotation: 45,
              minRotation: 0,
              autoSkip: false,
              maxTicksLimit: 100,
              callback: function(value, index, ticks) {
                const label = this.getLabelForValue(value);
                if (!label || typeof label === 'string') return label;
                
                const labelData = label;
                const lines = [];
                
                // Check if game number is a multiple of 100
                if (labelData.gameNumber % 100 === 0) {
                  lines.push(`#${labelData.gameNumber}`);
                }
                
                // For time: find the closest hour boundary within reasonable distance
                // Check if this point is close to an hour boundary (within ~5% of currentDotsPerHour on either side)
                const gamesFromHourBoundary = labelData.gameNumber % currentDotsPerHour;
                const threshold = Math.max(5, Math.floor(currentDotsPerHour * 0.05));
                
                // Show time if we're at or near a whole hour
                if (gamesFromHourBoundary === 0 || 
                    gamesFromHourBoundary <= threshold || 
                    gamesFromHourBoundary >= (currentDotsPerHour - threshold)) {
                  
                  // Additionally check if this is a different hour from adjacent ticks
                  let showTime = true;
                  if (index > 0) {
                    const prevLabel = this.getLabelForValue(ticks[index - 1].value);
                    if (prevLabel && prevLabel.hour === labelData.hour && prevLabel.timeString) {
                      showTime = false;
                    }
                  }
                  
                  if (showTime) {
                    lines.push(labelData.timeString);
                  }
                }
                
                // Return array of lines for multi-line label
                return lines.length > 0 ? lines : '';
              }
            }
          }
        },
        interaction: {
          mode: 'nearest',
          axis: 'x',
          intersect: false
        }
      }
    });

    // Cleanup
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [chartData, chartView, dotsPerHour, hourAnnotations]);

  if (!gameResults || gameResults.length === 0) {
    return (
      <div style={{ 
        padding: '40px', 
        textAlign: 'center', 
        backgroundColor: '#f8f9fa',
        minHeight: '100vh'
      }}>
        <h2>Classic View - All Dots</h2>
        <p style={{ color: '#666', marginTop: '20px' }}>No game results available</p>
      </div>
    );
  }

  return (
    <div style={{ 
      padding: '20px', 
      backgroundColor: '#f8f9fa',
      minHeight: '100vh',
      fontFamily: 'Arial, sans-serif'
    }}>
      {/* Header Section */}
      <div style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        marginBottom: '20px',
        border: '1px solid #ddd'
      }}>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '15px',
          marginBottom: '20px'
        }}>
          <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 'bold', color: '#333' }}>
            Classic View - All Games
          </h2>
          
          {/* Controls */}
          <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap', alignItems: 'center' }}>
            {/* Chart View Toggle */}
            <button
              onClick={() => setChartView(chartView === 'line' ? 'bar' : 'line')}
              style={{
                padding: '8px 16px',
                backgroundColor: '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '12px',
                fontWeight: 'bold',
                transition: 'all 0.2s'
              }}
            >
              📊 {chartView === 'line' ? 'Bar Chart' : 'Line Chart'}
            </button>

            {/* Dots Per Hour Input */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <label htmlFor="dotsPerHour" style={{ fontSize: '12px', fontWeight: 'bold', color: '#495057' }}>
                Dots/Hour:
              </label>
              <input
                type="number"
                id="dotsPerHour"
                min="1"
                max="500"
                value={dotsPerHour}
                onChange={(e) => setDotsPerHour(parseInt(e.target.value) || 100)}
                style={{
                  width: '70px',
                  padding: '6px 8px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  textAlign: 'center',
                  fontSize: '12px'
                }}
                title="Number of dots that represent 1 hour"
              />
            </div>
          </div>
        </div>

        {/* Statistics */}
        {stats && (
          <div style={{ 
            display: 'flex', 
            gap: '20px', 
            justifyContent: 'center',
            flexWrap: 'wrap',
            padding: '15px',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#333' }}>
                {stats.total}
              </div>
              <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
                Total Dots
              </div>
            </div>
            
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#c82333' }}>
                {stats.reds} ({stats.redPercent}%)
              </div>
              <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
                Red (&lt;2.0x)
              </div>
            </div>
            
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#198754' }}>
                {stats.greens} ({stats.greenPercent}%)
              </div>
              <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
                Green (2.0x-9.99x)
              </div>
            </div>
            
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#e0a800' }}>
                {stats.golds} ({stats.goldPercent}%)
              </div>
              <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
                Gold (≥10.0x)
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Chart Section */}
      <div style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        border: '1px solid #ddd'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '15px',
          flexWrap: 'wrap',
          gap: '10px'
        }}>
          <h3 style={{ 
            margin: 0, 
            fontSize: '16px', 
            fontWeight: 'bold', 
            color: '#333' 
          }}>
            Bust Values Chart (500 per page)
          </h3>
          
          {/* Chart Pagination Controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <button
              onClick={() => setChartPage(Math.max(0, chartPage - 1))}
              disabled={chartPage === 0}
              style={{
                padding: '6px 12px',
                backgroundColor: chartPage === 0 ? '#e9ecef' : '#007bff',
                color: chartPage === 0 ? '#6c757d' : 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: chartPage === 0 ? 'not-allowed' : 'pointer',
                fontSize: '12px',
                fontWeight: 'bold'
              }}
            >
              ← Prev
            </button>
            
            <span style={{ fontSize: '12px', fontWeight: 'bold', color: '#495057' }}>
              Page {chartPage + 1} of {totalChartPages}
            </span>
            
            <button
              onClick={() => setChartPage(Math.min(totalChartPages - 1, chartPage + 1))}
              disabled={chartPage >= totalChartPages - 1}
              style={{
                padding: '6px 12px',
                backgroundColor: chartPage >= totalChartPages - 1 ? '#e9ecef' : '#007bff',
                color: chartPage >= totalChartPages - 1 ? '#6c757d' : 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: chartPage >= totalChartPages - 1 ? 'not-allowed' : 'pointer',
                fontSize: '12px',
                fontWeight: 'bold'
              }}
            >
              Next →
            </button>
            
            <button
              onClick={() => setChartPage(0)}
              style={{
                padding: '6px 12px',
                backgroundColor: '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '11px',
                fontWeight: 'bold'
              }}
            >
              First
            </button>
            
            <button
              onClick={() => setChartPage(totalChartPages - 1)}
              style={{
                padding: '6px 12px',
                backgroundColor: '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '11px',
                fontWeight: 'bold'
              }}
            >
              Last
            </button>
          </div>
        </div>
        
        <div style={{ 
          fontSize: '11px', 
          color: '#666', 
          marginBottom: '10px',
          textAlign: 'center'
        }}>
          Showing games {chartPage * CHART_ITEMS_PER_PAGE + 1} - {Math.min((chartPage + 1) * CHART_ITEMS_PER_PAGE, gameResults?.length || 0)} of {gameResults?.length || 0}
          {chartWidthRatio < 1 && (
            <span style={{ marginLeft: '10px', color: '#007bff' }}>
              ({Math.round(chartWidthRatio * 100)}% width)
            </span>
          )}
        </div>
        
        <div style={{ 
          height: '400px', 
          position: 'relative',
          width: `${chartWidthRatio * 100}%`,
          margin: '0 auto'
        }}>
          <canvas ref={chartRef}></canvas>
        </div>
      </div>
    </div>
  );
}

export default ClassicView;

