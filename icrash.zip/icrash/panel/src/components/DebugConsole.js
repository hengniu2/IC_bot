// components/DebugConsole.js
import React, { useState, useEffect, useRef } from 'react';
import { signalLogger } from '../services/signalLogger';

function DebugConsole() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [logs, setLogs] = useState([]);
  const logsEndRef = useRef(null);
  const maxLogs = 100;

  // Scroll to bottom when new logs arrive
  useEffect(() => {
    if (isExpanded && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isExpanded]);

  // Subscribe to signal logs
  useEffect(() => {
    const unsubscribe = signalLogger.subscribe((logEntry) => {
      setLogs(prevLogs => {
        const newLogs = [logEntry, ...prevLogs];
        // Keep only last maxLogs entries
        return newLogs.slice(0, maxLogs);
      });
    });

    return unsubscribe;
  }, []);

  const clearLogs = () => {
    setLogs([]);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'success':
        return '#4CAF50';
      case 'error':
        return '#f44336';
      case 'pending':
        return '#FF9800';
      default:
        return '#666';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return '✅';
      case 'error':
        return '❌';
      case 'pending':
        return '⏳';
      default:
        return '⚪';
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 10000,
        fontFamily: 'monospace',
        fontSize: '12px'
      }}
    >
      {/* Header Bar - Always Visible */}
      <div
        style={{
          background: '#1e1e1e',
          color: '#fff',
          padding: '8px 12px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          cursor: 'pointer',
          borderTop: '2px solid #333',
          boxShadow: '0 -2px 8px rgba(0,0,0,0.3)'
        }}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '14px' }}>{isExpanded ? '▼' : '▲'}</span>
          <span style={{ fontWeight: 'bold' }}>Debug Console</span>
          <span style={{ 
            background: logs.length > 0 ? '#4CAF50' : '#666',
            padding: '2px 6px',
            borderRadius: '3px',
            fontSize: '10px'
          }}>
            {logs.length} logs
          </span>
        </div>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          {isExpanded && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                clearLogs();
              }}
              style={{
                background: '#f44336',
                color: 'white',
                border: 'none',
                padding: '4px 8px',
                borderRadius: '3px',
                cursor: 'pointer',
                fontSize: '10px'
              }}
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div
          style={{
            background: '#1e1e1e',
            color: '#d4d4d4',
            maxHeight: '400px',
            overflowY: 'auto',
            borderTop: '1px solid #333'
          }}
        >
          {logs.length === 0 ? (
            <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
              No signals logged yet. Signals will appear here when bots trigger n8n webhooks.
            </div>
          ) : (
            <table
              style={{
                width: '100%',
                borderCollapse: 'collapse',
                fontSize: '11px'
              }}
            >
              <thead>
                <tr style={{ background: '#2d2d2d', position: 'sticky', top: 0, zIndex: 10 }}>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Time
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Status
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Bot
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Bet Value
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Message
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Game Hash
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Last Value
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Retry
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Webhook
                  </th>
                  <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #444', color: '#fff' }}>
                    Error
                  </th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log, index) => (
                  <tr
                    key={log.id}
                    style={{
                      background: index % 2 === 0 ? '#1e1e1e' : '#252525',
                      borderBottom: '1px solid #333'
                    }}
                  >
                    <td style={{ padding: '6px 8px', color: '#9cdcfe' }}>
                      {log.formattedTime}
                    </td>
                    <td style={{ padding: '6px 8px' }}>
                      <span style={{ color: getStatusColor(log.status) }}>
                        {getStatusIcon(log.status)} {log.status.toUpperCase()}
                      </span>
                    </td>
                    <td style={{ padding: '6px 8px', color: '#4ec9b0', fontWeight: 'bold' }}>
                      {log.botName}
                    </td>
                    <td style={{ padding: '6px 8px', color: '#dcdcaa' }}>
                      {log.betValue !== '' ? log.betValue : '-'}
                    </td>
                    <td style={{ padding: '6px 8px', color: '#ce9178', fontSize: '10px', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {log.message || '-'}
                    </td>
                    <td style={{ padding: '6px 8px', color: '#b5cea8' }}>
                      {log.gameHash ? (log.gameHash.length > 12 ? log.gameHash.slice(0, 12) + '...' : log.gameHash) : '-'}
                    </td>
                    <td style={{ padding: '6px 8px', color: '#8be9fd' }}>
                      {log.lastValue !== null && log.lastValue !== undefined ? `${log.lastValue.toFixed(2)}x` : '-'}
                    </td>
                    <td style={{ padding: '6px 8px', color: '#ce9178' }}>
                      {log.retryCount > 0 ? `#${log.retryCount}` : '-'}
                    </td>
                    <td style={{ padding: '6px 8px', color: '#6a9955', fontSize: '10px', maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {log.webhookUrl || '-'}
                    </td>
                    <td style={{ padding: '6px 8px', color: '#f48771', fontSize: '10px', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {log.error ? log.error : '-'}
                    </td>
                  </tr>
                ))}
                <tr ref={logsEndRef}></tr>
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}

export default DebugConsole;

