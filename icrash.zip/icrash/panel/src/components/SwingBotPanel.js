// components/SwingBotPanel.js
import React, { useState, useMemo, useRef } from 'react';
import EmailService from './EmailService';

// Use useRef for global state to persist across renders without triggering re-renders
const swingBotState = {
  globalIsActive: false,
  peakValue: null,
  peakDirection: null,
  peakIndex: null,
  adjustedPeakIndex: null
};

// Helper function to calculate peak values
const calculatePeakValues = (SbTrendResults128) => {
  const last15Values = SbTrendResults128.slice(-15);
  const maxValue = Math.max(...last15Values);
  const minValue = Math.min(...last15Values);
  const absMax = Math.abs(maxValue);
  const absMin = Math.abs(minValue);

  let peakValue, peakDirection;
  if (absMax >= absMin) {
    peakValue = maxValue;
    peakDirection = -1;
  } else {
    peakValue = minValue;
    peakDirection = 1;
  }

  const peakIndexInLast15 = last15Values.findIndex(value => value === peakValue);
  const peakIndex = SbTrendResults128.length - 15 + peakIndexInLast15 + 1;

  return { peakValue, peakDirection, peakIndex };
};

// Helper function to activate bot
const activateBot = (SbTrendResults128, activationReason, manualDirection = null) => {
  swingBotState.globalIsActive = true;
  
  let calculatedPeakValue, calculatedPeakDirection, calculatedPeakIndex;
  
  if (manualDirection) {
    // Use manual direction
    const last15Values = SbTrendResults128.slice(-15);
    if (manualDirection === 1) {
      calculatedPeakValue = Math.min(...last15Values);
    } else {
      calculatedPeakValue = Math.max(...last15Values);
    }
    calculatedPeakDirection = manualDirection;
    const peakIndexInLast15 = last15Values.findIndex(value => value === calculatedPeakValue);
    calculatedPeakIndex = SbTrendResults128.length - 15 + peakIndexInLast15 + 1;
  } else {
    // Auto-detect direction
    const peakData = calculatePeakValues(SbTrendResults128);
    calculatedPeakValue = peakData.peakValue;
    calculatedPeakDirection = peakData.peakDirection;
    calculatedPeakIndex = peakData.peakIndex;
  }
  
  swingBotState.peakValue = calculatedPeakValue;
  swingBotState.peakDirection = calculatedPeakDirection;
  swingBotState.peakIndex = calculatedPeakIndex;
  swingBotState.adjustedPeakIndex = calculatedPeakIndex - 1;

  const currentValue = SbTrendResults128[SbTrendResults128.length - 1];
  const previousValue = SbTrendResults128[SbTrendResults128.length - 2];
  const direction = currentValue - previousValue;

  return {
    globalIsActive: true,
    reason: activationReason + (manualDirection ? ` (Manual: ${manualDirection === 1 ? 'UP' : 'DOWN'})` : ''),
    currentValue,
    previousValue,
    peakValue: calculatedPeakValue,
    peakDirection: calculatedPeakDirection,
    directionChanges: [{index: SbTrendResults128.length - 1, from: SbTrendResults128.length - 2, to: SbTrendResults128.length - 1, direction, peakDirection: calculatedPeakDirection}],
    bidirectionChanges: [],
    isNewActivation: true
  };
};

// Helper function to analyze swing trends and determine bot status
const analyzeSwingTrend = (SbTrendResults128, swingLength = 20, manualDirection = null) => {
  if (!SbTrendResults128 || SbTrendResults128.length < swingLength) {
    Object.assign(swingBotState, {
      globalIsActive: false,
      peakValue: null,
      peakDirection: null,
      peakIndex: null,
      adjustedPeakIndex: null
    });
    return {
      globalIsActive: false,
      reason: 'Insufficient trend data',
      peakValue: null,
      peakDirection: null,
      currentValue: null,
      directionChanges: [],
      bidirectionChanges: []
    };
  }

  const currentValue = SbTrendResults128[SbTrendResults128.length - 1];
  const previousValue = SbTrendResults128[SbTrendResults128.length - 2];
  
  // Check active condition
  let activationReason = '';
  
  // Only check for activation if currently inactive
  if (!swingBotState.globalIsActive) {
    if (manualDirection) {
      // Manual direction activation
      if (manualDirection === -1 && previousValue > swingLength && (currentValue - previousValue < 0)) {
        activationReason = `Manual DOWN - Current value ${currentValue.toFixed(2)} > ${swingLength} and decreasing`;
        return activateBot(SbTrendResults128, activationReason, manualDirection);
      } else if (manualDirection === 1 && (previousValue < (swingLength * -1)) && (currentValue - previousValue > 0)) {
        activationReason = `Manual UP - Current value ${currentValue.toFixed(2)} < ${swingLength * -1} and increasing`;
        return activateBot(SbTrendResults128, activationReason, manualDirection);
      }
    } else {
      // Auto-detect activation
      if (previousValue > swingLength && (currentValue - previousValue < 0)) {
        activationReason = `Current value ${currentValue.toFixed(2)} > ${swingLength} and decreasing (from ${previousValue.toFixed(2)})`;
        return activateBot(SbTrendResults128, activationReason);
      } else if ((previousValue < (swingLength * -1)) && (currentValue - previousValue > 0)) {
        activationReason = `Current value ${currentValue.toFixed(2)} < ${swingLength * -1} and increasing (from ${previousValue.toFixed(2)})`;
        return activateBot(SbTrendResults128, activationReason);
      }
    }
    
    return {
      globalIsActive: false,
      reason: 'Active conditions not met',
      currentValue,
      previousValue,
      peakValue: null,
      peakDirection: null,
      directionChanges: [],
      bidirectionChanges: []
    };
  } else {
    // Check if peak value's absolute value is smaller than swingLength
    if (swingBotState.peakValue !== null && Math.abs(swingBotState.peakValue) < swingLength) {
      Object.assign(swingBotState, {
        globalIsActive: false,
        peakDirection: null,
        peakIndex: null,
        adjustedPeakIndex: null
      });
      return {
        globalIsActive: false,
        reason: `Peak value ${swingBotState.peakValue.toFixed(2)} absolute (${Math.abs(swingBotState.peakValue).toFixed(2)}) < swing length ${swingLength}`,
        currentValue,
        previousValue,
        peakValue: null,
        peakDirection: null,
        directionChanges: [],
        bidirectionChanges: []
      };
    }

    // Analyze direction changes from ADJUSTED peak to end
    const directionChanges = [];
    const bidirectionChanges = [];
    let shouldDeactivate = false;

    const startIndex = swingBotState.adjustedPeakIndex !== null ? swingBotState.adjustedPeakIndex : swingBotState.peakIndex;
    
    if (startIndex !== null && startIndex < SbTrendResults128.length - 1) {
      for (let i = startIndex; i < SbTrendResults128.length - 1; i++) {
        const currentVal = SbTrendResults128[i];
        const nextVal = SbTrendResults128[i + 1];
        const direction = nextVal - currentVal;
        
        if ((swingBotState.peakDirection === -1 && direction < 0) || (swingBotState.peakDirection === 1 && direction > 0)) {
          directionChanges.push({ index: i, from: currentVal, to: nextVal, direction, peakDirection: swingBotState.peakDirection });
        }
     
        if ((swingBotState.peakDirection === -1 && direction > 0) || (swingBotState.peakDirection === 1 && direction < 0)) {
          bidirectionChanges.push({ index: i, from: currentVal, to: nextVal, direction, peakDirection: swingBotState.peakDirection });
        }
      }

      if ((directionChanges.length < bidirectionChanges.length) || (directionChanges.length >= 4)) {
        shouldDeactivate = true;
        swingBotState.globalIsActive = false;      
      }
    }
    
    const reason = shouldDeactivate 
      ? `Deactivated: Matching (${directionChanges.length}) vs Opposite (${bidirectionChanges.length})`
      : (swingBotState.globalIsActive ? 'Active - monitoring for deactivation signals' : 'Inactive');

    return {
      globalIsActive: swingBotState.globalIsActive,
      reason,
      currentValue,
      previousValue,
      peakValue: swingBotState.peakValue,
      peakDirection: swingBotState.peakDirection,
      peakIndex: swingBotState.peakIndex,
      adjustedPeakIndex: swingBotState.adjustedPeakIndex,
      directionChanges,
      bidirectionChanges,
      last15Values: SbTrendResults128.slice(-15),
      shouldDeactivate
    };
  }
};

function SwingBotPanel({ SbTrendResults128, mainBot, lastGeneratedBust, botStats, swingLength = 20 }) {
  const [isMinimized, setIsMinimized] = useState(true);
  const [resetTrigger, setResetTrigger] = useState(0);
  const [manualDirection, setManualDirection] = useState(null); // null = auto, 1 = up, -1 = down
  const activationCountRef = useRef(0);

  const swingSignal = useMemo(() => {
    if (!SbTrendResults128 || SbTrendResults128.length === 0) {
      return { 
        globalIsActive: false, 
        amount: 0, 
        reason: 'No trend data available',
        details: {}
      };
    }

    const analysis = analyzeSwingTrend(SbTrendResults128, swingLength, manualDirection);
    const baseAmount = 10;
    
    if (analysis.globalIsActive && analysis.isNewActivation) {
      activationCountRef.current += 1;
    }
    
    return {
      globalIsActive: swingBotState.globalIsActive,
      amount: swingBotState.globalIsActive ? baseAmount : 0,
      reason: analysis.reason,
      details: analysis,
      activationCount: activationCountRef.current
    };
  }, [SbTrendResults128, swingLength, resetTrigger, manualDirection]);

  const executeSwingBet = () => {
    if (mainBot && swingSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(swingSignal.amount, lastGeneratedBust, 2.0);
      console.log('Swing bot bet executed:', result);
    }
  };

  const resetBot = () => {
    Object.assign(swingBotState, {
      globalIsActive: false,
      peakValue: null,
      peakDirection: null,
      peakIndex: null,
      adjustedPeakIndex: null
    });
    activationCountRef.current = 0;
    setResetTrigger(prev => prev + 1);
    console.log('Swing bot reset');
  };

  const handleManualDirection = (direction) => {
    setManualDirection(direction);
    // Reset bot when changing direction
    if (swingBotState.globalIsActive) {
      resetBot();
    }
  };

  const isActive = swingBotState.globalIsActive;
  const betAmount = isActive ? 10 : 0;
  const status = isActive ? 'Active' : 'Inactive';
  
  // Get swing direction - this is what determines the panel color
  const swingDirection = swingBotState.peakDirection || manualDirection;
  const directionSymbol = swingDirection === 1 ? '↗' : (swingDirection === -1 ? '↘' : '');
  const directionText = manualDirection === 1 ? 'UP' : manualDirection === -1 ? 'DOWN' : 'AUTO';

  // Determine panel colors based ONLY on swing direction
  const getPanelColors = () => {
    if (swingDirection === 1) {
      // UP direction - green
      return {
        background: '#e8f5e8',
        border: '#4CAF50',
        statusColor: '#4CAF50'
      };
    } else if (swingDirection === -1) {
      // DOWN direction - red
      return {
        background: '#ffeaea',
        border: '#ff4444',
        statusColor: '#ff4444'
      };
    } else {
      // No direction set - gray
      return {
        background: '#f8f9fa',
        border: '#6c757d',
        statusColor: '#666'
      };
    }
  };

  const panelColors = getPanelColors();

  return (
    <>
      {/* <EmailService 
        botStatus={isActive ? 'Active' : 'Inactive'}
        botType="Swing Bot"
      /> */}

      {(!SbTrendResults128 || SbTrendResults128.length === 0) ? (
        <div style={{
          position: 'fixed', top: '150px', right: '320px', background: '#f8f9fa',
          border: '2px solid #6c757d', borderRadius: '8px', padding: '15px',
          minWidth: '300px', zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>🔁 Swing Bot</h3>
            <button onClick={() => setIsMinimized(!isMinimized)} style={{ background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer', color: '#666' }}>
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>Waiting for trend data...</div>
        </div>
      ) : isMinimized ? (
        <div style={{
          position: 'fixed', top: '10px', right: '755px', 
          // CHANGED: Use white background for inactive status
          background: isActive ? panelColors.background : 'white',
          border: `2px solid ${isActive ? panelColors.border : '#6c757d'}`, 
          borderRadius: '8px', 
          padding: '10px 15px',
          zIndex: 1000, 
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)', 
          cursor: 'pointer'
        }} onClick={() => setIsMinimized(false)}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🔁</span>
            <span style={{ fontSize: '12px' }}>{isActive ? `$${betAmount}` : 'Inactive'}</span>
            {swingDirection && (
              <span style={{ 
                fontSize: '14px', 
                fontWeight: 'bold', 
                color: isActive ? panelColors.border : '#666'
              }}>
                {directionSymbol}
              </span>
            )}
            <span style={{ 
              fontSize: '8px', 
              color: manualDirection ? '#ff6b00' : '#666',
              background: manualDirection ? '#fff3e0' : 'transparent',
              padding: '1px 4px',
              borderRadius: '3px',
              border: manualDirection ? '1px solid #ffb74d' : 'none'
            }}>
              {directionText}
            </span>
            <span style={{ 
              fontSize: '10px', 
              color: isActive ? panelColors.statusColor : '#666', 
              fontWeight: 'bold' 
            }}>
              {isActive ? 'ACTIVE' : 'IDLE'}
            </span>
            <button onClick={(e) => { e.stopPropagation(); setIsMinimized(false); }} style={{ background: 'none', border: 'none', fontSize: '14px', cursor: 'pointer', color: '#666', marginLeft: 'auto' }}>
              +
            </button>
          </div>
        </div>
      ) : (
        <div style={{
          position: 'fixed', top: '360px', right: '320px', 
          background: panelColors.background,
          border: `2px solid ${panelColors.border}`, 
          borderRadius: '8px', 
          padding: '15px',
          minWidth: '350px', 
          zIndex: 3000, 
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)', 
          maxHeight: '500px', 
          overflow: 'auto'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>🔁Swing Bot</h3>
            <div>
              <button onClick={resetBot} style={{ background: '#ffc107', color: 'black', border: 'none', padding: '2px 6px', borderRadius: '3px', fontSize: '10px', marginRight: '5px', cursor: 'pointer' }} title="Reset Bot">
                Reset
              </button>
              <button onClick={() => setIsMinimized(true)} style={{ background: 'none', border: 'none', fontSize: '18px', cursor: 'pointer', color: '#666', padding: '2px 8px', borderRadius: '3px' }} title="Minimize">
                −
              </button>
            </div>
          </div>
          
          {/* Direction Control Section */}
          <div style={{ marginBottom: '15px', padding: '10px', background: '#f0f8ff', borderRadius: '6px', border: '1px solid #d1e7ff' }}>
            <div style={{ fontSize: '12px', fontWeight: 'bold', marginBottom: '8px' }}>Swing Direction:</div>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <button 
                onClick={() => handleManualDirection(null)}
                style={{ 
                  background: manualDirection === null ? '#4CAF50' : '#e0e0e0',
                  color: manualDirection === null ? 'white' : '#666',
                  border: 'none',
                  padding: '6px 12px',
                  borderRadius: '4px',
                  fontSize: '11px',
                  cursor: 'pointer',
                  fontWeight: 'bold'
                }}
              >
                AUTO
              </button>
              <button 
                onClick={() => handleManualDirection(1)}
                style={{ 
                  background: manualDirection === 1 ? '#4CAF50' : '#e0e0e0',
                  color: manualDirection === 1 ? 'white' : '#666',
                  border: 'none',
                  padding: '6px 12px',
                  borderRadius: '4px',
                  fontSize: '11px',
                  cursor: 'pointer',
                  fontWeight: 'bold'
                }}
              >
                ↗ UP
              </button>
              <button 
                onClick={() => handleManualDirection(-1)}
                style={{ 
                  background: manualDirection === -1 ? '#ff4444' : '#e0e0e0',
                  color: manualDirection === -1 ? 'white' : '#666',
                  border: 'none',
                  padding: '6px 12px',
                  borderRadius: '4px',
                  fontSize: '11px',
                  cursor: 'pointer',
                  fontWeight: 'bold'
                }}
              >
                ↘ DOWN
              </button>
            </div>
            <div style={{ fontSize: '10px', color: '#666', marginTop: '6px' }}>
              {manualDirection === null && 'Auto-detect swing direction'}
              {manualDirection === 1 && 'Manual UP swing - will activate on oversold conditions'}
              {manualDirection === -1 && 'Manual DOWN swing - will activate on overbought conditions'}
            </div>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {status}</strong></div>
            <div>Bet Amount: <strong>${betAmount}</strong></div>
            <div>Reason: {swingSignal.reason}</div>
            <div>Global State: <strong>{isActive ? 'ACTIVE' : 'INACTIVE'}</strong></div>
            <div>Activations: <strong>{swingSignal.activationCount}</strong></div>
            
            {swingSignal.details.currentValue !== undefined && (
              <div style={{ marginTop: '8px', padding: '6px', background: '#e3f2fd', borderRadius: '4px', border: '1px solid #bbdefb' }}>
                <div style={{ fontSize: '11px', fontWeight: 'bold' }}>Current Trend Analysis:</div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Current: {swingSignal.details.currentValue.toFixed(2)}</div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Previous: {swingSignal.details.previousValue.toFixed(2)}</div>
                {swingSignal.details.isNewActivation && (
                  <div style={{ fontSize: '10px', fontFamily: 'monospace', color: '#28a745', fontWeight: 'bold' }}>🎯 NEW ACTIVATION</div>
                )}
                {isActive && swingSignal.details.peakValue !== null && (
                  <>
                    <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Peak Value: {swingSignal.details.peakValue.toFixed(2)}</div>
                    <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Peak Direction: 
                      <span style={{ 
                        color: swingSignal.details.peakDirection === 1 ? '#4CAF50' : '#ff4444',
                        fontWeight: 'bold',
                        marginLeft: '4px'
                      }}>
                        {swingSignal.details.peakDirection === 1 ? '↗ UP (+1)' : '↘ DOWN (-1)'}
                      </span>
                    </div>
                    <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Peak Index: {swingSignal.details.peakIndex}</div>
                    <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Adjusted Peak Index: {swingSignal.details.adjustedPeakIndex}</div>
                    <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Peak Absolute: {Math.abs(swingSignal.details.peakValue).toFixed(2)}</div>
                  </>
                )}
              </div>
            )}

            {isActive && swingSignal.details.directionChanges && (
              <div style={{ marginTop: '8px', padding: '6px', background: '#fff3cd', borderRadius: '4px', border: '1px solid #ffeaa7' }}>
                <div style={{ fontSize: '11px', fontWeight: 'bold' }}>Direction Analysis:</div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Matching Direction Changes: <strong>{swingSignal.details.directionChanges.length}</strong></div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace' }}>Opposite Direction Changes: <strong>{swingSignal.details.bidirectionChanges ? swingSignal.details.bidirectionChanges.length : 0}</strong></div>
                <div style={{ fontSize: '10px', fontFamily: 'monospace', marginTop: '4px' }}>
                  Deactivation Condition: {(swingSignal.details.directionChanges.length <= swingSignal.details.bidirectionChanges.length) || (swingSignal.details.directionChanges.length >= 4) 
                    ? 'MET' : 'NOT MET'}
                </div>
                
                {swingSignal.details.directionChanges.length > 0 && (
                  <>
                    <div style={{ fontSize: '10px', fontWeight: 'bold', marginTop: '6px' }}>Matching Changes:</div>
                    {swingSignal.details.directionChanges.slice(0, 3).map((change, index) => (
                      <div key={index} style={{ fontSize: '9px', fontFamily: 'monospace', marginTop: '2px' }}>
                        Change {index + 1}: {change.from.toFixed(2)} → {change.to.toFixed(2)} (dir: {change.direction.toFixed(2)})
                      </div>
                    ))}
                    {swingSignal.details.directionChanges.length > 3 && (
                      <div style={{ fontSize: '9px', color: '#666', fontStyle: 'italic' }}>... and {swingSignal.details.directionChanges.length - 3} more</div>
                    )}
                  </>
                )}

                {swingSignal.details.bidirectionChanges && swingSignal.details.bidirectionChanges.length > 0 && (
                  <>
                    <div style={{ fontSize: '10px', fontWeight: 'bold', marginTop: '6px' }}>Opposite Changes:</div>
                    {swingSignal.details.bidirectionChanges.slice(0, 3).map((change, index) => (
                      <div key={index} style={{ fontSize: '9px', fontFamily: 'monospace', marginTop: '2px' }}>
                        Change {index + 1}: {change.from.toFixed(2)} → {change.to.toFixed(2)} (dir: {change.direction.toFixed(2)})
                      </div>
                    ))}
                    {swingSignal.details.bidirectionChanges.length > 3 && (
                      <div style={{ fontSize: '9px', color: '#666', fontStyle: 'italic' }}>... and {swingSignal.details.bidirectionChanges.length - 3} more</div>
                    )}
                  </>
                )}
              </div>
            )}

            {isActive && (
              <button onClick={executeSwingBet} style={{ background: '#4CAF50', color: 'white', border: 'none', padding: '6px 12px', borderRadius: '4px', marginTop: '8px', cursor: 'pointer', fontSize: '12px' }}>
                Execute Bet ${betAmount}
              </button>
            )}
          </div>

          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>Activation Conditions:</strong></div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              {manualDirection === null && (
                <>
                  • Current value &gt; {swingLength} AND decreasing (DOWN), OR<br/>
                  • Current value &lt; {swingLength} AND increasing (UP)
                </>
              )}
              {manualDirection === 1 && (
                <>• Manual UP: Current value &lt; {swingLength * -1} AND increasing</>
              )}
              {manualDirection === -1 && (
                <>• Manual DOWN: Current value &gt; {swingLength} AND decreasing</>
              )}
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '6px' }}><strong>Deactivation:</strong> Matching ≤ Opposite OR Matching ≥ 4</div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}><strong>OR:</strong> Peak absolute value &lt; {swingLength}</div>
          </div>

          {botStats && (
            <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export default SwingBotPanel;