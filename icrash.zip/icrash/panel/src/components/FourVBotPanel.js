// components/FourVBotPanel.js
import React, { useState, useMemo, useRef } from 'react';
import EmailService from './EmailService';

// Use useRef for global state to persist across renders without triggering re-renders
const fourVBotState = {
  globalIsActive: false,
  patternFound: false
};

// Helper function to generate binary stream from game results (only need 9 games)
const generateBinaryStream = (gameResults, length = 9) => {
  if (!gameResults || gameResults.length < length) return [];
  
  const lastGames = gameResults.slice(0, length).reverse();
  return lastGames.map(result => {
    const bust = result.bust;
    if (bust > 4 || (bust >= 1.5 && bust <= 2)) {
      return 1;
    } else {
      return 0;
    }
  });
};

// Target pattern we're looking for
const TARGET_PATTERN = [0, 0, 0, 0, 0, 0, 1, 0, 0];

// Helper function to analyze binary stream and determine bot status
const analyzeBinaryPattern = (gameResults) => {
  if (!gameResults || gameResults.length < 9) {
    Object.assign(fourVBotState, {
      globalIsActive: false,
      patternFound: false
    });
    return {
      globalIsActive: false,
      reason: 'Insufficient game data (need at least 9 games)',
      binaryStream: [],
      patternMatch: false
    };
  }

  const binaryStream = generateBinaryStream(gameResults, 9);
  const patternMatch = binaryStream.length === 9 && 
    binaryStream.every((bit, index) => bit === TARGET_PATTERN[index]);
  
  // Bot activates when pattern is found
  if (patternMatch && !fourVBotState.globalIsActive) {
    Object.assign(fourVBotState, {
      globalIsActive: true,
      patternFound: true
    });
    
    return {
      globalIsActive: true,
      reason: 'Pattern "000000100" detected in last 9 games',
      binaryStream,
      patternMatch: true,
      isNewActivation: true
    };
  }
  
  // If pattern is no longer found, deactivate bot
  if (!patternMatch && fourVBotState.globalIsActive) {
    Object.assign(fourVBotState, {
      globalIsActive: false,
      patternFound: false
    });
    
    return {
      globalIsActive: false,
      reason: 'Pattern "000000100" no longer detected',
      binaryStream,
      patternMatch: false
    };
  }
  
  // If pattern is still found and bot is active
  if (patternMatch && fourVBotState.globalIsActive) {
    return {
      globalIsActive: true,
      reason: 'Pattern "000000100" active',
      binaryStream,
      patternMatch: true
    };
  }
  
  // Default inactive state
  return {
    globalIsActive: false,
    reason: 'Pattern "000000100" not detected',
    binaryStream,
    patternMatch: false
  };
};

function FourVBotPanel({ gameResults, mainBot, lastGeneratedBust, botStats }) {
  const [isMinimized, setIsMinimized] = useState(true);
  const [resetTrigger, setResetTrigger] = useState(0);
  const activationCountRef = useRef(0);

  const fourVSignal = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return { 
        globalIsActive: false, 
        amount: 0, 
        reason: 'No game data available',
        details: {}
      };
    }

    const analysis = analyzeBinaryPattern(gameResults);
    const baseAmount = 10;
    
    if (analysis.globalIsActive && analysis.isNewActivation) {
      activationCountRef.current += 1;
    }
    
    return {
      globalIsActive: fourVBotState.globalIsActive,
      amount: fourVBotState.globalIsActive ? baseAmount : 0,
      reason: analysis.reason,
      details: analysis,
      activationCount: activationCountRef.current
    };
  }, [gameResults, resetTrigger]);

  const executeFourVBet = () => {
    if (mainBot && fourVSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(fourVSignal.amount, lastGeneratedBust, 2.0);
      console.log('4V bot bet executed:', result);
    }
  };

  const resetBot = () => {
    Object.assign(fourVBotState, {
      globalIsActive: false,
      patternFound: false
    });
    activationCountRef.current = 0;
    setResetTrigger(prev => prev + 1);
    console.log('4V bot reset');
  };

  const isActive = fourVBotState.globalIsActive;
  const betAmount = isActive ? 10 : 0;
  const status = isActive ? 'Active' : 'Inactive';

  return (
    <>
      <EmailService 
        botStatus={isActive ? 'Active' : 'Inactive'}
        botType="4V Bot"
      />

      {(!gameResults || gameResults.length === 0) ? (
        <div style={{
          position: 'fixed', top: '150px', right: '320px', background: '#f8f9fa',
          border: '2px solid #6c757d', borderRadius: '8px', padding: '15px',
          minWidth: '300px', zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>4️⃣V 4V Bot</h3>
            <button onClick={() => setIsMinimized(!isMinimized)} style={{ background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer', color: '#666' }}>
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>Waiting for game data...</div>
        </div>
      ) : isMinimized ? (
        <div style={{
          position: 'fixed', top: '10px', right: '980px', background: isActive ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${isActive ? '#4CAF50' : '#6c757d'}`, borderRadius: '8px', padding: '10px 15px',
          zIndex: 1000, boxShadow: '0 4px 12px rgba(0,0,0,0.1)', cursor: 'pointer'
        }} onClick={() => setIsMinimized(false)}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>4️⃣V</span>
            <span style={{ fontSize: '12px' }}>{isActive ? `$${betAmount}` : 'Inactive'}</span>
            <span style={{ fontSize: '10px', color: isActive ? '#4CAF50' : '#666', fontWeight: 'bold' }}>
              {isActive ? 'ACTIVE' : 'IDLE'}
            </span>
            <button onClick={(e) => { e.stopPropagation(); setIsMinimized(false); }} style={{ background: 'none', border: 'none', fontSize: '14px', cursor: 'pointer', color: '#666', marginLeft: 'auto' }}>
              +
            </button>
          </div>
        </div>
      ) : (
        <div style={{
          position: 'fixed', top: '360px', right: '320px', background: isActive ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${isActive ? '#4CAF50' : '#6c757d'}`, borderRadius: '8px', padding: '15px',
          minWidth: '350px', zIndex: 3000, boxShadow: '0 4px 12px rgba(0,0,0,0.1)', maxHeight: '500px', overflow: 'auto'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>4️⃣V 4V Bot</h3>
            <div>
              <button onClick={resetBot} style={{ background: '#ffc107', color: 'black', border: 'none', padding: '2px 6px', borderRadius: '3px', fontSize: '10px', marginRight: '5px', cursor: 'pointer' }} title="Reset Bot">
                Reset
              </button>
              <button onClick={() => setIsMinimized(true)} style={{ background: 'none', border: 'none', fontSize: '18px', cursor: 'pointer', color: '#666', padding: '2px 8px', borderRadius: '3px' }} title="Minimize">
                −
              </button>
            </div>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {status}</strong></div>
            <div>Bet Amount: <strong>${betAmount}</strong></div>
            <div>Reason: {fourVSignal.reason}</div>
            <div>Global State: <strong>{isActive ? 'ACTIVE' : 'INACTIVE'}</strong></div>
            <div>Activations: <strong>{fourVSignal.activationCount}</strong></div>
            
            {fourVSignal.details.binaryStream && (
              <div style={{ marginTop: '8px', padding: '6px', background: '#e3f2fd', borderRadius: '4px', border: '1px solid #bbdefb' }}>
                <div style={{ fontSize: '11px', fontWeight: 'bold' }}>Binary Stream Analysis (Last 9 Games):</div>
                
                {/* Binary Stream Display */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '6px' }}>
                  <span style={{ fontSize: '10px', fontWeight: 'bold' }}>Stream:</span>
                  <div style={{ display: 'flex', gap: '2px', flexWrap: 'wrap' }}>
                    {fourVSignal.details.binaryStream.map((bit, index) => (
                      <div
                        key={index}
                        title={`Game ${index + 1}: ${bit} (Target: ${TARGET_PATTERN[index]})`}
                        style={{
                          width: '20px',
                          height: '20px',
                          borderRadius: '3px',
                          backgroundColor: bit === 1 ? '#28a745' : '#dc3545',
                          color: 'white',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '10px',
                          fontWeight: 'bold',
                          boxShadow: '0 1px 2px rgba(0,0,0,0.1)',
                          border: fourVSignal.details.patternMatch ? '2px solid #007bff' : '1px solid transparent',
                          position: 'relative',
                        }}
                      >
                        {bit}
                        {/* Underline for pattern matches */}
                        {fourVSignal.details.patternMatch && (
                          <div
                            style={{
                              position: 'absolute',
                              bottom: '-3px',
                              left: '0',
                              width: '100%',
                              height: '2px',
                              backgroundColor: '#007bff',
                            }}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Target Pattern Display */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '6px' }}>
                  <span style={{ fontSize: '10px', fontWeight: 'bold' }}>Target:</span>
                  <div style={{ display: 'flex', gap: '2px', flexWrap: 'wrap' }}>
                    {TARGET_PATTERN.map((bit, index) => (
                      <div
                        key={index}
                        style={{
                          width: '20px',
                          height: '20px',
                          borderRadius: '3px',
                          backgroundColor: '#6c757d',
                          color: 'white',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '10px',
                          fontWeight: 'bold',
                          opacity: 0.7,
                        }}
                      >
                        {bit}
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Pattern Match Status */}
                <div style={{ 
                  marginTop: '8px', 
                  padding: '4px', 
                  background: fourVSignal.details.patternMatch ? '#d4edda' : '#f8d7da', 
                  borderRadius: '3px', 
                  border: `1px solid ${fourVSignal.details.patternMatch ? '#c3e6cb' : '#f5c6cb'}`
                }}>
                  <div style={{ 
                    fontSize: '10px', 
                    fontWeight: 'bold', 
                    color: fourVSignal.details.patternMatch ? '#155724' : '#721c24' 
                  }}>
                    {fourVSignal.details.patternMatch ? '🎯 PATTERN MATCH!' : '❌ PATTERN NOT MATCHED'}
                  </div>
                  <div style={{ fontSize: '9px', fontFamily: 'monospace' }}>
                    Current: [{fourVSignal.details.binaryStream.join(', ')}]
                  </div>
                  <div style={{ fontSize: '9px', fontFamily: 'monospace' }}>
                    Target:  [{TARGET_PATTERN.join(', ')}]
                  </div>
                </div>
                
                {fourVSignal.details.isNewActivation && (
                  <div style={{ fontSize: '10px', fontFamily: 'monospace', color: '#28a745', fontWeight: 'bold', marginTop: '4px' }}>
                    🚀 NEW ACTIVATION TRIGGERED
                  </div>
                )}
              </div>
            )}

            {isActive && (
              <button onClick={executeFourVBet} style={{ background: '#4CAF50', color: 'white', border: 'none', padding: '6px 12px', borderRadius: '4px', marginTop: '8px', cursor: 'pointer', fontSize: '12px' }}>
                Execute Bet ${betAmount}
              </button>
            )}
          </div>

          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>Activation Condition:</strong></div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              • Exact match with pattern <strong>"000000100"</strong> in last 9 games
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '6px' }}><strong>Binary Rules:</strong></div>
            <div style={{ fontSize: '9px', color: '#666' }}>• 1 = bust &gt; 4 OR (bust ≥ 1.5 AND bust ≤ 2)</div>
            <div style={{ fontSize: '9px', color: '#666' }}>• 0 = all other values</div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}><strong>Deactivation:</strong> Pattern no longer matches</div>
          </div>

          {botStats && (
            <div style={{ marginTop: '1010px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export default FourVBotPanel;