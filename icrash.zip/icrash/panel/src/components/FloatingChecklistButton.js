import React, { useState } from 'react';

function FloatingChecklistButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [items, setItems] = useState([
    { id: 1, text: 'Down in Moon Graph', checked: false },
    { id: 2, text: 'Need Swing', checked: false },
    { id: 3, text: 'Need User Base', checked: false }
  ]);

  const toggleChecklist = () => {
    setIsOpen(!isOpen);
  };

  const toggleItem = (itemId) => {
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId
          ? { ...item, checked: !item.checked }
          : item
      )
    );
  };

  // Check if all items are checked
  const allChecked = items.every(item => item.checked);
  const buttonColor = allChecked ? '#007bff' : '#dc3545'; // Blue when all checked, Red otherwise
  const hoverColor = allChecked ? '#0056b3' : '#c82333'; // Darker blue/red on hover

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={toggleChecklist}
        style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          width: '60px',
          height: '60px',
          borderRadius: '50%',
          backgroundColor: buttonColor,
          color: 'white',
          border: 'none',
          cursor: 'pointer',
          fontSize: '24px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.3s ease',
          transform: isOpen ? 'rotate(45deg)' : 'rotate(0deg)'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = hoverColor;
          e.currentTarget.style.transform = isOpen ? 'rotate(45deg) scale(1.1)' : 'scale(1.1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = buttonColor;
          e.currentTarget.style.transform = isOpen ? 'rotate(45deg)' : 'rotate(0deg)';
        }}
        title={isOpen ? 'Close Checklists' : 'Open Checklists'}
      >
        {isOpen ? '×' : '✓'}
      </button>

      {/* Checklist Panel */}
      {isOpen && (
        <div
          style={{
            position: 'fixed',
            bottom: '100px',
            right: '20px',
            width: '320px',
            maxHeight: '500px',
            backgroundColor: 'white',
            borderRadius: '12px',
            boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
            zIndex: 999,
            padding: '20px',
            overflowY: 'auto',
            border: '2px solid #007bff'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <h3 style={{
            margin: '0 0 20px 0',
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#333',
            textAlign: 'center',
            borderBottom: '2px solid #007bff',
            paddingBottom: '10px'
          }}>
            Checklist
          </h3>

          <div style={{
            padding: '10px 0'
          }}>
            {items.map((item) => (
              <label
                key={item.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  marginBottom: '12px',
                  cursor: 'pointer',
                  padding: '10px',
                  borderRadius: '6px',
                  transition: 'background-color 0.2s',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#e9ecef';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <input
                  type="checkbox"
                  checked={item.checked}
                  onChange={() => toggleItem(item.id)}
                  style={{
                    marginRight: '12px',
                    width: '20px',
                    height: '20px',
                    cursor: 'pointer'
                  }}
                />
                <span
                  style={{
                    fontSize: '15px',
                    color: item.checked ? '#6c757d' : '#212529',
                    textDecoration: item.checked ? 'line-through' : 'none',
                    flex: 1,
                    fontWeight: item.checked ? 'normal' : '500'
                  }}
                >
                  {item.text}
                </span>
              </label>
            ))}
          </div>
        </div>
      )}
    </>
  );
}

export default FloatingChecklistButton;

