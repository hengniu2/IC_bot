// components/ThreeRedGBotPanel.js
import React, { useState, useMemo, useEffect, useRef } from 'react';
import EmailService from './EmailService';
import FireSignalService from './FireSignalService';
import { isBotEnabled } from '../utils/botControl';

// Helper function to find sequences of 3+ games with bust < 2x followed by value > 2x
const findLowSequencesFollowedByHigh = (bustValues) => {
  bustValues = bustValues.reverse();
  const sequences = [];
  let currentLowSequence = [];
  
  for (let i = 0; i < bustValues.length - 1; i++) {
    const currentBust = bustValues[i];
    const nextBust = bustValues[i + 1];
    
    // If current bust is < 2, add to current low sequence
    if (currentBust < 2) {
      currentLowSequence.push({ 
        index: i, 
        value: currentBust,
        gameNumber: i + 1
      });
    } else {
      // If we have a sequence of 3+ low busts and next value is > 2
      if (currentLowSequence.length >= 3 && currentBust > 2) {
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: i + 1,
          nextValue: currentBust,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2))
        });
      }
      // Reset the sequence
      currentLowSequence = [];
    }
  }
  
  // CRITICAL FIX: Check if the last (newest) element completes a sequence
  // This ensures immediate synchronization when new game data arrives
  const lastIndex = bustValues.length - 1;
  const lastBust = bustValues[lastIndex];
  
  if (lastBust !== undefined) {
    // If the last element is part of a low sequence (< 2.0)
    if (lastBust < 2) {
      // Add it to the current low sequence
      currentLowSequence.push({
        index: lastIndex,
        value: lastBust,
        gameNumber: lastIndex + 1
      });
      // Mark as incomplete since there's no next value yet
      if (currentLowSequence.length >= 3) {
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: 'N/A',
          nextValue: 'N/A',
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2)),
          incomplete: true
        });
      }
    } else {
      // If the last element is > 2.0, it might complete a sequence
      if (currentLowSequence.length >= 3 && lastBust > 2) {
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: lastIndex + 1,
          nextValue: lastBust,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2))
        });
      }
    }
  } else {
    // Fallback: If there's a sequence at the end but no last element to check
    if (currentLowSequence.length >= 3) {
      sequences.push({
        lowSequenceLength: currentLowSequence.length,
        startGame: currentLowSequence[0].gameNumber,
        endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
        nextGame: 'N/A',
        nextValue: 'N/A',
        lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2)),
        incomplete: true
      });
    }
  }
  
  return sequences;
};

function ThreeRedGBotPanel({ gameResults, mainBot, lastGeneratedBust, botStats, botConfig }) {
  const [isMinimized, setIsMinimized] = useState(true);
  const [fireSignalActive, setFireSignalActive] = useState(false);
  const [manualFireSignal, setManualFireSignal] = useState(false);
  
  // Track previous status to detect when bot becomes active
  const previousStatusRef = useRef(null);
  const previousBustRef = useRef(null);
  
  // Track consecutive red values (bust < 2.0) for fire signal trigger
  const consecutiveRedsRef = useRef(0);
  const waitingForThreeRedsRef = useRef(false);
  const firingSignalsRef = useRef(false);
  
  // Retry tracking
  const retryCountRef = useRef(0);
  const MAX_RETRIES = 3;
  const currentBetAmountRef = useRef(null); // Current bet amount for this retry
  
  // Track if round is in progress - once round starts, keep bot Active until round completes
  const roundInProgressRef = useRef(false);
  
  // Track the last game number that was part of a completed round (state so useMemo can react to it)
  // Sequences ending at or before this game number will be ignored for activation
  const [lastCompletedRoundGameNumber, setLastCompletedRoundGameNumber] = useState(null);
  
  // State for UI display (refs don't trigger re-renders)
  const [consecutiveRedsCount, setConsecutiveRedsCount] = useState(0);
  const [waitingForReds, setWaitingForReds] = useState(false);
  const [firingSignals, setFiringSignals] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [currentBetAmount, setCurrentBetAmount] = useState(null);
  
  // Effective status: combines sequence-based status with round-in-progress status
  const [effectiveStatus, setEffectiveStatus] = useState('Inactive');
  
  // Check if bot is enabled from control panel
  const botEnabled = isBotEnabled('threeRedG');
  
  // Get bet amount (click count for DoubleAmount) based on retry count (from Firebase config)
  // Note: The config values (v_1_1, v_2_1, v_3_1) are treated as CLICK COUNTS for DoubleAmount button
  // These will be passed directly to AHK script which clicks DoubleAmount that many times
  const getBetAmountForRetry = (retryNum) => {
    if (!botConfig) {
      return 0; // Default fallback - no clicks
    }
    
    // retryNum: 0 = first try (v_1_1), 1 = second try (v_2_1), 2 = third try (v_3_1)
    const betFieldMap = {
      0: 'v_1_1',
      1: 'v_2_1',
      2: 'v_3_1'
    };
    
    const fieldName = betFieldMap[retryNum];
    const clickCount = botConfig[fieldName];
    
    if (clickCount === undefined || clickCount === null) {
      return 0;
    }
    
    // Convert to number and ensure it's a valid non-negative integer
    const clickCountNum = Math.max(0, Math.floor(Number(clickCount)) || 0);
    
    return clickCountNum;
  };

  // Calculate sequences and bot signal
  const redThreeSignal = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return { 
        status: 'Inactive', 
        amount: 0, 
        reason: 'No game data available',
        sequences: []
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    const sequences = findLowSequencesFollowedByHigh(bustValues);
    
    // Filter out incomplete sequences
    let completeSequences = sequences.filter(seq => !seq.incomplete && seq.nextValue !== 'N/A');
    
    // If we have a completed round, exclude sequences that were used in that round
    // We track the last sequence's nextGame that was used for activation
    if (lastCompletedRoundGameNumber !== null) {
      const lastCompletedGame = lastCompletedRoundGameNumber;
      const beforeCount = completeSequences.length;
      completeSequences = completeSequences.filter(seq => {
        // Exclude sequences where nextGame <= lastCompletedGame
        // nextGame is the game number in the reversed array (1 = most recent)
        // So we exclude sequences that occurred at or before the completed round
        const shouldInclude = seq.nextGame > lastCompletedGame;
        return shouldInclude;
      });
    }
    
    // Get the last 2 complete sequences (after filtering)
    const lastTwoSequences = completeSequences.slice(-2);
    
    if (lastTwoSequences.length < 2) {
      return {
        status: 'Inactive',
        amount: 0,
        reason: `Need 2 complete sequences, found ${lastTwoSequences.length}`,
        sequences: lastTwoSequences
      };
    }

    // Check if both last 2 sequences have next values >= 2.7
    const bothAboveOrEqualThreshold = lastTwoSequences.every(seq => seq.nextValue >= 2.7);
    
    if (bothAboveOrEqualThreshold) {
      const betAmount = 10; // Base bet amount
      return {
        status: 'Active',
        amount: betAmount,
        reason: 'Last 2 consecutive sequences both have next values >= 2.7x',
        sequences: lastTwoSequences,
        sequenceData: {
          sequence1: {
            length: lastTwoSequences[0].lowSequenceLength,
            nextValue: lastTwoSequences[0].nextValue
          },
          sequence2: {
            length: lastTwoSequences[1].lowSequenceLength,
            nextValue: lastTwoSequences[1].nextValue
          }
        }
      };
    }

    return {
      status: 'Inactive',
      amount: 0,
      reason: `Not both last 2 sequences are >= 2.7x`,
      sequences: lastTwoSequences,
      sequenceData: {
        sequence1: {
          length: lastTwoSequences[0].lowSequenceLength,
          nextValue: lastTwoSequences[0].nextValue
        },
        sequence2: {
          length: lastTwoSequences[1].lowSequenceLength,
          nextValue: lastTwoSequences[1].nextValue
        }
      }
    };
  }, [gameResults, lastCompletedRoundGameNumber]); // Add lastCompletedRoundGameNumber as dependency
  
  // Calculate effective status: if round is in progress, keep Active regardless of sequence status
  // After round completion, ensure bot stays Inactive until truly new sequences appear
  useEffect(() => {
    if (roundInProgressRef.current) {
      // Round is in progress - keep status as Active
      if (effectiveStatus !== 'Active') {
        setEffectiveStatus('Active');
      }
    } else {
      // No round in progress - use sequence-based status
      // Sequences are already filtered to exclude completed rounds
      // If we just completed a round, the sequences should be filtered, so status should be Inactive
      setEffectiveStatus(redThreeSignal.status);
    }
  }, [redThreeSignal.status, effectiveStatus, lastCompletedRoundGameNumber]);

  // Effect to handle fire signal logic: wait for 3 sequential reds, then trigger until green
  useEffect(() => {
    // Don't process if bot is disabled
    if (!botEnabled) {
      setFireSignalActive(false);
      consecutiveRedsRef.current = 0;
      waitingForThreeRedsRef.current = false;
      firingSignalsRef.current = false;
      setConsecutiveRedsCount(0);
      setWaitingForReds(false);
      setFiringSignals(false);
      return;
    }
    
    const isActive = effectiveStatus === 'Active';
    const wasActive = previousStatusRef.current === 'Active';
    const bustChanged = previousBustRef.current !== lastGeneratedBust;
    
    // When bot becomes active, reset and start waiting for 3 sequential reds
    if (isActive && !wasActive) {
      setFireSignalActive(false);
      consecutiveRedsRef.current = 0;
      waitingForThreeRedsRef.current = true;
      firingSignalsRef.current = false;
      retryCountRef.current = 0; // Reset retry count
      setConsecutiveRedsCount(0);
      setWaitingForReds(true);
      setFiringSignals(false);
      setRetryCount(0);
      const betAmount = getBetAmountForRetry(0);
      currentBetAmountRef.current = betAmount;
      setCurrentBetAmount(betAmount);
      previousBustRef.current = lastGeneratedBust;
    }
    
    // When bot is active and new game data arrives (bust changed)
    if (isActive && bustChanged && lastGeneratedBust !== null) {
      const isRed = lastGeneratedBust < 2.0;
      const isGreen = lastGeneratedBust >= 2.0;
      
      // Phase 1: Waiting for 3 sequential reds
      if (waitingForThreeRedsRef.current) {
        if (isRed) {
          consecutiveRedsRef.current += 1;
          setConsecutiveRedsCount(consecutiveRedsRef.current);
          
          // Check if we have 3 sequential reds
          if (consecutiveRedsRef.current >= 3) {
            // Mark round as in progress - this will keep bot Active until round completes
            if (!roundInProgressRef.current) {
              roundInProgressRef.current = true;
              setEffectiveStatus('Active');
            }
            
            waitingForThreeRedsRef.current = false;
            firingSignalsRef.current = true;
            setWaitingForReds(false);
            setFiringSignals(true);
            // Set bet amount for this retry
            const betAmount = getBetAmountForRetry(retryCountRef.current);
            currentBetAmountRef.current = betAmount;
            setCurrentBetAmount(betAmount);
            // Trigger first fire signal IMMEDIATELY
            // Since fireSignalActive starts as false when bot activates, we can set it directly to true
            setFireSignalActive(true);
          }
        } else {
          // Green value resets the counter (but we're still in retry mode, so restart detection)
          consecutiveRedsRef.current = 0;
          setConsecutiveRedsCount(0);
        }
      }
      // Phase 2: Firing signals until green
      else if (firingSignalsRef.current) {
        if (isGreen) {
          // Last fire signal at green value
          setFireSignalActive(false);
          setTimeout(() => {
            setFireSignalActive(true);
          }, 0);
          
          // Check if green value >= 2.7 (success) or < 2.7 (fail)
          setTimeout(() => {
            if (lastGeneratedBust >= 2.7) {
              // SUCCESS: Green value >= 2.7
              
              // Round completed - mark the sequences as used by tracking the last sequence's nextGame
              // Get the most recent sequence's nextGame (the sequence that just completed)
              const lastSequence = redThreeSignal.sequences?.[redThreeSignal.sequences.length - 1];
              if (lastSequence && lastSequence.nextGame) {
                setLastCompletedRoundGameNumber(lastSequence.nextGame);
              } else {
                // Fallback: use the most recent game (game 1 in reversed array)
                setLastCompletedRoundGameNumber(1);
              }
              
              // Reset flags and force Inactive
              roundInProgressRef.current = false;
              setEffectiveStatus('Inactive');
              
              // Reset everything and end the round
              consecutiveRedsRef.current = 0;
              waitingForThreeRedsRef.current = false;
              firingSignalsRef.current = false;
              retryCountRef.current = 0;
              setConsecutiveRedsCount(0);
              setWaitingForReds(false);
              setFiringSignals(false);
              setRetryCount(0);
              setFireSignalActive(false);
              currentBetAmountRef.current = null;
              setCurrentBetAmount(null);
            } else {
              // FAIL: Green value < 2.7 but >= 2.0
              retryCountRef.current += 1;
              setRetryCount(retryCountRef.current);
              
              if (retryCountRef.current >= MAX_RETRIES) {
                // Max retries reached, give up
                
                // Round completed (failed) - mark sequences as used
                const lastSequence = redThreeSignal.sequences?.[redThreeSignal.sequences.length - 1];
                if (lastSequence && lastSequence.nextGame) {
                  setLastCompletedRoundGameNumber(lastSequence.nextGame);
                } else {
                  setLastCompletedRoundGameNumber(1);
                }
                
                // Reset flags and force Inactive
                roundInProgressRef.current = false;
                setEffectiveStatus('Inactive');
                
                consecutiveRedsRef.current = 0;
                waitingForThreeRedsRef.current = false;
                firingSignalsRef.current = false;
                retryCountRef.current = 0;
                setConsecutiveRedsCount(0);
                setWaitingForReds(false);
                setFiringSignals(false);
                setRetryCount(0);
                setFireSignalActive(false);
                currentBetAmountRef.current = null;
                setCurrentBetAmount(null);
              } else {
                // Retry: Restart detection of 3 sequential reds
                
                // CRITICAL FIX: Check if the current game (that just failed) is already red
                // If so, start counting from 1, otherwise start from 0
                const currentIsRed = lastGeneratedBust < 2.0;
                if (currentIsRed) {
                  consecutiveRedsRef.current = 1;
                  setConsecutiveRedsCount(1);
                } else {
                  consecutiveRedsRef.current = 0;
                  setConsecutiveRedsCount(0);
                }
                
                waitingForThreeRedsRef.current = true;
                firingSignalsRef.current = false;
                setWaitingForReds(true);
                setFiringSignals(false);
                setFireSignalActive(false);
                
                // Set bet amount for this retry immediately
                const betAmount = getBetAmountForRetry(retryCountRef.current);
                currentBetAmountRef.current = betAmount;
                setCurrentBetAmount(betAmount);
                
                // If we already have 3 reds (shouldn't happen, but handle edge case), trigger immediately
                if (consecutiveRedsRef.current >= 3) {
                  waitingForThreeRedsRef.current = false;
                  firingSignalsRef.current = true;
                  setWaitingForReds(false);
                  setFiringSignals(true);
                  setFireSignalActive(false);
                  setTimeout(() => setFireSignalActive(true), 10);
                }
              }
            }
          }, 100);
        } else {
          // Continue firing on each red value
          // Toggle to ensure FireSignalService detects change
          setFireSignalActive(false);
          setTimeout(() => {
            setFireSignalActive(true);
          }, 0);
        }
      }
      
      previousBustRef.current = lastGeneratedBust;
    }
    
    // When bot becomes inactive, reset everything
    if (!isActive && wasActive) {
      // Reset all flags when bot deactivates
      roundInProgressRef.current = false;
      setLastCompletedRoundGameNumber(null);
      
      setFireSignalActive(false);
      consecutiveRedsRef.current = 0;
      waitingForThreeRedsRef.current = false;
      firingSignalsRef.current = false;
      retryCountRef.current = 0;
      setConsecutiveRedsCount(0);
      setWaitingForReds(false);
      setFiringSignals(false);
      setRetryCount(0);
      currentBetAmountRef.current = null;
      setCurrentBetAmount(null);
      previousBustRef.current = null;
    }
    
    // Update previous status
    previousStatusRef.current = effectiveStatus;
  }, [effectiveStatus, lastGeneratedBust, botEnabled]);

  const executeRedThreeBet = () => {
    if (mainBot && redThreeSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
    }
  };

  const handleManualExecute = () => {
    if (!botEnabled) {
      return;
    }
    
    // Execute the bet
    if (mainBot && redThreeSignal.amount > 0 && lastGeneratedBust) {
      const result = mainBot.executeBet(redThreeSignal.amount, lastGeneratedBust, 2.0);
    }
    
    // Trigger manual firesignal
    setManualFireSignal(true);
    
    // Reset manual firesignal after a short delay
    setTimeout(() => {
      setManualFireSignal(false);
    }, 1000);
  };

  return (
    <>
      {/* Email Service Component - Always render, but only send emails when bot is enabled */}
      <EmailService 
        botStatus={effectiveStatus}
        botType="ThreeRedG Bot"
        botEnabled={botEnabled}
      />
      
      {/* Fire Signal Service Component - Only if bot is enabled */}
      {botEnabled && (
        <FireSignalService
          botName="ThreeRed"
          betValue={currentBetAmountRef.current ?? currentBetAmount ?? getBetAmountForRetry(retryCountRef.current) ?? 0}
          fireSignal={fireSignalActive || manualFireSignal}
          onFireSignal={() => {
            // For mainBot.executeBet, we need actual bet amount, but for AHK we pass click count
            // Since we don't know the base amount after InitializeAmount, we'll use a default for executeBet
            const clickCount = currentBetAmountRef.current ?? currentBetAmount ?? getBetAmountForRetry(retryCountRef.current) ?? 0;
            const betAmount = 10; // Placeholder for executeBet calculation
            if (mainBot && lastGeneratedBust && betAmount > 0) {
              const result = mainBot.executeBet(betAmount, lastGeneratedBust, 2.0);
            }
          }}
        />
      )}

      {/* Add loading state */}
      {(!gameResults || gameResults.length === 0) ? (
        <div style={{
          position: 'fixed',
          top: '120px',
          right: '320px',
          background: '#f8f9fa',
          border: '2px solid #6c757d',
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 1000,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🟢👤👤👤 ThreeRedG Bot
              {!botEnabled && <span style={{ fontSize: '12px', color: '#dc3545', marginLeft: '8px' }}>(DISABLED)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                cursor: 'pointer',
                color: '#666'
              }}
            >
              −
            </button>
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>
            Waiting for game data...
          </div>
        </div>
      ) : isMinimized ? (
        // Minimized state
        <div style={{
          position: 'fixed',
          top: '10px',
          right: '370px',
          background: effectiveStatus === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${effectiveStatus === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '10px 15px',
          zIndex: 1000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          cursor: 'pointer'
        }}
        onClick={() => setIsMinimized(false)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>🟢👤👤👤</span>
            <span style={{ fontSize: '12px' }}>
              {effectiveStatus === 'Active' ? `$${redThreeSignal.amount}` : 'Inactive'}
            </span>
            <span style={{ 
              fontSize: '10px', 
              color: effectiveStatus === 'Active' ? '#4CAF50' : '#666',
              fontWeight: 'bold'
            }}>
              {effectiveStatus === 'Active' ? 'ACTIVE' : 'IDLE'}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer',
                color: '#666',
                marginLeft: 'auto'
              }}
            >
              +
            </button>
          </div>
        </div>
      ) : (
        // Expanded state
        <div style={{
          position: 'fixed',
          top: '240px',
          right: '10px',
          background: effectiveStatus === 'Active' ? '#e8f5e8' : '#f8f9fa',
          border: `2px solid ${effectiveStatus === 'Active' ? '#4CAF50' : '#6c757d'}`,
          borderRadius: '8px',
          padding: '15px',
          minWidth: '300px',
          zIndex: 3000,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          maxHeight: '500px',
          overflow: 'auto'
        }}>
          {/* Header with minimize button */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h3 style={{ margin: '0', fontSize: '16px' }}>
              🟢 ThreeRedG Bot
              {!botEnabled && <span style={{ fontSize: '12px', color: '#dc3545', marginLeft: '8px' }}>(DISABLED)</span>}
            </h3>
            <button
              onClick={() => setIsMinimized(true)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '18px',
                cursor: 'pointer',
                color: '#666',
                padding: '2px 8px',
                borderRadius: '3px'
              }}
              title="Minimize"
            >
              −
            </button>
          </div>
          
          <div style={{ fontSize: '12px', lineHeight: '1.4' }}>
            <div><strong>Status: {effectiveStatus}</strong></div>
            <div>Bet Amount: <strong>${redThreeSignal.amount}</strong></div>
            <div>Reason: {redThreeSignal.reason}</div>
            
            {redThreeSignal.sequenceData && (
              <div style={{ marginTop: '8px', fontFamily: 'monospace', fontSize: '11px' }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence1.nextValue >= 2.7 ? '#f1f8e9' : '#ffebee',
                  borderRadius: '3px'
                }}>
                  <span>Seq 1 (L:{redThreeSignal.sequenceData.sequence1.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence1.nextValue >= 2.7 ? '#4CAF50' : '#f44336',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence1.nextValue.toFixed(2)}x
                  </span>
                </div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  padding: '4px',
                  background: redThreeSignal.sequenceData.sequence2.nextValue >= 2.7 ? '#f1f8e9' : '#ffebee',
                  borderRadius: '3px'
                }}>
                  <span>Seq 2 (L:{redThreeSignal.sequenceData.sequence2.length}):</span>
                  <span style={{ 
                    color: redThreeSignal.sequenceData.sequence2.nextValue >= 2.7 ? '#4CAF50' : '#f44336',
                    fontWeight: 'bold'
                  }}>
                    {redThreeSignal.sequenceData.sequence2.nextValue.toFixed(2)}x
                  </span>
                </div>
              </div>
            )}

            {/* Execute Button */}
            <div style={{ marginTop: '15px' }}>
              <button 
                onClick={handleManualExecute}
                style={{
                  background: effectiveStatus === 'Active' ? '#4CAF50' : '#2196F3',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  width: '100%'
                }}
              >
                {effectiveStatus === 'Active' ? '🚀 Execute & FireSignal' : '⚡ Manual Execute'} 
                ${redThreeSignal.amount}
              </button>
              
              <div style={{ 
                fontSize: '10px', 
                color: '#666', 
                marginTop: '8px',
                textAlign: 'center'
              }}>
                {effectiveStatus === 'Active' 
                  ? 'Waits for 3 sequential reds, then fires until green' 
                  : 'Manual execute (bot is currently inactive)'}
              </div>
              
              {waitingForReds && (
                <div style={{ 
                  fontSize: '10px', 
                  color: '#FF9800', 
                  marginTop: '4px',
                  textAlign: 'center',
                  fontWeight: 'bold'
                }}>
                  ⏳ Waiting for 3 sequential reds ({consecutiveRedsCount}/3)
                  {retryCount > 0 && (
                    <span style={{ display: 'block', marginTop: '2px', color: '#f44336' }}>
                      Retry {retryCount}/{MAX_RETRIES}
                    </span>
                  )}
                </div>
              )}
              
              {firingSignals && (
                <div style={{ 
                  fontSize: '10px', 
                  color: '#4CAF50', 
                  marginTop: '4px',
                  textAlign: 'center',
                  fontWeight: 'bold'
                }}>
                  🔥 FireSignal Active - Firing until green (bust ≥ 2.0)
                  {retryCount > 0 && (
                    <span style={{ display: 'block', marginTop: '2px', color: '#f44336' }}>
                      Retry {retryCount}/{MAX_RETRIES} | Bet: ${currentBetAmount || 'N/A'}
                    </span>
                  )}
                  {retryCount === 0 && currentBetAmount && (
                    <span style={{ display: 'block', marginTop: '2px' }}>
                      Bet: ${currentBetAmount}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Recent sequences info */}
          <div style={{ marginTop: '10px', fontSize: '10px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
            <div><strong>Last 2 Sequences Analysis:</strong></div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Looks for sequences of 3+ games &lt; 2x followed by &gt; 2x
            </div>
            <div style={{ fontSize: '9px', color: '#666' }}>
              Activates when last 2 sequences both have next values &gt;= 2.7x
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Success: green value &gt;= 2.7x | Fail: green value between 2.0x and 2.7x
            </div>
            <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>
              Then waits for 3 sequential reds (bust &lt; 2.0) before firing signals
            </div>
          </div>

          {botStats && (
            <div style={{ marginTop: '10px', fontSize: '11px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
              <div>Balance: <strong>${botStats.currentBalance}</strong></div>
              <div>Total Bets: {botStats.totalBets}</div>
              <div>Win Rate: {botStats.winRate}%</div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export default ThreeRedGBotPanel;


