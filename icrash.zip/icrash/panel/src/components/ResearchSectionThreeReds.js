// components/ResearchSection.js
import React, { useMemo, useState } from 'react';
import { generateThreeRedSyncSeries, calculateMaxPatternCounts } from '../utils/threeRedSyncSeries';

// Helper function to find sequences of 5+ games with bust < 2x followed by value > 2x
const findLowSequencesFollowedByHigh = (bustValues, analysisLength) => {
  // Apply length limit if specified
  let analysisValues = [...bustValues];
  if (analysisLength && analysisLength > 0) {
    analysisValues = bustValues.slice(0, analysisLength);
  }
  
  analysisValues = analysisValues.reverse();
  const sequences = [];
  let currentLowSequence = [];
  
  for (let i = 0; i < analysisValues.length - 1; i++) {
    const currentBust = analysisValues[i];
    const nextBust = analysisValues[i + 1];
    
    // If current bust is < 2, add to current low sequence
    if (currentBust < 2) {
      currentLowSequence.push({ 
        index: i, 
        value: currentBust,
        gameNumber: i + 1
      });
    } else {
      // If we have a sequence of 5+ low busts and next value is > 2
      if (currentLowSequence.length >= 3 && currentBust > 2) {
        // REVERSED: WIN (>=2.7) or HOLD (2-2.7)
        const resultType = currentBust >= 2.7 ? 'WIN' : 'HOLD';
        
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: i + 1,
          nextValue: currentBust,
          resultType: resultType,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2))
        });
      }
      // Reset the sequence
      currentLowSequence = [];
    }
  }
  
  // CRITICAL FIX: Check if the last (newest) element completes a sequence
  // This ensures immediate synchronization when new game data arrives
  const lastIndex = analysisValues.length - 1;
  const lastBust = analysisValues[lastIndex];
  
  if (lastBust !== undefined) {
    // If the last element is part of a low sequence (< 2.0)
    if (lastBust < 2) {
      // Add it to the current low sequence
      currentLowSequence.push({
        index: lastIndex,
        value: lastBust,
        gameNumber: lastIndex + 1
      });
      // Mark as incomplete since there's no next value yet
      if (currentLowSequence.length >= 3) {
        const resultType = 'INCOMPLETE';
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: 'N/A',
          nextValue: 'N/A',
          resultType: resultType,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2)),
          incomplete: true
        });
      }
    } else {
      // If the last element is > 2.0, it might complete a sequence
      if (currentLowSequence.length >= 3 && lastBust > 2) {
        // REVERSED: WIN (>=2.7) or HOLD (2-2.7)
        const resultType = lastBust >= 2.7 ? 'WIN' : 'HOLD';
        sequences.push({
          lowSequenceLength: currentLowSequence.length,
          startGame: currentLowSequence[0].gameNumber,
          endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
          nextGame: lastIndex + 1,
          nextValue: lastBust,
          resultType: resultType,
          lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2))
        });
      }
    }
  } else {
    // Fallback: If there's a sequence at the end but no last element to check
    if (currentLowSequence.length >= 3) {
      sequences.push({
        lowSequenceLength: currentLowSequence.length,
        startGame: currentLowSequence[0].gameNumber,
        endGame: currentLowSequence[currentLowSequence.length - 1].gameNumber,
        nextGame: 'N/A',
        nextValue: 'N/A',
        resultType: 'INCOMPLETE',
        lowSequenceValues: currentLowSequence.map(item => item.value.toFixed(2)),
        incomplete: true
      });
    }
  }
  return sequences;
};


// Calculate statistics for ThreeRedSyncSeries
const calculateThreeRedSyncSeriesStats = (binaryString) => {
  if (!binaryString || binaryString.length === 0) {
    return {
      total: 0,
      ones: 0,
      zeros: 0,
      patterns: []
    };
  }

  const ones = (binaryString.match(/1/g) || []).length;
  const zeros = (binaryString.match(/0/g) || []).length;
  const total = binaryString.length;

  // Define patterns to search for (sorted by length, longest first)
  const patternsToSearch = [
    '1000001',
    '100001',
    '10001',
    '1001',
    '011',
    '11',
    '00',
    '101',
    '010',
    '1',
    '0'
  ];

  const patternCounts = {};
  
  patternsToSearch.forEach(pattern => {
    let count = 0;
    let index = binaryString.indexOf(pattern);
    while (index !== -1) {
      count++;
      index = binaryString.indexOf(pattern, index + 1);
    }
    if (count > 0) {
      patternCounts[pattern] = count;
    }
  });

  // Sort patterns by length (longest first), then by count (highest first)
  const patterns = Object.entries(patternCounts)
    .map(([pattern, count]) => ({ pattern, count }))
    .sort((a, b) => {
      if (a.pattern.length !== b.pattern.length) {
        return b.pattern.length - a.pattern.length;
      }
      return b.count - a.count;
    });

  return {
    total,
    ones,
    zeros,
    patterns
  };
};

function ResearchSectionThreeReds({ gameResults }) {
  const [analysisLength, setAnalysisLength] = useState(2000);
  const [maxPatternCounts, setMaxPatternCounts] = useState(null);
  
  // Research calculations
  const researchData = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return {
        lowSequences: []
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    
    // Apply analysis length limit
    const limitedBustValues = analysisLength > 0 
      ? bustValues.slice(0, analysisLength)
      : bustValues;
    
    // Find sequences of 5+ games with bust < 2x followed by value > 2x
    const lowSequences = findLowSequencesFollowedByHigh(bustValues, analysisLength);
    
    // Generate ThreeRedSyncSeries
    const threeRedSyncSeriesResult = generateThreeRedSyncSeries(limitedBustValues);
    const threeRedSyncSeries = threeRedSyncSeriesResult.binaryString;
    const { p1, p11, p111 } = threeRedSyncSeriesResult;
    
    // Calculate statistics
    const stats = calculateThreeRedSyncSeriesStats(threeRedSyncSeries);
    
    return {
      lowSequences: lowSequences,
      threeRedSyncSeries: threeRedSyncSeries,
      stats: stats,
      p1: p1,
      p11: p11,
      p111: p111,
      limitedBustValues: limitedBustValues
    };
    // return {
    //   lowSequences: lowSequences.slice(-15) // Show top 15 sequences
    // };
  }, [gameResults, analysisLength]);

  const handleAnalysisLengthChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value > 0) {
      setAnalysisLength(value);
      // Reset max pattern counts when analysis length changes
      setMaxPatternCounts(null);
    }
  };

  const handleCalculateMaxPatterns = () => {
    if (!researchData.limitedBustValues) return;
    const maxPatterns = calculateMaxPatternCounts(researchData.limitedBustValues);
    setMaxPatternCounts(maxPatterns);
  };

  if (!gameResults || gameResults.length === 0) {
    return (
      <div style={{
        marginTop: '40px',
        padding: '20px',
        background: '#f8f9fa',
        borderRadius: '8px',
        border: '1px solid #dee2e6'
      }}>
        <h2>Research Section</h2>
        <p>No game data available for research.</p>
      </div>
    );
  }

  return (
    <div style={{
      marginTop: '40px',
      padding: '20px',
      background: '#f8f9fa',
      borderRadius: '8px',
      border: '1px solid #dee2e6'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2 style={{ margin: 0 }}>TR+</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <label htmlFor="analysisLengthInput" style={{ fontSize: '14px', fontWeight: 'bold' }}>
            Analysis Length:
          </label>
          <input
            type="number"
            id="analysisLengthInput"
            min="1"
            max="10000"
            value={analysisLength}
            onChange={handleAnalysisLengthChange}
            style={{
              width: '80px',
              padding: '5px 8px',
              border: '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '14px'
            }}
          />
          <span style={{ fontSize: '12px', color: '#6c757d' }}>
            games
          </span>
        </div>
      </div>

      <div style={{ 
        fontSize: '12px', 
        color: '#666', 
        background: '#fff', 
        padding: '10px', 
        borderRadius: '4px',
        marginBottom: '15px',
        border: '1px solid #ddd'
      }}>
        <strong>Analysis Info:</strong> Total games analyzed: {Math.min(gameResults.length, analysisLength)} | 
        Sequences found: {researchData.lowSequences.length} |
        Showing last 15 sequences
      </div>

      {/* ThreeRedSyncSeries Display */}
      <div style={{
        background: '#fff',
        padding: '20px',
        borderRadius: '8px',
        border: '2px solid #007bff',
        marginBottom: '20px'
      }}>
        <h3 style={{ margin: '0 0 15px 0', fontSize: '18px', color: '#007bff' }}>
          ThreeRedSyncSeries
        </h3>
        
        {/* Binary String Display */}
        <div style={{
          background: '#f8f9fa',
          padding: '15px',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #dee2e6',
          wordBreak: 'break-all',
          fontFamily: 'monospace',
          fontSize: '14px',
          maxHeight: '150px',
          overflow: 'auto'
        }}>
          <div style={{ marginBottom: '8px', fontSize: '12px', color: '#6c757d' }}>
            <strong>Binary Sequence:</strong> (newest → oldest, right → left)
          </div>
          <div style={{ color: '#212529' }}>
            {researchData.threeRedSyncSeries || '(empty)'}
          </div>
        </div>

        {/* Statistics */}
        {researchData.stats && researchData.stats.total > 0 && (
          <div style={{
            background: '#e7f3ff',
            padding: '15px',
            borderRadius: '6px',
            border: '1px solid #b3d9ff'
          }}>
            <div style={{ marginBottom: '10px', fontSize: '14px', fontWeight: 'bold' }}>
              Statistics:
            </div>
            
            <div style={{ marginBottom: '10px', fontSize: '13px' }}>
              <strong>Total:</strong> {researchData.stats.total} | 
              <strong style={{ color: '#28a745', marginLeft: '10px' }}>1s:</strong> {researchData.stats.ones} | 
              <strong style={{ color: '#dc3545', marginLeft: '10px' }}>0s:</strong> {researchData.stats.zeros}
            </div>
            
            <div style={{ marginBottom: '10px', fontSize: '13px', marginTop: '15px' }}>
              <div style={{ fontSize: '14px', fontWeight: 'bold', marginBottom: '8px' }}>
                Pattern Counts (scanning from right to left):
              </div>
              <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap', marginBottom: '15px' }}>
                <div>
                  <strong>p1:</strong> <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#007bff' }}>{researchData.p1 !== undefined ? researchData.p1 : 'N/A'}</span>
                  <div style={{ fontSize: '11px', color: '#6c757d', marginTop: '2px' }}>
                    (1s before first "11")
                  </div>
                </div>
                <div>
                  <strong>p11:</strong> <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#007bff' }}>{researchData.p11 !== undefined ? researchData.p11 : 'N/A'}</span>
                  <div style={{ fontSize: '11px', color: '#6c757d', marginTop: '2px' }}>
                    ("11"s before first "111")
                  </div>
                </div>
                <div>
                  <strong>p111:</strong> <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#007bff' }}>{researchData.p111 !== undefined ? researchData.p111 : 'N/A'}</span>
                  <div style={{ fontSize: '11px', color: '#6c757d', marginTop: '2px' }}>
                    ("111"s before first "1111")
                  </div>
                </div>
              </div>
              
              <div style={{ 
                marginTop: '15px', 
                padding: '10px', 
                background: '#fff3cd', 
                borderRadius: '6px', 
                border: '1px solid #ffc107' 
              }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center',
                  marginBottom: maxPatternCounts ? '8px' : '0'
                }}>
                  <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#856404' }}>
                    Maximum Pattern Counts (by removing end bytes):
                  </div>
                  <button
                    onClick={handleCalculateMaxPatterns}
                    style={{
                      padding: '6px 12px',
                      backgroundColor: '#ffc107',
                      color: '#856404',
                      border: '1px solid #ffc107',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                      fontSize: '12px'
                    }}
                  >
                    Calculate Max
                  </button>
                </div>
                {maxPatternCounts && (
                  <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap', marginTop: '8px' }}>
                    <div>
                      <strong>Max p1:</strong> <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#ff6b00' }}>{maxPatternCounts.maxP1}</span>
                      <div style={{ fontSize: '11px', color: '#856404', marginTop: '2px' }}>
                        (max 1s before "11")
                      </div>
                    </div>
                    <div>
                      <strong>Max p11:</strong> <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#ff6b00' }}>{maxPatternCounts.maxP11}</span>
                      <div style={{ fontSize: '11px', color: '#856404', marginTop: '2px' }}>
                        (max "11"s before "111")
                      </div>
                    </div>
                    <div>
                      <strong>Max p111:</strong> <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#ff6b00' }}>{maxPatternCounts.maxP111}</span>
                      <div style={{ fontSize: '11px', color: '#856404', marginTop: '2px' }}>
                        (max "111"s before "1111")
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {researchData.stats.patterns.length > 0 && (
              <div style={{ marginTop: '10px' }}>
                <div style={{ fontSize: '13px', fontWeight: 'bold', marginBottom: '8px' }}>
                  Pattern Counts:
                </div>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '10px',
                  fontSize: '12px'
                }}>
                  {researchData.stats.patterns.map((item, idx) => (
                    <div key={idx} style={{
                      background: '#fff',
                      padding: '6px 10px',
                      borderRadius: '4px',
                      border: '1px solid #007bff'
                    }}>
                      <strong>"{item.pattern}"</strong>: {item.count}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      
      {researchData.lowSequences.length > 0 ? (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
          gap: '15px',
          maxHeight: '500px',
          overflowY: 'auto',
          padding: '10px'
        }}>
          {researchData.lowSequences.map((sequence, index) => (
            <div key={index} style={{ 
              padding: '15px', 
              background: sequence.incomplete ? '#fff3cd' : 
                         sequence.resultType === 'WIN' ? '#d4edda' : 
                         sequence.resultType === 'HOLD' ? '#f8d7da' : '#e2e3e5',
              borderRadius: '8px',
              border: `2px solid ${sequence.incomplete ? '#ffeaa7' : 
                                sequence.resultType === 'WIN' ? '#c3e6cb' : 
                                sequence.resultType === 'HOLD' ? '#f5c6cb' : '#d6d8db'}`,
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <div style={{ marginBottom: '10px', fontSize: '16px', fontWeight: 'bold' }}>
                Sequence {index + 1}: {sequence.lowSequenceLength}
              </div>
              
              <div style={{ fontSize: '14px', marginBottom: '8px' }}>
                <strong>Games:</strong> {sequence.startGame} - {sequence.endGame}
              </div>            
    
              {!sequence.incomplete ? (
                <div style={{ fontSize: '14px', marginBottom: '8px' }}>
                  <strong>Next game ({sequence.nextGame}):</strong> 
                  <span style={{ 
                    color: sequence.resultType === 'WIN' ? '#28a745' : 
                           sequence.resultType === 'HOLD' ? '#dc3545' : '#6c757d',
                    fontWeight: 'bold',
                    marginLeft: '5px',
                    fontSize: '16px'
                  }}>
                    {sequence.nextValue.toFixed(2)}x - {sequence.resultType}
                  </span>
                </div>
              ) : (
                <div style={{ fontSize: '14px', color: '#856404', fontWeight: 'bold' }}>
                  ⚠️ No next value available (end of data)
                </div>
              )}
              
              <div style={{ 
                fontSize: '12px', 
                color: '#6c757d', 
                marginTop: '10px',
                padding: '8px',
                background: 'rgba(255,255,255,0.7)',
                borderRadius: '4px'
              }}>
                <strong>Low sequence values:</strong><br/>
                [{sequence.lowSequenceValues.join(', ')}]
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ 
          padding: '20px', 
          textAlign: 'center',
          background: 'white',
          borderRadius: '8px',
          border: '1px solid #dee2e6'
        }}>
          <p style={{ fontSize: '16px', color: '#6c757d' }}>
            No sequences of 5+ games &lt; 2x followed by &gt; 2x found in the current data.
          </p>
        </div>
      )}
    </div>
  );
}

export default ResearchSectionThreeReds;