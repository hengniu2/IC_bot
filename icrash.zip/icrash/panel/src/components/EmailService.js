// components/EmailService.js
import React, { useEffect, useRef, useCallback } from 'react';

// n8n Webhook URL for email service
// NOTE: Update the webhook path after creating the n8n workflow
// The webhook path can be found in the n8n workflow webhook node settings
// Default: http://localhost:5678/webhook/email-service
// After importing backup_email.json, update this with the actual webhook path
const EMAIL_WEBHOOK_URL = 'http://localhost:5678/webhook/email-service';

// Recipient Emails
const RECIPIENT_EMAILS =  
  [
    'itsbigdavid99@gmail.com'
  ];

function EmailService({ botStatus, botType, botEnabled = true }) {
  const previousStatusRef = useRef(null);
  const emailCooldownRef = useRef(0);
  const isInitialMountRef = useRef(true);

  // Log when component mounts/renders
  useEffect(() => {
    console.log(`[EmailService] ${botType} - ✅ Component mounted/rendered. Status: ${botStatus}, BotEnabled: ${botEnabled}`);
  }, [botType, botStatus, botEnabled]);

  const sendEmailNotification = useCallback(async (subject, message) => {
    // Cooldown to prevent spam (5 minutes)
    const now = Date.now();
    const timeSinceLastEmail = now - emailCooldownRef.current;
    if (timeSinceLastEmail < 5 * 60 * 1000) {
      const minutesRemaining = Math.ceil((5 * 60 * 1000 - timeSinceLastEmail) / (60 * 1000));
      console.log(`[EmailService] ${botType} - Email cooldown active. ${minutesRemaining} minute(s) remaining before next email can be sent.`);
      return;
    }

    console.log(`[EmailService] ${botType} - Attempting to send email notification via n8n webhook...`);

    try {
      // Prepare email HTML content
      const emailHtml = `
        <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4;">
          <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2 style="color: #4CAF50; margin-top: 0;">🚨 Trading Bot Alert</h2>
            <p><strong>Bot Type:</strong> ${botType}</p>
            <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
            <p>${message}</p>
            <hr style="margin: 20px 0;">
            <p style="color: #666; font-size: 12px;">
              This is an automated notification from your trading bot system.
            </p>
          </div>
        </div>
      `;

      // Send email data to n8n webhook (n8n will handle Resend API call server-side)
      const requestBody = {
        to: RECIPIENT_EMAILS,
        subject: subject,
        html: emailHtml
      };

      console.log(`[EmailService] ${botType} - Sending request to n8n webhook:`, EMAIL_WEBHOOK_URL);
      console.log(`[EmailService] ${botType} - Email payload:`, { 
        subject, 
        to: RECIPIENT_EMAILS
      });

      const response = await fetch(EMAIL_WEBHOOK_URL, {
        method: 'POST',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      console.log(`[EmailService] ${botType} - Response status:`, response.status, response.statusText);

      if (response.ok) {
        const result = await response.json();
        console.log(`[EmailService] ${botType} - ✅ Email notification sent successfully via n8n:`, result);
        emailCooldownRef.current = now;
      } else {
        const errorText = await response.text();
        let parsedError;
        try {
          parsedError = JSON.parse(errorText);
        } catch {
          parsedError = errorText;
        }
        
        console.error(`[EmailService] ${botType} - ❌ Failed to send email via n8n:`, {
          status: response.status,
          statusText: response.statusText,
          error: parsedError
        });

        if (response.status === 404) {
          console.error(`[EmailService] ${botType} - ⚠️ n8n webhook not found. Make sure the email workflow is imported and active in n8n.`);
        } else if (response.status === 0) {
          console.error(`[EmailService] ${botType} - ⚠️ CORS error - check n8n webhook CORS settings.`);
        }
      }
    } catch (error) {
      const isCorsError = error.message.includes('CORS') || 
                         error.message.includes('Failed to fetch') ||
                         error.message.includes('NetworkError') ||
                         error.name === 'TypeError';
      
      console.error(`[EmailService] ${botType} - ❌ Error sending email:`, error);
      console.error(`[EmailService] ${botType} - Error details:`, {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      
      if (isCorsError) {
        console.error(`[EmailService] ${botType} - ⚠️ CORS ERROR DETECTED!`);
        console.error(`[EmailService] ${botType} - Check that n8n workflow has CORS headers configured in "Respond to Webhook" node.`);
        console.error(`[EmailService] ${botType} - Also verify n8n is running and the email workflow is active.`);
      }
    }
  }, [botType]);

  useEffect(() => {
    // Skip on initial mount to avoid sending email if bot is already Active when component mounts
    if (isInitialMountRef.current) {
      console.log(`[EmailService] ${botType} - Initial mount. Current status: ${botStatus}. Will track changes from now on.`);
      previousStatusRef.current = botStatus;
      isInitialMountRef.current = false;
      return;
    }

    // Skip if bot is disabled
    if (!botEnabled) {
      console.log(`[EmailService] ${botType} - Bot is disabled. Skipping email logic.`);
      previousStatusRef.current = botStatus;
      return;
    }

    // Debug logging
    console.log(`[EmailService] ${botType} - Status changed:`, {
      currentStatus: botStatus,
      previousStatus: previousStatusRef.current,
      willSendEmail: botStatus === 'Active' && previousStatusRef.current !== 'Active',
      botEnabled: botEnabled
    });

    // Only send email when status changes to "Active" (not on initial mount)
    if (botStatus === 'Active' && previousStatusRef.current !== 'Active') {
      console.log(`[EmailService] ${botType} - ✅ Status transition detected: ${previousStatusRef.current} → Active. Attempting to send email...`);
      sendEmailNotification(
        `🤖 ${botType} - ACTIVE iCrash SIGNAL`,
        `Enjoy`
      );
    } else if (botStatus === 'Active' && previousStatusRef.current === 'Active') {
      console.log(`[EmailService] ${botType} - Bot is already Active. No email sent (only sends on status transition).`);
    } else if (botStatus !== 'Active') {
      console.log(`[EmailService] ${botType} - Bot status is "${botStatus}". No email sent.`);
    }

    // Update previous status
    previousStatusRef.current = botStatus;
  }, [botStatus, botType, botEnabled, sendEmailNotification]);

  // This component doesn't render anything visible
  return null;
}

export default EmailService;
