// components/ResearchSectionNeutralReds.js
import React, { useMemo, useState, useRef, useEffect } from 'react';
import Chart from 'chart.js/auto';

// Helper function to create ternary data (2 for strong blue, 1 for neutral reds, 0 for others)
const createTernaryData = (bustValues, analysisLength) => {
  let analysisValues = [...bustValues];
  if (analysisLength && analysisLength > 0) {
    analysisValues = bustValues.slice(0, analysisLength);
  }
  
  analysisValues = analysisValues.reverse();
  
  return analysisValues.map((bust, index) => ({
    gameId: index + 1,
    bustValue: bust,
    // 2 = Strong Blue (≥4.0), 1 = Neutral Red (1.5-2.0), 0 = Other
    category: bust >= 4.0 ? 2 : (bust >= 1.5 && bust < 2.0 ? 1 : 0)
  }));
};

// Helper function to calculate neutral red game ID differences and sum series
const calculateNeutralRedDifferences = (bustValues, sumLength, analysisLength) => {
  let analysisValues = [...bustValues];
  if (analysisLength && analysisLength > 0) {
    analysisValues = bustValues.slice(0, analysisLength);
  }
  
  analysisValues = analysisValues.reverse();
  
  const neutralRedGames = [];
  let lastNeutralRedId = null;
  
  // Find all neutral red games and calculate differences
  analysisValues.forEach((bust, index) => {
    const gameId = index + 1;
    if (bust >= 1.5 && bust < 2.0) {
      const difference = lastNeutralRedId !== null ? gameId - lastNeutralRedId : 0;
      neutralRedGames.push({
        gameId: gameId,
        bustValue: bust,
        difference: difference,
        isFirst: lastNeutralRedId === null
      });
      lastNeutralRedId = gameId;
    }
  });
  
  // Calculate sum series - only create series if we have enough neutral red games
  const sumSeries = [];
  if (sumLength > 0 && neutralRedGames.length >= sumLength) {
    for (let i = 0; i <= neutralRedGames.length - sumLength; i++) {
      const slice = neutralRedGames.slice(i, i + sumLength);
      const sum = slice.reduce((total, game) => total + game.difference, 0);
      const lastDifference = slice[slice.length - 1].difference;
      
      sumSeries.push({
        startGame: slice[0].gameId,
        endGame: slice[slice.length - 1].gameId,
        sum: sum,
        lastDifference: lastDifference,
        isLastValueSpecial: lastDifference === 1 || lastDifference === 2,
        games: slice.map(game => ({
          gameId: game.gameId,
          difference: game.difference
        }))
      });
    }
  }
  
  return {
    neutralRedGames,
    sumSeries
  };
};

// Helper function to calculate "Other" (category 0) series lengths
const calculateOtherSeriesLengths = (ternaryData) => {
  if (!ternaryData || ternaryData.length === 0) return [];
  
  const seriesLengths = [];
  let currentSeriesLength = 0;
  let seriesStartGame = 0;
  
  ternaryData.forEach((item, index) => {
    if (item.category === 0) {
      // This is an "Other" value
      if (currentSeriesLength === 0) {
        // Start of a new series
        seriesStartGame = item.gameId;
      }
      currentSeriesLength++;
    } else {
      // This is not an "Other" value - end current series if it exists
      if (currentSeriesLength > 0) {
        seriesLengths.push({
          startGame: seriesStartGame,
          endGame: ternaryData[index - 1].gameId,
          length: currentSeriesLength,
          games: ternaryData.slice(index - currentSeriesLength, index)
        });
        currentSeriesLength = 0;
      }
    }
  });
  
  // Add the last series if it ends at the last game
  if (currentSeriesLength > 0) {
    seriesLengths.push({
      startGame: seriesStartGame,
      endGame: ternaryData[ternaryData.length - 1].gameId,
      length: currentSeriesLength,
      games: ternaryData.slice(ternaryData.length - currentSeriesLength)
    });
  }
  
  return seriesLengths;
};

// Improved SB Trend calculation with proper window handling
const calculateSBForArray = (array) => {
  if (!array || array.length === 0) return 0;

  // Always take the last 16 values, pad with zeros if needed
  const last16 = array.slice(-16);
  
  // If we have less than 16 values, pad with zeros (neutral values)
  while (last16.length < 16) {
    last16.unshift(0);
  }
  
  const last16_g = last16.map(val => (val >= 2 ? 1 : -1));

  const s1 = 4 * last16_g.slice(-4).reduce((sum, v) => sum + v, 0);
  const s2 = 2 * last16_g.slice(-8).reduce((sum, v) => sum + v, 0);
  const s3 = last16_g.reduce((sum, v) => sum + v, 0);

  return s1 + s2 + s3;
};

function ResearchSectionNeutralReds({ gameResults, gameIdDifferences }) {
  const [analysisLength, setAnalysisLength] = useState(200);
  const [sumLength, setSumLength] = useState(1);
  const [chartScrollPosition, setChartScrollPosition] = useState(0);
  const [sumChartScrollPosition, setSumChartScrollPosition] = useState(0);
  const [otherSeriesScrollPosition, setOtherSeriesScrollPosition] = useState(0);
  const [chartVisibleRange, setChartVisibleRange] = useState(100);
  const [sumChartVisibleRange, setSumChartVisibleRange] = useState(50);
  const [otherSeriesVisibleRange, setOtherSeriesVisibleRange] = useState(50);
  const chartRef = useRef(null);
  const sumChartRef = useRef(null);
  const otherSeriesChartRef = useRef(null);
  const chartInstance = useRef(null);
  const sumChartInstance = useRef(null);
  const otherSeriesChartInstance = useRef(null);

  // Research calculations
  const researchData = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return {
        ternaryData: [],
        differencesData: {
          neutralRedGames: [],
          sumSeries: []
        },
        otherSeriesLengths: [],
        sbTrendData: [],
        allBustValues: []
      };
    }

    const bustValues = gameResults.map(res => res.bust);
    
    // Create ternary data for chart (Strong Blue, Neutral Red, Other)
    const ternaryData = createTernaryData(bustValues, analysisLength);
    
    // Calculate differences and sum series
    const differencesData = calculateNeutralRedDifferences(bustValues, sumLength, analysisLength);
    
    // Calculate "Other" series lengths
    const otherSeriesLengths = calculateOtherSeriesLengths(ternaryData);
    
    // Improved SB Trend data calculation
    const sbTrendData = [];
    const allBustValues = bustValues.slice(0, analysisLength).reverse();
    
    for (let i = 0; i < allBustValues.length; i++) {
      // Get bust values up to current index
      const windowValues = allBustValues.slice(0, i + 1);
      sbTrendData.push(calculateSBForArray(windowValues));
    }

    // Calculate SB Trend predictions using the full available data
    const last15Values = allBustValues.slice(-15);
    const sbTrendUp = calculateSBForArray([...last15Values, 2]);
    const sbTrendDown = calculateSBForArray([...last15Values, 1]);
    
    return {
      ternaryData: ternaryData,
      differencesData: differencesData,
      otherSeriesLengths: otherSeriesLengths,
      sbTrendData: sbTrendData,
      sbTrendUp: sbTrendUp,
      sbTrendDown: sbTrendDown,
      allBustValues: allBustValues
    };
  }, [gameResults, analysisLength, sumLength]);

  // Helper function to display SB Trend info
  const getSBTrendInfo = () => {
    if (!researchData.allBustValues || researchData.allBustValues.length === 0) return null;
    
    const currentValues = researchData.allBustValues.slice(-16);
    const mappedValues = currentValues.map(val => (val >= 2 ? 1 : -1));
    
    const last4 = mappedValues.slice(-4);
    const last8 = mappedValues.slice(-8);
    
    const s1 = 4 * last4.reduce((sum, v) => sum + v, 0);
    const s2 = 2 * last8.reduce((sum, v) => sum + v, 0);
    const s3 = mappedValues.reduce((sum, v) => sum + v, 0);
    
    return {
      currentValues: currentValues,
      mappedValues: mappedValues,
      components: { s1, s2, s3 },
      total: s1 + s2 + s3,
      currentSBTrend: researchData.sbTrendData[researchData.sbTrendData.length - 1] || 0
    };
  };

  // Get visible data for main chart based on scroll position
  const getVisibleChartData = () => {
    if (researchData.ternaryData.length === 0) return { labels: [], data: [], tooltipData: [], sbTrendData: [] };
    
    const start = Math.max(0, chartScrollPosition);
    const end = Math.min(researchData.ternaryData.length, start + chartVisibleRange);
    
    const visibleData = researchData.ternaryData.slice(start, end);
    const visibleSbTrendData = researchData.sbTrendData.slice(start, end);
    
    return {
      labels: visibleData.map(item => `G${item.gameId}`),
      data: visibleData.map(item => item.category),
      tooltipData: visibleData,
      sbTrendData: visibleSbTrendData,
      startIndex: start,
      endIndex: end
    };
  };

  // Get visible data for sum chart based on scroll position
  const getVisibleSumChartData = () => {
    if (researchData.differencesData.sumSeries.length === 0) return { labels: [], data: [], tooltipData: [] };
    
    const start = Math.max(0, sumChartScrollPosition);
    const end = Math.min(researchData.differencesData.sumSeries.length, start + sumChartVisibleRange);
    
    const visibleData = researchData.differencesData.sumSeries.slice(start, end);
    
    return {
      labels: visibleData.map(item => `${item.startGame}-${item.endGame}`),
      data: visibleData.map(item => item.sum),
      tooltipData: visibleData,
      startIndex: start,
      endIndex: end
    };
  };

  // Get visible data for "Other" series chart based on scroll position
  const getVisibleOtherSeriesData = () => {
    if (researchData.otherSeriesLengths.length === 0) return { labels: [], data: [], tooltipData: [] };
    
    const start = Math.max(0, otherSeriesScrollPosition);
    const end = Math.min(researchData.otherSeriesLengths.length, start + otherSeriesVisibleRange);
    
    const visibleData = researchData.otherSeriesLengths.slice(start, end);
    
    return {
      labels: visibleData.map(item => `${item.startGame}-${item.endGame}`),
      data: visibleData.map(item => item.length),
      tooltipData: visibleData,
      startIndex: start,
      endIndex: end
    };
  };

  // Main chart effect
  useEffect(() => {
    if (!chartRef.current || researchData.ternaryData.length === 0) return;

    const ctx = chartRef.current.getContext('2d');
    const visibleData = getVisibleChartData();
    
    // Destroy previous chart instance
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    // Create new chart with dual Y-axes
    chartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: visibleData.labels,
        datasets: [
          // Primary dataset: Strong Blue & Neutral Reds Pattern (Left Y-axis)
          {
            label: 'Strong Blue & Neutral Reds',
            data: visibleData.data,
            backgroundColor: visibleData.data.map((value, index) => {
              if (value === 2) return 'rgba(255, 205, 86, 0.8)'; // Yellow for Strong Blue
              if (value === 1) return 'rgba(54, 162, 235, 0.8)'; // Blue for Neutral Red
              return 'rgba(255, 99, 132, 0.6)'; // Red for Other
            }),
            borderColor: visibleData.data.map((value, index) => {
              if (value === 2) return 'rgba(255, 205, 86, 1)';
              if (value === 1) return 'rgba(54, 162, 235, 1)';
              return 'rgba(255, 99, 132, 1)';
            }),
            borderWidth: 1,
            barPercentage: 0.9,
            categoryPercentage: 0.9,
            yAxisID: 'y'
          },
          // Secondary dataset: SB Trend (Right Y-axis)
          {
            label: 'SB Trend',
            data: visibleData.sbTrendData,
            type: 'line',
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.1)',
            borderWidth: 2,
            pointRadius: 2,
            pointBackgroundColor: 'rgba(75, 192, 192, 1)',
            tension: 0.2,
            fill: false,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top'
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            callbacks: {
              label: function(context) {
                const dataIndex = context.dataIndex;
                const item = visibleData.tooltipData[dataIndex];
                const datasetIndex = context.datasetIndex;
                
                if (datasetIndex === 0) {
                  let categoryText = '';
                  if (item.category === 2) categoryText = 'Strong Blue';
                  else if (item.category === 1) categoryText = 'Neutral Red';
                  else categoryText = 'Other';
                  
                  return [
                    `Game: ${item.gameId}`,
                    `Bust: ${item.bustValue.toFixed(2)}x`,
                    `Category: ${categoryText}`
                  ];
                } else if (datasetIndex === 1) {
                  return `SB Trend: ${context.parsed.y}`;
                }
                return context.dataset.label + ': ' + context.parsed.y;
              }
            }
          },
          title: {
            display: true,
            text: `Strong Blue & Neutral Reds Distribution + SB Trend - Showing ${visibleData.startIndex + 1}-${visibleData.endIndex} of ${researchData.ternaryData.length} games`,
            font: {
              size: 14
            }
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: `Game Sequence (${visibleData.startIndex + 1}-${visibleData.endIndex})`
            },
            ticks: {
              maxTicksLimit: chartVisibleRange,
              autoSkip: false,
              maxRotation: 0,
              minRotation: 0
            },
            grid: {
              display: true
            }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: {
              display: true,
              text: 'Categories'
            },
            min: 0,
            max: 2,
            ticks: {
              stepSize: 1,
              callback: function(value) {
                if (value === 2) return 'Strong Blue';
                if (value === 1) return 'Neutral Red';
                if (value === 0) return 'Other';
                return '';
              }
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'SB Trend Value'
            },
            grid: {
              drawOnChartArea: false,
            },
            beginAtZero: true
          }
        },
        animation: {
          duration: 0
        },
        elements: {
          point: {
            radius: 0
          }
        }
      }
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [researchData.ternaryData, chartScrollPosition, chartVisibleRange, researchData.sbTrendData]);

  // Sum series chart effect
  useEffect(() => {
    if (!sumChartRef.current || researchData.differencesData.sumSeries.length === 0) return;

    const ctx = sumChartRef.current.getContext('2d');
    const visibleData = getVisibleSumChartData();
    
    // Destroy previous chart instance
    if (sumChartInstance.current) {
      sumChartInstance.current.destroy();
    }

    // Create datasets for the chart
    const datasets = [
      {
        label: `Sum of ${sumLength} Differences`,
        data: visibleData.data,
        borderColor: 'rgba(75, 192, 192, 1)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        tension: 0.4,
        pointRadius: visibleData.tooltipData.map(item => item.isLastValueSpecial ? 8 : 4),
        pointBackgroundColor: visibleData.tooltipData.map(item => 
          item.isLastValueSpecial ? 'rgba(255, 0, 0, 1)' : 'rgba(75, 192, 192, 1)'
        ),
        pointBorderColor: visibleData.tooltipData.map(item => 
          item.isLastValueSpecial ? 'rgba(255, 0, 0, 1)' : 'rgba(75, 192, 192, 1)'
        ),
        pointBorderWidth: visibleData.tooltipData.map(item => item.isLastValueSpecial ? 3 : 1),
        fill: true
      }
    ];

    // Create sum series chart
    sumChartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: visibleData.labels,
        datasets: datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const dataIndex = context.dataIndex;
                const item = visibleData.tooltipData[dataIndex];
                const label = [`Sum: ${item.sum}`];
                if (item.isLastValueSpecial) {
                  label.push(`🚨 Last difference: ${item.lastDifference}`);
                }
                return label;
              },
              afterLabel: function(context) {
                const dataIndex = context.dataIndex;
                const item = visibleData.tooltipData[dataIndex];
                return [
                  `Games: ${item.startGame} to ${item.endGame}`,
                  `Differences: ${item.games.map(g => g.difference).join(', ')}`,
                  item.isLastValueSpecial ? `⭐ Last value: ${item.lastDifference} (Special)` : `Last value: ${item.lastDifference}`
                ];
              }
            }
          },
          title: {
            display: true,
            text: `Neutral Reds - Sum of ${sumLength} Differences (Showing ${visibleData.startIndex + 1}-${visibleData.endIndex} of ${researchData.differencesData.sumSeries.length} series)`,
            font: {
              size: 14
            }
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: `Game Range (${visibleData.startIndex + 1}-${visibleData.endIndex})`
            },
            ticks: {
              maxTicksLimit: sumChartVisibleRange,
              autoSkip: false,
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            title: {
              display: true,
              text: 'Sum of Differences'
            },
            beginAtZero: true
          }
        },
        animation: {
          duration: 0
        }
      }
    });

    return () => {
      if (sumChartInstance.current) {
        sumChartInstance.current.destroy();
      }
    };
  }, [researchData.differencesData.sumSeries, sumLength, sumChartScrollPosition, sumChartVisibleRange]);

  // "Other" series lengths chart effect
  useEffect(() => {
    if (!otherSeriesChartRef.current || researchData.otherSeriesLengths.length === 0) return;

    const ctx = otherSeriesChartRef.current.getContext('2d');
    const visibleData = getVisibleOtherSeriesData();
    
    // Destroy previous chart instance
    if (otherSeriesChartInstance.current) {
      otherSeriesChartInstance.current.destroy();
    }

    // Create datasets for the chart
    const datasets = [
      {
        label: 'Other Series Length',
        data: visibleData.data,
        borderColor: 'rgba(255, 99, 132, 1)',
        backgroundColor: 'rgba(255, 99, 132, 0.1)',
        tension: 0,
        pointRadius: 3,
        pointBackgroundColor: 'rgba(255, 99, 132, 1)',
        pointBorderColor: 'rgba(255, 99, 132, 1)',
        pointBorderWidth: 1,
        fill: false,
        borderWidth: 2
      }
    ];

    // Create other series chart
    otherSeriesChartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: visibleData.labels,
        datasets: datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const dataIndex = context.dataIndex;
                const item = visibleData.tooltipData[dataIndex];
                return [`Series Length: ${item.length}`];
              },
              afterLabel: function(context) {
                const dataIndex = context.dataIndex;
                const item = visibleData.tooltipData[dataIndex];
                return [
                  `Games: ${item.startGame} to ${item.endGame}`,
                  `Total Games: ${item.length}`,
                  `Bust Values: ${item.games.map(g => g.bustValue.toFixed(1)).join(', ')}`
                ];
              }
            }
          },
          title: {
            display: true,
            text: `Other Values Series Lengths (Showing ${visibleData.startIndex + 1}-${visibleData.endIndex} of ${researchData.otherSeriesLengths.length} series)`,
            font: {
              size: 14
            }
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: `Series Index (${visibleData.startIndex + 1}-${visibleData.endIndex})`
            },
            ticks: {
              autoSkip: false,
              maxRotation: 90,
              minRotation: 45
            },
            grid: {
              display: true
            }
          },
          y: {
            title: {
              display: true,
              text: 'Series Length'
            },
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        },
        animation: {
          duration: 0
        },
        elements: {
          line: {
            tension: 0
          }
        }
      }
    });

    return () => {
      if (otherSeriesChartInstance.current) {
        otherSeriesChartInstance.current.destroy();
      }
    };
  }, [researchData.otherSeriesLengths, otherSeriesScrollPosition, otherSeriesVisibleRange]);

  const handleAnalysisLengthChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value > 0) {
      setAnalysisLength(value);
      setChartScrollPosition(0);
      setSumChartScrollPosition(0);
      setOtherSeriesScrollPosition(0);
    }
  };

  const handleSumLengthChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value > 0) {
      setSumLength(value);
      setSumChartScrollPosition(0);
    }
  };

  // Scroll handlers for main chart
  const handleChartScroll = (direction) => {
    if (direction === 'left') {
      setChartScrollPosition(prev => Math.max(0, prev - chartVisibleRange));
    } else {
      setChartScrollPosition(prev => 
        Math.min(researchData.ternaryData.length - chartVisibleRange, prev + chartVisibleRange)
      );
    }
  };

  // Scroll handlers for sum chart
  const handleSumChartScroll = (direction, e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    if (direction === 'left') {
      setSumChartScrollPosition(prev => Math.max(0, prev - sumChartVisibleRange));
    } else {
      setSumChartScrollPosition(prev => 
        Math.min(researchData.differencesData.sumSeries.length - sumChartVisibleRange, prev + sumChartVisibleRange)
      );
    }
  };

  // Scroll handlers for "Other" series chart
  const handleOtherSeriesScroll = (direction, e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    if (direction === 'left') {
      setOtherSeriesScrollPosition(prev => Math.max(0, prev - otherSeriesVisibleRange));
    } else {
      setOtherSeriesScrollPosition(prev => 
        Math.min(researchData.otherSeriesLengths.length - otherSeriesVisibleRange, prev + otherSeriesVisibleRange)
      );
    }
  };

  const handleChartVisibleRangeChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value >= 50 && value <= 500) {
      setChartVisibleRange(value);
    }
  };

  const handleSumChartVisibleRangeChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value >= 20 && value <= 200) {
      setSumChartVisibleRange(value);
    }
  };

  const handleOtherSeriesVisibleRangeChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value >= 20 && value <= 200) {
      setOtherSeriesVisibleRange(value);
    }
  };

  // Calculate statistics including special values and strong blue
  const stats = useMemo(() => {
    if (researchData.ternaryData.length === 0) return null;
    
    const totalGames = researchData.ternaryData.length;
    const neutralRedGames = researchData.ternaryData.filter(item => item.category === 1).length;
    const strongBlueGames = researchData.ternaryData.filter(item => item.category === 2).length;
    const neutralRedPercentage = (neutralRedGames / totalGames * 100).toFixed(1);
    const strongBluePercentage = (strongBlueGames / totalGames * 100).toFixed(1);
    
    // Differences stats
    const differences = researchData.differencesData.neutralRedGames
      .filter(game => !game.isFirst)
      .map(game => game.difference);
    
    const avgDifference = differences.length > 0 
      ? (differences.reduce((a, b) => a + b, 0) / differences.length).toFixed(1)
      : 0;
    
    // Special values stats (last difference = 1 or 2)
    const specialSeries = researchData.differencesData.sumSeries.filter(item => item.isLastValueSpecial);
    const specialPercentage = researchData.differencesData.sumSeries.length > 0 
      ? ((specialSeries.length / researchData.differencesData.sumSeries.length) * 100).toFixed(1)
      : 0;
    
    // Other series stats
    const otherSeriesStats = researchData.otherSeriesLengths.length > 0 ? {
      totalOtherSeries: researchData.otherSeriesLengths.length,
      avgOtherSeriesLength: (researchData.otherSeriesLengths.reduce((sum, series) => sum + series.length, 0) / researchData.otherSeriesLengths.length).toFixed(1),
      maxOtherSeriesLength: Math.max(...researchData.otherSeriesLengths.map(series => series.length)),
      minOtherSeriesLength: Math.min(...researchData.otherSeriesLengths.map(series => series.length))
    } : null;
    
    return {
      totalGames,
      neutralRedGames,
      neutralRedPercentage,
      strongBlueGames,
      strongBluePercentage,
      avgDifference,
      totalDifferences: differences.length,
      specialSeriesCount: specialSeries.length,
      specialSeriesPercentage: specialPercentage,
      otherSeriesStats
    };
  }, [researchData.ternaryData, researchData.differencesData, researchData.otherSeriesLengths]);

  if (!gameResults || gameResults.length === 0) {
    return (
      <div style={{
        marginTop: '40px',
        padding: '20px',
        background: '#f8f9fa',
        borderRadius: '8px',
        border: '1px solid #dee2e6'
      }}>
        <h2>Strong Blue & Neutral Reds Research</h2>
        <p>No game data available for research.</p>
      </div>
    );
  }

  const visibleChartData = getVisibleChartData();
  const visibleSumChartData = getVisibleSumChartData();
  const visibleOtherSeriesData = getVisibleOtherSeriesData();
  const sbTrendInfo = getSBTrendInfo();

  return (
    <div style={{
      marginTop: '40px',
      padding: '20px',
      background: '#f8f9fa',
      borderRadius: '8px',
      border: '1px solid #dee2e6'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2 style={{ margin: 0 }}>Strong Blue & Neutral Reds Research</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <label htmlFor="neutralAnalysisLength" style={{ fontSize: '14px', fontWeight: 'bold' }}>
            Analysis Length:
          </label>
          <input
            type="number"
            id="neutralAnalysisLength"
            min="1"
            max="10000"
            value={analysisLength}
            onChange={handleAnalysisLengthChange}
            style={{
              width: '80px',
              padding: '5px 8px',
              border: '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '14px'
            }}
          />
        </div>
      </div>

      {/* SB Trend Information Panel */}
      <div style={{ 
        background: 'white', 
        padding: '15px', 
        borderRadius: '8px', 
        border: '1px solid #dee2e6',
        marginBottom: '20px'
      }}>
        <h4 style={{ margin: '0 0 10px 0' }}>SB Trend Analysis (16-Game Window)</h4>
        {sbTrendInfo ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px' }}>
            <div>
              <strong>Current Values (Last 16):</strong>
              <div style={{ fontSize: '12px', fontFamily: 'monospace', marginTop: '5px' }}>
                {sbTrendInfo.currentValues.map((v, i) => 
                  <span key={i} style={{ 
                    color: v >= 4.0 ? '#ffd700' : v >= 2 ? 'green' : v >= 1.5 && v < 2 ? 'blue' : 'red',
                    marginRight: '2px',
                    fontWeight: v >= 4.0 ? 'bold' : 'normal'
                  }}>
                    {v.toFixed(1)}
                  </span>
                )}
              </div>
            </div>
            <div>
              <strong>Mapped Values (±1):</strong>
              <div style={{ fontSize: '12px', fontFamily: 'monospace', marginTop: '5px' }}>
                {sbTrendInfo.mappedValues.map((v, i) => 
                  <span key={i} style={{ 
                    color: v === 1 ? 'green' : 'red',
                    marginRight: '2px'
                  }}>
                    {v > 0 ? `+${v}` : v}
                  </span>
                )}
              </div>
            </div>
            <div>
              <strong>Components:</strong>
              <div style={{ fontSize: '12px' }}>
                S1 (Last 4): {sbTrendInfo.components.s1}<br />
                S2 (Last 8): {sbTrendInfo.components.s2}<br />
                S3 (All 16): {sbTrendInfo.components.s3}
              </div>
            </div>
            <div>
              <strong>Current SB Trend:</strong>
              <div style={{ 
                fontSize: '16px', 
                fontWeight: 'bold',
                color: sbTrendInfo.total > 0 ? 'green' : sbTrendInfo.total < 0 ? 'red' : 'gray'
              }}>
                {sbTrendInfo.total}
              </div>
            </div>
          </div>
        ) : (
          <div>No SB Trend data available</div>
        )}
      </div>

      {/* Statistics */}
      {stats && (
        <div style={{ 
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: '15px',
          marginBottom: '20px'
        }}>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #e9ecef',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#007bff' }}>
              {stats.totalGames}
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Total Games
            </div>
          </div>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #ffd700',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ffd700' }}>
              {stats.strongBlueGames}
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Strong Blue (≥4.0)
            </div>
          </div>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #ffd700',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ffd700' }}>
              {stats.strongBluePercentage}%
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Strong Blue %
            </div>
          </div>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #36a2eb',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#36a2eb' }}>
              {stats.neutralRedGames}
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Neutral Reds
            </div>
          </div>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #36a2eb',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#36a2eb' }}>
              {stats.neutralRedPercentage}%
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Neutral Red %
            </div>
          </div>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #28a745',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#28a745' }}>
              {stats.avgDifference}
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Avg Difference
            </div>
          </div>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #ff4444',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ff4444' }}>
              {stats.specialSeriesCount}
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Last Diff = 1 or 2
            </div>
          </div>
          <div style={{ 
            padding: '15px', 
            background: 'white',
            borderRadius: '8px',
            border: '2px solid #ff4444',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ff4444' }}>
              {stats.specialSeriesPercentage}%
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Special %
            </div>
          </div>
          {stats.otherSeriesStats && (
            <>
              <div style={{ 
                padding: '15px', 
                background: 'white',
                borderRadius: '8px',
                border: '2px solid #ff6b6b',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ff6b6b' }}>
                  {stats.otherSeriesStats.totalOtherSeries}
                </div>
                <div style={{ fontSize: '12px', color: '#6c757d' }}>
                  Other Series
                </div>
              </div>
              <div style={{ 
                padding: '15px', 
                background: 'white',
                borderRadius: '8px',
                border: '2px solid #ff6b6b',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ff6b6b' }}>
                  {stats.otherSeriesStats.avgOtherSeriesLength}
                </div>
                <div style={{ fontSize: '12px', color: '#6c757d' }}>
                  Avg Other Length
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Main Chart Section with Scroll Controls */}
      <div style={{ 
        background: 'white', 
        padding: '20px', 
        borderRadius: '8px', 
        border: '1px solid #dee2e6',
        marginBottom: '20px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
          <h3 style={{ margin: 0 }}>Strong Blue & Neutral Reds Distribution + SB Trend</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <label htmlFor="chartVisibleRange" style={{ fontSize: '12px', fontWeight: 'bold' }}>
              Visible Range:
            </label>
            <select
              id="chartVisibleRange"
              value={chartVisibleRange}
              onChange={handleChartVisibleRangeChange}
              style={{
                padding: '4px 8px',
                border: '1px solid #ccc',
                borderRadius: '4px',
                fontSize: '12px'
              }}
            >
              <option value={50}>50 games</option>
              <option value={100}>100 games</option>
              <option value={200}>200 games</option>
              <option value={300}>300 games</option>
              <option value={500}>500 games</option>
            </select>
          </div>
        </div>

        {/* Scroll Controls for Main Chart */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
          <button
            onClick={() => handleChartScroll('left')}
            disabled={chartScrollPosition === 0}
            style={{
              padding: '8px 16px',
              backgroundColor: chartScrollPosition === 0 ? '#ccc' : '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: chartScrollPosition === 0 ? 'not-allowed' : 'pointer',
              fontSize: '12px'
            }}
          >
            ← Previous {chartVisibleRange}
          </button>
          
          <div style={{ fontSize: '12px', color: '#666', textAlign: 'center' }}>
            Showing games {visibleChartData.startIndex + 1} to {visibleChartData.endIndex} of {researchData.ternaryData.length}
          </div>
          
          <button
            onClick={() => handleChartScroll('right')}
            disabled={chartScrollPosition >= researchData.ternaryData.length - chartVisibleRange}
            style={{
              padding: '8px 16px',
              backgroundColor: chartScrollPosition >= researchData.ternaryData.length - chartVisibleRange ? '#ccc' : '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: chartScrollPosition >= researchData.ternaryData.length - chartVisibleRange ? 'not-allowed' : 'pointer',
              fontSize: '12px'
            }}
          >
            Next {chartVisibleRange} →
          </button>
        </div>

        <div style={{ height: '400px', position: 'relative' }}>
          <canvas ref={chartRef}></canvas>
        </div>
        <div style={{ 
          fontSize: '12px', 
          color: '#666', 
          textAlign: 'center', 
          marginTop: '10px' 
        }}>
          Yellow bars = Strong Blue (≥4.0) | Blue bars = Neutral Reds (1.5-2.0) | Red bars = Other values | Green line = SB Trend | Scrollable view
        </div>
      </div>

      {/* Sum Series Section with Scroll Controls */}
      <div style={{ 
        background: 'white', 
        padding: '20px', 
        borderRadius: '8px', 
        border: '1px solid #dee2e6',
        marginBottom: '20px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
          <h3 style={{ margin: 0 }}>Neutral Reds Differences Sum Series</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <label htmlFor="sumLength" style={{ fontSize: '12px', fontWeight: 'bold' }}>
                Sum Length:
              </label>
              <input
                type="number"
                id="sumLength"
                min="1"
                max="20"
                value={sumLength}
                onChange={handleSumLengthChange}
                style={{
                  width: '50px',
                  padding: '4px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  fontSize: '12px'
                }}
              />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <label htmlFor="sumChartVisibleRange" style={{ fontSize: '12px', fontWeight: 'bold' }}>
                Visible:
              </label>
              <select
                id="sumChartVisibleRange"
                value={sumChartVisibleRange}
                onChange={handleSumChartVisibleRangeChange}
                style={{
                  padding: '4px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  fontSize: '12px'
                }}
              >
                <option value={20}>20 series</option>
                <option value={50}>50 series</option>
                <option value={100}>100 series</option>
                <option value={200}>200 series</option>
              </select>
            </div>
          </div>
        </div>

        {researchData.differencesData.sumSeries.length > 0 ? (
          <>
            {/* Scroll Controls for Sum Chart */}
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'center', 
              marginBottom: '10px',
              padding: '10px',
              background: '#f8f9fa',
              borderRadius: '6px',
              border: '1px solid #dee2e6'
            }}>
              <button
                onClick={(e) => handleSumChartScroll('left', e)}
                disabled={sumChartScrollPosition === 0}
                style={{
                  padding: '10px 16px',
                  backgroundColor: sumChartScrollPosition === 0 ? '#ccc' : '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: sumChartScrollPosition === 0 ? 'not-allowed' : 'pointer',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  minWidth: '120px'
                }}
              >
                ← Previous {sumChartVisibleRange}
              </button>
              
              <div style={{ 
                fontSize: '12px', 
                color: '#666', 
                textAlign: 'center',
                fontWeight: 'bold',
                padding: '0 15px'
              }}>
                Showing series {visibleSumChartData.startIndex + 1} to {visibleSumChartData.endIndex} of {researchData.differencesData.sumSeries.length}
              </div>
              
              <button
                onClick={(e) => handleSumChartScroll('right', e)}
                disabled={sumChartScrollPosition >= researchData.differencesData.sumSeries.length - sumChartVisibleRange}
                style={{
                  padding: '10px 16px',
                  backgroundColor: sumChartScrollPosition >= researchData.differencesData.sumSeries.length - sumChartVisibleRange ? '#ccc' : '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: sumChartScrollPosition >= researchData.differencesData.sumSeries.length - sumChartVisibleRange ? 'not-allowed' : 'pointer',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  minWidth: '120px'
                }}
              >
                Next {sumChartVisibleRange} →
              </button>
            </div>

            <div style={{ height: '400px', position: 'relative' }}>
              <canvas ref={sumChartRef}></canvas>
            </div>
            <div style={{ 
              fontSize: '12px', 
              color: '#666', 
              textAlign: 'center', 
              marginTop: '10px' 
            }}>
              Showing sum of {sumLength} consecutive neutral red differences | 
              <span style={{ color: '#ff4444', fontWeight: 'bold' }}>
                {' '}Red dots: Last difference = 1 or 2 ({stats.specialSeriesCount})
              </span>
            </div>
          </>
        ) : (
          <div style={{ 
            padding: '40px', 
            textAlign: 'center',
            background: '#f8f9fa',
            borderRadius: '8px'
          }}>
            <p style={{ fontSize: '16px', color: '#6c757d' }}>
              No sum series available. Need at least {sumLength} neutral red games with differences.
            </p>
          </div>
        )}
      </div>

      {/* Other Series Lengths Section */}
      <div style={{ 
        background: 'white', 
        padding: '20px', 
        borderRadius: '8px', 
        border: '1px solid #dee2e6'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
          <h3 style={{ margin: 0 }}>Other Values Series Lengths</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <label htmlFor="otherSeriesVisibleRange" style={{ fontSize: '12px', fontWeight: 'bold' }}>
                Visible:
              </label>
              <select
                id="otherSeriesVisibleRange"
                value={otherSeriesVisibleRange}
                onChange={handleOtherSeriesVisibleRangeChange}
                style={{
                  padding: '4px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  fontSize: '12px'
                }}
              >
                <option value={20}>20 series</option>
                <option value={50}>50 series</option>
                <option value={100}>100 series</option>
                <option value={200}>200 series</option>
              </select>
            </div>
          </div>
        </div>

        {researchData.otherSeriesLengths.length > 0 ? (
          <>
            {/* Scroll Controls for Other Series Chart */}
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'center', 
              marginBottom: '10px',
              padding: '10px',
              background: '#f8f9fa',
              borderRadius: '6px',
              border: '1px solid #dee2e6'
            }}>
              <button
                onClick={(e) => handleOtherSeriesScroll('left', e)}
                disabled={otherSeriesScrollPosition === 0}
                style={{
                  padding: '10px 16px',
                  backgroundColor: otherSeriesScrollPosition === 0 ? '#ccc' : '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: otherSeriesScrollPosition === 0 ? 'not-allowed' : 'pointer',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  minWidth: '120px'
                }}
              >
                ← Previous {otherSeriesVisibleRange}
              </button>
              
              <div style={{ 
                fontSize: '12px', 
                color: '#666', 
                textAlign: 'center',
                fontWeight: 'bold',
                padding: '0 15px'
              }}>
                Showing series {visibleOtherSeriesData.startIndex + 1} to {visibleOtherSeriesData.endIndex} of {researchData.otherSeriesLengths.length}
              </div>
              
              <button
                onClick={(e) => handleOtherSeriesScroll('right', e)}
                disabled={otherSeriesScrollPosition >= researchData.otherSeriesLengths.length - otherSeriesVisibleRange}
                style={{
                  padding: '10px 16px',
                  backgroundColor: otherSeriesScrollPosition >= researchData.otherSeriesLengths.length - otherSeriesVisibleRange ? '#ccc' : '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: otherSeriesScrollPosition >= researchData.otherSeriesLengths.length - otherSeriesVisibleRange ? 'not-allowed' : 'pointer',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  minWidth: '120px'
                }}
              >
                Next {otherSeriesVisibleRange} →
              </button>
            </div>

            <div style={{ height: '400px', position: 'relative' }}>
              <canvas ref={otherSeriesChartRef}></canvas>
            </div>
            <div style={{ 
              fontSize: '12px', 
              color: '#666', 
              textAlign: 'center', 
              marginTop: '10px' 
            }}>
              Showing length of consecutive "Other" value series | Red line = Series length over time
            </div>
          </>
        ) : (
          <div style={{ 
            padding: '40px', 
            textAlign: 'center',
            background: '#f8f9fa',
            borderRadius: '8px'
          }}>
            <p style={{ fontSize: '16px', color: '#6c757d' }}>
              No "Other" value series available. All games are either Strong Blue or Neutral Reds.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default ResearchSectionNeutralReds;