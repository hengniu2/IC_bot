import React, { useMemo, useState, useEffect } from 'react';

// Helper function to count pattern occurrences in a stream
const countPatternOccurrences = (stream, pattern) => {
  let count = 0;
  for (let i = 0; i <= stream.length - pattern.length; i++) {
    const segment = stream.slice(i, i + pattern.length);
    const isMatch = segment.every((bit, index) => bit === pattern[index]);
    if (isMatch) {
      count++;
    }
  }
  return count;
};

// Extension by adding last digit repeatedly
const findExtension1Patterns = (totalStream, basePattern) => {
  if (basePattern.length === 0) return [];
  
  const lastDigit = basePattern[basePattern.length - 1];
  const extensions = [];
  
  const patterns = [];
  
  for (let depth = 0; depth <= 4; depth++) {
    const extendedPattern = [...basePattern, ...Array(depth).fill(lastDigit)];
    const count = countPatternOccurrences(totalStream, extendedPattern);
    
    if (count === 0 && depth > 0) {
      break;
    }
    
    patterns.push({
      depth,
      pattern: [...extendedPattern],
      count,
      display: `${basePattern.join('')}${lastDigit.toString().repeat(depth)}`,
      isOriginal: depth === 0,
      isExtension: depth > 0
    });
  }
  
  const totalMatches = patterns.reduce((sum, p) => sum + p.count, 0);
  
  if (totalMatches > 0) {
    extensions.push({
      lastDigit,
      patterns,
      totalMatches
    });
  }
  
  return extensions;
};

function HeaderSection({ lastGeneratedBust, moonPercentResult, gameIdDifferences, gameResults, isLiveMode, onModeChange, isManualHashMode, onManualHashModeChange, onManualHashUpdate, currentHash, onMatchedQueueChange, weatherCondition }) {
  const [manualHashInput, setManualHashInput] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const diffEntries = Object.entries(gameIdDifferences || {});
  const last14Diffs = diffEntries.slice(0, 14);
  const last14GameResults = gameResults ? [...gameResults].slice(0,14).reverse() : [];

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  // Format time for GMT+9
  const getGMT3Time = () => {
    const now = currentTime;
      const gmtPlus9Offset = 9 * 60; // GMT+9 in minutes
      const localOffset = now.getTimezoneOffset(); // Local offset in minutes
      const offsetDiff = gmtPlus9Offset + localOffset; // Difference in minutes
      
      const gmt9Time = new Date(now.getTime() + offsetDiff * 60 * 1000);
      
      let hours = gmt9Time.getHours();
      const minutes = gmt9Time.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // 0 should be 12
    
    const minutesStr = minutes < 10 ? `0${minutes}` : minutes;
    
    return `${hours}:${minutesStr} ${ampm}`;
  };

  const binaryStream = last14GameResults.map(result => {
    const bust = result.bust;
    if (bust > 4 || (bust >= 1.5 && bust <= 2)) {
      return 1;
    } else {
      return 0;
    }
  });

  const findPatternIndices = (stream) => {
    const pattern = [0, 0, 0, 0, 0, 0, 1, 0, 0];
    const indices = [];
    for (let i = 0; i <= stream.length - pattern.length; i++) {
      const segment = stream.slice(i, i + pattern.length);
      const isMatch = segment.every((bit, index) => bit === pattern[index]);
      if (isMatch) {
        indices.push(i);
      }
    }
    return indices;
  };

  const patternIndices = findPatternIndices(binaryStream);
  const [isPatternModalOpen, setIsPatternModalOpen] = useState(false);
  const [showPatternAnalysis, setShowPatternAnalysis] = useState(true);
  const [highProbabilityBet, setHighProbabilityBet] = useState([]);
  const [highProbabilityBetReasoning, setHighProbabilityBetReasoning] = useState([]);
  const [highProbabilityActualBet, setHighProbabilityActualBet] = useState([]);
  const [matchedSeries, setMatchedSeries] = useState([]);
  const prevLastGeneratedBustRef = React.useRef(lastGeneratedBust);

  // Convert actual bets to 1 or 2: >=2 -> 2, <2 -> 1
  const highProbabilityActualConvertedBet = useMemo(() => {
    return highProbabilityActualBet.map(bust => bust >= 2 ? 2 : 1);
  }, [highProbabilityActualBet]);

  // Track previous converted length to detect new additions
  const prevConvertedLengthRef = React.useRef(0);

  // Update matched series when converted values are added
  useEffect(() => {
    const betLength = highProbabilityBet.length;
    const convertedLength = highProbabilityActualConvertedBet.length;
    
    // Check if a new converted value was added
    if (convertedLength > prevConvertedLengthRef.current) {
      // n = length of converted
      const n = convertedLength;
      
      // Need at least 4 values in both arrays to calculate match
      if (betLength >= n && n >= 4) {
        // Get last 4 values from converted: converted[n-4] to converted[n-1]
        const convertedMatched = highProbabilityActualConvertedBet.slice(n - 4, n);
        
        // Get last 4 values from bet: bet[n-4] to bet[n-1]
        const betMatched = highProbabilityBet.slice(n - 4, n);
        
        // Count how many match
        let matchCount = 0;
        for (let i = 0; i < 4; i++) {
          if (betMatched[i] === convertedMatched[i]) {
            matchCount++;
          }
        }
        
        // Add the match count to the matched series array
        setMatchedSeries(prev => [...prev, matchCount]);
      }
      
      // Update the ref to track the new length
      prevConvertedLengthRef.current = convertedLength;
    }
  }, [highProbabilityActualConvertedBet, highProbabilityBet]);

  // Pass matched queue (matchedSeries) to parent component
  useEffect(() => {
    if (onMatchedQueueChange) {
      onMatchedQueueChange(matchedSeries);
    }
  }, [matchedSeries, onMatchedQueueChange]);

  const streamAnalysis = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return null;
    }

    const totalStream = gameResults.map(result => 
      result.bust >= 2 ? 2 : 1
    );

    // Calculate for all lengths from 6 to 11
    const allSubStreams = [];
    for (let len = 6; len <= 11; len++) {
      const subStream = gameResults.slice(0, len).reverse().map(result => 
        result.bust >= 2 ? 2 : 1
      );

      const extendedPattern1 = [...subStream, 1];
      const extendedPattern2 = [...subStream, 2];

      const countPattern1 = countPatternOccurrences(totalStream, extendedPattern1);
      const countPattern2 = countPatternOccurrences(totalStream, extendedPattern2);

      const totalMatches = countPattern1 + countPattern2;
      const percentage1 = totalMatches > 0 ? ((countPattern1 / totalMatches) * 100).toFixed(1) : '0.0';
      const percentage2 = totalMatches > 0 ? ((countPattern2 / totalMatches) * 100).toFixed(1) : '0.0';

      allSubStreams.push({
        length: len,
        subStream,
        extendedPattern1,
        extendedPattern2,
        countPattern1,
        countPattern2,
        percentage1,
        percentage2,
        totalMatches
      });
    }

    return {
      totalStream,
      totalBits: totalStream.length,
      allSubStreams
    };
  }, [gameResults]);

  // Track high probability bets - add to array when hasHighProbability is detected
  const prevStreamAnalysisRef = React.useRef(null);
  const processedAnalysisRef = React.useRef(new Set()); // Track processed analyses
  
  useEffect(() => {
    if (!streamAnalysis) return;
    
    // Create a unique key for this analysis based on allSubStreams
    const analysisKey = JSON.stringify(streamAnalysis.allSubStreams);
    
    // Skip if this exact analysis was already processed
    if (processedAnalysisRef.current.has(analysisKey)) {
      return;
    }
    
    // Check if streamAnalysis has changed (new analysis)
    const analysisChanged = analysisKey !== JSON.stringify(prevStreamAnalysisRef.current?.allSubStreams);
    
    if (analysisChanged) {
      // Mark this analysis as processed immediately to prevent duplicate processing
      processedAnalysisRef.current.add(analysisKey);
      
      // Clear previous reasoning when new analysis comes
      setHighProbabilityBetReasoning([]);
      
      const betsToAdd = [];
      const reasoningToAdd = [];
      
      // Priority order: Third > Second > First
      // Check in priority order and only add once per bet value (highest priority wins)
      // Only add one bet value per analysis cycle (highest priority wins)
      
      // THIRD LOGIC (Highest Priority): Check length 10 and 11 for percentage > 80 and count > 2
      let bet1Added = false;
      let bet2Added = false;
      let anyBetAdded = false; // Track if any bet was added to prevent lower priorities
      
      for (let len = 10; len <= 11; len++) {
        if (anyBetAdded) break; // Stop if already added a bet
        
        const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
        if (subStreamData) {
          const percentage1 = parseFloat(subStreamData.percentage1);
          const percentage2 = parseFloat(subStreamData.percentage2);
          const countPattern1 = subStreamData.countPattern1;
          const countPattern2 = subStreamData.countPattern2;
          
          // For length 10, 11: if (percentage1 > 80) && (count > 2), add 2
          if (percentage1 > 80 && countPattern1 > 2 && !anyBetAdded) {
            betsToAdd.push(2);
            reasoningToAdd.push(`Len${len}: P1>80% (${percentage1.toFixed(1)}%) & count>2 (${countPattern1}) [Priority 3]`);
            bet2Added = true;
            anyBetAdded = true;
            break; // Only add one value, exit loop
          }
          
          // For length 10, 11: if (percentage2 > 80) && (count > 2), add 1
          if (percentage2 > 80 && countPattern2 > 2 && !anyBetAdded) {
            betsToAdd.push(1);
            reasoningToAdd.push(`Len${len}: P2>80% (${percentage2.toFixed(1)}%) & count>2 (${countPattern2}) [Priority 3]`);
            bet1Added = true;
            anyBetAdded = true;
            break; // Only add one value, exit loop
          }
        }
      }
      
      // SECOND LOGIC (Second Priority): Check if at least 5 lengths 6-11 have percentage >= 50
      // Omit len 11 if both count1 and count2 are 0
      // Only check if no bet was added by higher priority
      if (!anyBetAdded && !bet1Added) {
        const len11Data = streamAnalysis.allSubStreams.find(s => s.length === 11);
        const shouldOmitLen11 = len11Data && len11Data.countPattern1 === 0 && len11Data.countPattern2 === 0;
        const maxLen = shouldOmitLen11 ? 10 : 11;
        
        let countValid = 0;
        for (let len = 6; len <= maxLen; len++) {
          const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
          if (subStreamData) {
            const p1 = parseFloat(subStreamData.percentage1);
            if (p1 >= 50) {
              countValid++;
            }
          }
        }
        
        if (countValid >= 5) {
          betsToAdd.push(1);
          const lenRange = shouldOmitLen11 ? 'len6-10' : 'len6-11';
          const totalLengths = maxLen - 6 + 1; // 6 to maxLen inclusive
          reasoningToAdd.push(`At least 5 of ${lenRange}: P1>=50% (${countValid}/${totalLengths}) [Priority 2]`);
          bet1Added = true;
          anyBetAdded = true;
        }
      }
      
      if (!anyBetAdded && !bet2Added) {
        const len11Data = streamAnalysis.allSubStreams.find(s => s.length === 11);
        const shouldOmitLen11 = len11Data && len11Data.countPattern1 === 0 && len11Data.countPattern2 === 0;
        const maxLen = shouldOmitLen11 ? 10 : 11;
        
        let countValid = 0;
        for (let len = 6; len <= maxLen; len++) {
          const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
          if (subStreamData) {
            const p2 = parseFloat(subStreamData.percentage2);
            if (p2 >= 50) {
              countValid++;
            }
          }
        }
        
        if (countValid >= 5) {
          betsToAdd.push(2);
          const lenRange = shouldOmitLen11 ? 'len6-10' : 'len6-11';
          const totalLengths = maxLen - 6 + 1; // 6 to maxLen inclusive
          reasoningToAdd.push(`At least 5 of ${lenRange}: P2>=50% (${countValid}/${totalLengths}) [Priority 2]`);
          bet2Added = true;
          anyBetAdded = true;
        }
      }
      
      // FIRST LOGIC (Lowest Priority): High probability at specific length with continuation
      // Only check if no bet was added by higher priorities
      if (!anyBetAdded && !bet1Added && !bet2Added) {
        const highProbLengths = [];
        streamAnalysis.allSubStreams.forEach((subStreamData) => {
          const percentage1 = parseFloat(subStreamData.percentage1);
          const percentage2 = parseFloat(subStreamData.percentage2);
          const totalMatches = subStreamData.countPattern1 + subStreamData.countPattern2;
          const hasHighProbability = (percentage1 > 70 || percentage2 > 70) && totalMatches >= 5;
          
          if (hasHighProbability) {
            highProbLengths.push({
              length: subStreamData.length,
              percentage1,
              percentage2
            });
          }
        });
        
        for (const { length, percentage1, percentage2 } of highProbLengths) {
          if (anyBetAdded) break; // Stop if already added a bet
          
          // Check if percentage1 > 70, then verify all lengths from this length to 11 have percentage1 >= 50
          // Omit len 11 if both count1 and count2 are 0
          if (percentage1 > 70 && !bet1Added && !anyBetAdded) {
            let allValid = true;
            const len11Data = streamAnalysis.allSubStreams.find(s => s.length === 11);
            const shouldOmitLen11 = len11Data && len11Data.countPattern1 === 0 && len11Data.countPattern2 === 0;
            const maxLen = shouldOmitLen11 ? 10 : 11;
            
            for (let len = length; len <= maxLen; len++) {
              const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
              if (subStreamData) {
                const p1 = parseFloat(subStreamData.percentage1);
                if (p1 < 50) {
                  allValid = false;
                  break;
                }
              }
            }
            if (allValid) {
              betsToAdd.push(1);
              const lenRange = shouldOmitLen11 ? `len${length}-10` : `len${length}-11`;
              reasoningToAdd.push(`Len${length}: P1>70% (${percentage1.toFixed(1)}%) & all ${lenRange} P1>=50% [Priority 1]`);
              bet1Added = true;
              anyBetAdded = true;
              break; // Only add one value, exit loop
            }
          }
          
          // Check if percentage2 > 70, then verify all lengths from this length to 11 have percentage2 >= 50
          // Omit len 11 if both count1 and count2 are 0
          if (percentage2 > 70 && !bet2Added && !anyBetAdded) {
            let allValid = true;
            const len11Data = streamAnalysis.allSubStreams.find(s => s.length === 11);
            const shouldOmitLen11 = len11Data && len11Data.countPattern1 === 0 && len11Data.countPattern2 === 0;
            const maxLen = shouldOmitLen11 ? 10 : 11;
            
            for (let len = length; len <= maxLen; len++) {
              const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
              if (subStreamData) {
                const p2 = parseFloat(subStreamData.percentage2);
                if (p2 < 50) {
                  allValid = false;
                  break;
                }
              }
            }
            if (allValid) {
              betsToAdd.push(2);
              const lenRange = shouldOmitLen11 ? `len${length}-10` : `len${length}-11`;
              reasoningToAdd.push(`Len${length}: P2>70% (${percentage2.toFixed(1)}%) & all ${lenRange} P2>=50% [Priority 1]`);
              bet2Added = true;
              anyBetAdded = true;
              break; // Only add one value, exit loop
            }
          }
        }
      }
      
      // Only add the first bet value if multiple were added (shouldn't happen, but safety check)
      if (betsToAdd.length > 0) {
        // Only add one value per analysis cycle
        const betToAdd = betsToAdd[0];
        const reasoningToAddFinal = reasoningToAdd[0] || '';
        setHighProbabilityBet(prev => [...prev, betToAdd]);
        setHighProbabilityBetReasoning([reasoningToAddFinal]);
      }
      
      prevStreamAnalysisRef.current = streamAnalysis;
    }
  }, [streamAnalysis]);

  // Track actual bust results after high probability bets
  const betsAddedRef = React.useRef(0);
  
  useEffect(() => {
    // Track when new bets are added
    if (highProbabilityBet.length > betsAddedRef.current) {
      betsAddedRef.current = highProbabilityBet.length;
    }
  }, [highProbabilityBet]);

  useEffect(() => {
    if (lastGeneratedBust !== null && 
        prevLastGeneratedBustRef.current !== lastGeneratedBust &&
        betsAddedRef.current > highProbabilityActualBet.length) {
      // New bust generated after bets were added, add it to actual bet array
      setHighProbabilityActualBet(prev => [...prev, lastGeneratedBust]);
    }
    prevLastGeneratedBustRef.current = lastGeneratedBust;
  }, [lastGeneratedBust, highProbabilityActualBet.length]);

  const shouldShowNauseatedIcon = (bust) => {
    return bust < 1.5 || (bust >= 2 && bust <= 3);
  };

  const lastDiffValue = last14Diffs.length > 0 ? last14Diffs[0][1] : null;
  const shouldShowStopMoon = lastDiffValue > 14;

  const togglePatternModal = () => {
    setIsPatternModalOpen(!isPatternModalOpen);
  };



  return (
    <div
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 1000,
        background: 'linear-gradient(135deg, #fafafa 0%, #f5f5f5 100%)',
        borderBottom: '1px solid #e0e0e0',
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
        padding: '10px 20px',
      }}
    >
      {/* Weather Condition Radio Buttons - Top Left */}
      <div style={{
        position: 'absolute',
        top: '10px',
        left: '10px',
        zIndex: 1002,
        display: 'flex',
        gap: '15px',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        padding: '8px 15px',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2)',
        border: '2px solid #007bff'
      }}>
        <span style={{ fontWeight: 'bold', fontSize: '14px', marginRight: '5px' }}>Condition:</span>
        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
          <input
            type="radio"
            name="weatherCondition"
            value="Sunny"
            checked={weatherCondition === 'Sunny'}
            readOnly
            style={{ cursor: 'pointer' }}
          />
          <span style={{ color: '#ffa500', fontWeight: weatherCondition === 'Sunny' ? 'bold' : 'normal' }}>
            ☀️ Sunny
          </span>
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
          <input
            type="radio"
            name="weatherCondition"
            value="Rainy"
            checked={weatherCondition === 'Rainy'}
            readOnly
            style={{ cursor: 'pointer' }}
          />
          <span style={{ color: '#4169e1', fontWeight: weatherCondition === 'Rainy' ? 'bold' : 'normal' }}>
            🌧️ Rainy
          </span>
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
          <input
            type="radio"
            name="weatherCondition"
            value="Cloudy"
            checked={weatherCondition === 'Cloudy'}
            readOnly
            style={{ cursor: 'pointer' }}
          />
          <span style={{ color: '#808080', fontWeight: weatherCondition === 'Cloudy' ? 'bold' : 'normal' }}>
            ☁️ Cloudy
          </span>
        </label>
      </div>

      {/* Time Display - Top Center */}
      <div style={{
        position: 'absolute',
        top: '10px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 1001
      }}>
        <div style={{
          backgroundColor: '#007bff',
          color: 'white',
          padding: '6px 20px',
          borderRadius: '8px',
          fontSize: '18px',
          fontWeight: 'bold',
          fontFamily: 'monospace',
          letterSpacing: '1px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
          whiteSpace: 'nowrap'
        }}>
          {getGMT3Time()} <span style={{ fontSize: '12px', fontWeight: 'normal' }}>GMT+9</span>
        </div>
      </div>

      {/* First Row: Last Bust + Percent Results */}
      <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', flexWrap: 'wrap', gap: '15px', marginTop: '50px' }}>
        {lastGeneratedBust !== null && (
          <div style={{ padding: '10px 20px', backgroundColor: lastGeneratedBust > 2 ? '#28a745' : '#dc3545', color: 'white', borderRadius: '8px', fontWeight: 'bold', fontSize: '16px', minWidth: '120px', textAlign: 'center', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
            Last: {lastGeneratedBust.toFixed(2)}x
          </div>
        )}
        {moonPercentResult && moonPercentResult.length > 0 && (
          <div style={{ padding: '10px 20px', backgroundColor: '#f8fbfd', borderRadius: '8px', fontSize: '14px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', whiteSpace: 'nowrap' }}>
            {moonPercentResult.map((res) => `${res.total}: ${res.percentageOver10}`).join(' | ')}
          </div>
        )}
      </div>

      {/* Second Row: Last 14 Game Results */}
      {last14GameResults.length > 0 && (
        <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', flexWrap: 'wrap', gap: '15px', marginTop: '12px' }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: 1 }}>
            {last14GameResults.map((result, index) => {
              const showNauseatedIcon = shouldShowNauseatedIcon(result.bust);
              return (
                <div key={result.gameId || index} style={{ backgroundColor: result.bust >= 10 ? '#e0a800' : result.bust >= 2 ? '#198754' : '#c82333', color: 'white', borderRadius: '6px', padding: '6px 10px', fontWeight: 'bold', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', minWidth: '50px', textAlign: 'center', position: 'relative' }}>
                  {result.bust?.toFixed(2)}x
                  {showNauseatedIcon && (
                    <span style={{ position: 'absolute', top: '-6px', right: '-6px', fontSize: '14px', background: 'rgba(255, 255, 255, 0.9)', borderRadius: '50%', width: '18px', height: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 1px 2px rgba(0,0,0,0.2)' }}>🤢</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Third Row: Game ID Differences + 4V Section + Pattern Modal Toggle */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '15px', marginTop: '12px' }}>
        {/* Left Side: Game ID Differences and 4V Section */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1, minWidth: '300px' }}>
          {last14Diffs.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {last14Diffs.reverse().map(([gameId, diff], index) => (
                <div key={index} style={{ backgroundColor: diff > 10 ? 'orange' : '#e0e0e0', color: diff > 10 ? 'white' : '#333', borderRadius: '6px', padding: '6px 10px', fontWeight: 'bold', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', minWidth: '50px', textAlign: 'center' }}>
                  {diff}
                </div>
              ))}
            </div>
          )}

          {/* 4V Section */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', background: '#f8f9fa', padding: '8px 12px', borderRadius: '8px', border: '1px solid #dee2e6', position: 'relative' }}>
            <span style={{ fontSize: '12px', fontWeight: 'bold', color: '#495057', marginRight: '8px', whiteSpace: 'nowrap' }}>4V:</span>
            <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', position: 'relative' }}>
              {binaryStream.map((bit, index) => {
                const isInPattern = patternIndices.some(startIndex => index >= startIndex && index < startIndex + 9);
                return (
                  <div key={index} style={{ width: '20px', height: '20px', borderRadius: '4px', backgroundColor: bit === 1 ? '#28a745' : '#dc3545', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 'bold', boxShadow: '0 1px 2px rgba(0,0,0,0.1)', position: 'relative', zIndex: 2 }}>
                    {bit}
                    {isInPattern && <div style={{ position: 'absolute', bottom: '-2px', left: '0', width: '100%', height: '2px', backgroundColor: '#007bff', zIndex: 1 }} />}
                  </div>
                );
              })}
              {patternIndices.length > 0 && <div style={{ position: 'absolute', top: '-15px', left: `${patternIndices[0] * 24}px`, width: '216px', height: '2px', backgroundColor: '#007bff', zIndex: 1 }} />}
            </div>
            {patternIndices.length > 0 && <div style={{ position: 'absolute', top: '-8px', right: '8px', backgroundColor: '#007bff', color: 'white', fontSize: '9px', fontWeight: 'bold', padding: '2px 6px', borderRadius: '10px', zIndex: 3 }}>PATTERN FOUND</div>}
          </div>
        </div>

        {/* Right Side: Mode Toggle and Pattern Modal Toggle Button */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          {/* Manual Hash Mode Toggle */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '6px',
            padding: '6px 12px',
            backgroundColor: '#fff3cd',
            borderRadius: '8px',
            border: `1px solid ${isManualHashMode ? '#ffc107' : '#dee2e6'}`
          }}>
            <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#856404' }}>
              Hash:
            </span>
            <button
              onClick={() => {
                onManualHashModeChange(!isManualHashMode);
                if (!isManualHashMode && currentHash) {
                  setManualHashInput(currentHash);
                }
              }}
              style={{
                padding: '4px 10px',
                backgroundColor: isManualHashMode ? '#ffc107' : '#e9ecef',
                color: isManualHashMode ? '#856404' : '#6c757d',
                border: 'none',
                borderRadius: '4px',
                fontSize: '10px',
                fontWeight: 'bold',
                cursor: 'pointer',
                whiteSpace: 'nowrap'
              }}
              title={isManualHashMode ? 'Switch to Extension Mode' : 'Switch to Manual Hash Mode'}
            >
              {isManualHashMode ? '✏️ MANUAL' : '🔌 EXT'}
            </button>
          </div>
          
          {/* Manual Hash Input (shown when in manual mode) */}
          {isManualHashMode && (
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '6px',
              padding: '4px 8px',
              backgroundColor: '#fff',
              borderRadius: '6px',
              border: '1px solid #ffc107'
            }}>
              <input
                type="text"
                value={manualHashInput}
                onChange={(e) => setManualHashInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    onManualHashUpdate(manualHashInput);
                  }
                }}
                placeholder="Enter hash..."
                style={{
                  padding: '4px 8px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  fontSize: '11px',
                  width: '200px',
                  fontFamily: 'monospace'
                }}
              />
              <button
                onClick={() => onManualHashUpdate(manualHashInput)}
                style={{
                  padding: '4px 10px',
                  backgroundColor: '#28a745',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '10px',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
                title="Update hash"
              >
                ✓
              </button>
            </div>
          )}
          
          {/* Mode Toggle Switch */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '8px',
            padding: '6px 12px',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px',
            border: '1px solid #dee2e6'
          }}>
            <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057' }}>
              Mode:
            </span>
            <button
              onClick={() => onModeChange(!isLiveMode)}
              style={{
                padding: '6px 14px',
                backgroundColor: isLiveMode ? '#28a745' : '#ffc107',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '11px',
                fontWeight: 'bold',
                cursor: 'pointer',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                transition: 'all 0.3s ease',
                whiteSpace: 'nowrap'
              }}
              title={isLiveMode ? 'Switch to Test Mode' : 'Switch to Live Mode'}
            >
              {isLiveMode ? '🔴 LIVE' : '🧪 TEST'}
            </button>
          </div>
          
          {/* Show/Hide Pattern Analysis Checkbox */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '6px',
            padding: '6px 12px',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px',
            border: '1px solid #dee2e6'
          }}>
            <input
              type="checkbox"
              id="showPatternAnalysis"
              checked={showPatternAnalysis}
              onChange={(e) => setShowPatternAnalysis(e.target.checked)}
              style={{
                width: '16px',
                height: '16px',
                cursor: 'pointer'
              }}
            />
            <label 
              htmlFor="showPatternAnalysis"
              style={{ 
                fontSize: '11px', 
                fontWeight: 'bold', 
                color: '#495057',
                cursor: 'pointer',
                userSelect: 'none'
              }}
            >
              Show Analysis
            </label>
          </div>
          
          <button
            onClick={togglePatternModal}
            style={{
              padding: '8px 16px',
              backgroundColor: isPatternModalOpen ? '#dc3545' : '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '12px',
              fontWeight: 'bold',
              cursor: 'pointer',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              transition: 'all 0.3s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              whiteSpace: 'nowrap'
            }}
          >
            {isPatternModalOpen ? 'Close Pattern Analysis' : 'Open Pattern Analysis'}
            <span style={{ fontSize: '14px' }}>
              {isPatternModalOpen ? '▲' : '▼'}
            </span>
          </button>
        </div>
      </div>

      {/* Pattern Prediction Modal */}
      {isPatternModalOpen && streamAnalysis && (
        <div style={{
          marginTop: '15px',
          padding: '15px',
          backgroundColor: '#ffffff',
          borderRadius: '8px',
          border: '1px solid #dee2e6',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          animation: 'slideDown 0.3s ease-out'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '15px',
            paddingBottom: '10px',
            borderBottom: '2px solid #007bff'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
              <h3 style={{
                fontSize: '14px',
                fontWeight: 'bold',
                color: '#007bff',
                margin: 0
              }}>
                Pattern Prediction Analysis
              </h3>
              {highProbabilityBet.length > 0 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginLeft: '15px' }}>
                  {/* Bet Row */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Bet:</span>
                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                      {highProbabilityBet.map((bet, idx) => (
                        <span key={idx} style={{
                          padding: '2px 6px',
                          backgroundColor: bet === 1 ? '#e8f4fd' : '#e8f9e8',
                          color: bet === 1 ? '#007bff' : '#28a745',
                          borderRadius: '4px',
                          fontSize: '10px',
                          fontWeight: 'bold',
                          border: `1px solid ${bet === 1 ? '#b3d9ff' : '#a3d9a3'}`,
                          minWidth: '24px',
                          textAlign: 'center'
                        }}>
                          {bet}
                        </span>
                      ))}
                    </div>
                  </div>
                  {/* Actual Row */}
                  {highProbabilityActualBet.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Actual:</span>
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {highProbabilityActualBet.map((actual, idx) => (
                          <span key={idx} style={{
                            padding: '2px 6px',
                            backgroundColor: '#fff3cd',
                            color: '#856404',
                            borderRadius: '4px',
                            fontSize: '10px',
                            fontWeight: 'bold',
                            border: '1px solid #ffc107',
                            minWidth: '40px',
                            textAlign: 'center'
                          }}>
                            {actual.toFixed(2)}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Converted Row */}
                  {highProbabilityActualConvertedBet.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Converted:</span>
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {highProbabilityActualConvertedBet.map((converted, idx) => (
                          <span key={idx} style={{
                            padding: '2px 6px',
                            backgroundColor: converted === 1 ? '#e8f4fd' : '#e8f9e8',
                            color: converted === 1 ? '#007bff' : '#28a745',
                            borderRadius: '4px',
                            fontSize: '10px',
                            fontWeight: 'bold',
                            border: `1px solid ${converted === 1 ? '#b3d9ff' : '#a3d9a3'}`,
                            minWidth: '24px',
                            textAlign: 'center'
                          }}>
                            {converted}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Matched Series Row */}
                  {matchedSeries.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Matched:</span>
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {matchedSeries.map((matchCount, idx) => {
                          // Color coding: Green: 3/4, Yellow: 2, Red: 0-1
                          let backgroundColor, color, borderColor;
                          if (matchCount >= 3) {
                            backgroundColor = '#d4edda';
                            color = '#155724';
                            borderColor = '#c3e6cb';
                          } else if (matchCount === 2) {
                            backgroundColor = '#fff3cd';
                            color = '#856404';
                            borderColor = '#ffeaa7';
                          } else {
                            backgroundColor = '#f8d7da';
                            color = '#721c24';
                            borderColor = '#f5c6cb';
                          }
                          
                          return (
                            <span key={idx} style={{
                              padding: '2px 6px',
                              backgroundColor,
                              color,
                              borderRadius: '4px',
                              fontSize: '10px',
                              fontWeight: 'bold',
                              border: `1px solid ${borderColor}`,
                              minWidth: '24px',
                              textAlign: 'center'
                            }}>
                              {matchCount}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  {/* Reasoning Row */}
                  {highProbabilityBetReasoning.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', marginTop: '4px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Reasoning:</span>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', flex: 1 }}>
                        {highProbabilityBetReasoning.map((reason, idx) => (
                          <div key={idx} style={{
                            padding: '4px 8px',
                            backgroundColor: '#f8f9fa',
                            borderRadius: '4px',
                            fontSize: '10px',
                            color: '#495057',
                            border: '1px solid #dee2e6',
                            fontFamily: 'monospace'
                          }}>
                            {reason}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            <button
              onClick={togglePatternModal}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                color: '#dc3545',
                cursor: 'pointer',
                fontWeight: 'bold',
                padding: '4px 8px'
              }}
              title="Close modal"
            >
              ×
            </button>
          </div>

          {/* Compact Pattern Prediction Results - All lengths 6-11 */}
          {showPatternAnalysis && (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '6px',
              marginBottom: '15px'
            }}>
              {streamAnalysis.allSubStreams.map((subStreamData, index) => {
              const percentage1 = parseFloat(subStreamData.percentage1);
              const percentage2 = parseFloat(subStreamData.percentage2);
              const totalMatches = subStreamData.countPattern1 + subStreamData.countPattern2;
              const hasHighProbability = (percentage1 > 70 || percentage2 > 70)  &&
                                        totalMatches >= 5;
              // Check if at least one value in the pattern is red (value 1)
              const hasRedLine = subStreamData.subStream.some(bit => bit === 1);
              const isOpportunity = hasRedLine;
              
              return (
              <div key={index} style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '6px 10px',
                backgroundColor: isOpportunity ? '#fff3cd' : '#f8f9fa',
                borderRadius: '4px',
                border: '1px solid #e9ecef',
                borderBottom: hasHighProbability ? '3px solid #dc3545' : '1px solid #e9ecef',
                borderLeft: isOpportunity ? '4px solid #ffc107' : '1px solid #e9ecef'
              }}>
                {/* Length label */}
                <div style={{
                  fontSize: '10px',
                  fontWeight: 'bold',
                  color: '#495057',
                  minWidth: '30px'
                }}>
                  {subStreamData.length}:
                </div>
                
                {/* Substream pattern */}
                <div style={{ display: 'flex', gap: '2px' }}>
                  {subStreamData.subStream.map((bit, bitIndex) => (
                    <div key={bitIndex} style={{
                      width: '16px',
                      height: '16px',
                      borderRadius: '3px',
                      backgroundColor: bit === 2 ? '#28a745' : '#dc3545',
                      color: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '9px',
                      fontWeight: 'bold'
                    }}>
                      {bit}
                    </div>
                  ))}
                </div>
                
                {/* +1 Probability */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '2px 8px',
                  backgroundColor: '#e8f4fd',
                  borderRadius: '3px',
                  border: '1px solid #b3d9ff'
                }}>
                  <span style={{ fontSize: '9px', color: '#007bff', fontWeight: 'bold' }}>+1:</span>
                  <span style={{ fontSize: '10px', color: '#495057', fontWeight: 'bold' }}>{subStreamData.percentage1}%</span>
                  <span style={{ fontSize: '9px', color: '#6c757d' }}>({subStreamData.countPattern1})</span>
                </div>
                
                {/* +2 Probability */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '2px 8px',
                  backgroundColor: '#e8f9e8',
                  borderRadius: '3px',
                  border: '1px solid #a3d9a3'
                }}>
                  <span style={{ fontSize: '9px', color: '#28a745', fontWeight: 'bold' }}>+2:</span>
                  <span style={{ fontSize: '10px', color: '#495057', fontWeight: 'bold' }}>{subStreamData.percentage2}%</span>
                  <span style={{ fontSize: '9px', color: '#6c757d' }}>({subStreamData.countPattern2})</span>
                </div>
              </div>
              );
            })}
            </div>
          )}

          {/* Extension Patterns Section */}
     

          {/* Summary Footer */}
          <div style={{
            marginTop: '15px',
            paddingTop: '10px',
            borderTop: '1px solid #dee2e6',
            fontSize: '10px',
            color: '#6c757d',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div>
              Based on {streamAnalysis.totalBits} total games | {streamAnalysis.totalMatches} total pattern matches
            </div>
            <div style={{
              padding: '4px 8px',
              backgroundColor: '#e9ecef',
              borderRadius: '4px',
              fontWeight: 'bold'
            }}>
              Overall Confidence: {Math.max(streamAnalysis.percentage1, streamAnalysis.percentage2)}%
            </div>
          </div>
        </div>
      )}

      {shouldShowStopMoon && (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          marginTop: '12px',
          padding: '10px',
          backgroundColor: '#dc3545',
          color: 'white',
          borderRadius: '8px',
          fontWeight: 'bold',
          fontSize: '16px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
          animation: 'pulse 2s infinite'
        }}>
          ⚠️ Stop Moon and idle
        </div>
      )}

      <style>
        {`
          @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
          }
          
          @keyframes slideDown {
            from {
              opacity: 0;
              transform: translateY(-20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
        `}
      </style>
    </div>
  );
}

export default HeaderSection;