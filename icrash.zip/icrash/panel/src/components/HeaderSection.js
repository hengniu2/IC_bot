import React, { useMemo, useState, useEffect } from 'react';
import { signalLogger } from '../services/signalLogger';
import FireSignalService from './FireSignalService';

// Helper function to count pattern occurrences in a stream
const countPatternOccurrences = (stream, pattern) => {
  let count = 0;
  for (let i = 0; i <= stream.length - pattern.length; i++) {
    const segment = stream.slice(i, i + pattern.length);
    const isMatch = segment.every((bit, index) => bit === pattern[index]);
    if (isMatch) {
      count++;
    }
  }
  return count;
};

// Generate bet value for Awesome Bet 1 based on awesomeBetQueue1
const generateBetValue = (awesomeBetQueue1) => {
  let n = awesomeBetQueue1.length;
  let count = 0;
  
  // Count backwards from the end until we find a value >= 5
  while (n > 0) {
    n = n - 1;
    if (awesomeBetQueue1[n] >= 5) {
      break; // quit when we find value >= 5
    } else {
      count = count + 1;
    }
  }
  
  // Return based on count
  if (count === 0) return -1;
  if (count === 1) return -1;
  if (count === 2) return -1;
  if (count === 3) return 0;
  if (count === 4) return 0;
  if (count === 5) return 0;
  if (count === 6) return 1;
  if (count === 7) return 1;
  if (count === 8) return 2;
  if (count === 9) return 2;
  if (count == 10) return 2;

  return -1;
};

// Extension by adding last digit repeatedly
const findExtension1Patterns = (totalStream, basePattern) => {
  if (basePattern.length === 0) return [];
  
  const lastDigit = basePattern[basePattern.length - 1];
  const extensions = [];
  
  const patterns = [];
  
  for (let depth = 0; depth <= 4; depth++) {
    const extendedPattern = [...basePattern, ...Array(depth).fill(lastDigit)];
    const count = countPatternOccurrences(totalStream, extendedPattern);
    
    if (count === 0 && depth > 0) {
      break;
    }
    
    patterns.push({
      depth,
      pattern: [...extendedPattern],
      count,
      display: `${basePattern.join('')}${lastDigit.toString().repeat(depth)}`,
      isOriginal: depth === 0,
      isExtension: depth > 0
    });
  }
  
  const totalMatches = patterns.reduce((sum, p) => sum + p.count, 0);
  
  if (totalMatches > 0) {
    extensions.push({
      lastDigit,
      patterns,
      totalMatches
    });
  }
  
  return extensions;
};

function HeaderSection({ lastGeneratedBust, moonPercentResult, gameIdDifferences, gameResults, isLiveMode, onModeChange, isManualHashMode, onManualHashModeChange, onManualHashUpdate, currentHash, onMatchedQueueChange, weatherCondition, lastOpportunityValue }) {
  const [manualHashInput, setManualHashInput] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const diffEntries = Object.entries(gameIdDifferences || {});
  const last14Diffs = diffEntries.slice(0, 14);
  const last14GameResults = gameResults ? [...gameResults].slice(0,14).reverse() : [];

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  // Format time for GMT+9
  const getGMT3Time = () => {
    const now = currentTime;
      const gmtPlus9Offset = 9 * 60; // GMT+9 in minutes
      const localOffset = now.getTimezoneOffset(); // Local offset in minutes
      const offsetDiff = gmtPlus9Offset + localOffset; // Difference in minutes
      
      const gmt9Time = new Date(now.getTime() + offsetDiff * 60 * 1000);
      
      let hours = gmt9Time.getHours();
      const minutes = gmt9Time.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // 0 should be 12
    
    const minutesStr = minutes < 10 ? `0${minutes}` : minutes;
    
    return `${hours}:${minutesStr} ${ampm}`;
  };

  // Get current day of week in EST timezone
  const getESTDayOfWeek = () => {
    const now = currentTime;
    // EST is UTC-5, EDT is UTC-4 (during daylight saving time)
    // Use Intl.DateTimeFormat to get the day in EST/EDT timezone
    const estDate = new Date(now.toLocaleString("en-US", {timeZone: "America/New_York"}));
    return estDate.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  };

  // Check if it's Monday (1), Friday (5), or Saturday (6) in EST
  const isNonOperatingDay = () => {
    const dayOfWeek = getESTDayOfWeek();
    return dayOfWeek === 1 || dayOfWeek === 5 || dayOfWeek === 6; // Monday, Friday, or Saturday
  };

  const binaryStream = last14GameResults.map(result => {
    const bust = result.bust;
    if (bust > 4 || (bust >= 1.5 && bust <= 2)) {
      return 1;
    } else {
      return 0;
    }
  });

  const findPatternIndices = (stream) => {
    const pattern = [0, 0, 0, 0, 0, 0, 1, 0, 0];
    const indices = [];
    for (let i = 0; i <= stream.length - pattern.length; i++) {
      const segment = stream.slice(i, i + pattern.length);
      const isMatch = segment.every((bit, index) => bit === pattern[index]);
      if (isMatch) {
        indices.push(i);
      }
    }
    return indices;
  };

  const patternIndices = findPatternIndices(binaryStream);
  const [isPatternModalOpen, setIsPatternModalOpen] = useState(false);
  const [showPatternAnalysis, setShowPatternAnalysis] = useState(true);
  const [highProbabilityBet, setHighProbabilityBet] = useState([]);
  const [highProbabilityBetReasoning, setHighProbabilityBetReasoning] = useState([]);
  const [highProbabilityActualBet, setHighProbabilityActualBet] = useState([]);
  const [matchedSeries, setMatchedSeries] = useState([]);
  const [awesomeBetQueue1, setAwesomeBetQueue1] = useState([]);
  const [awesomeBet1BetValueQueue, setAwesomeBet1BetValueQueue] = useState([]);
  const [awesomeBet1OpportunityQueue, setAwesomeBet1OpportunityQueue] = useState([]);
  const [awesomeBet1FireSignal, setAwesomeBet1FireSignal] = useState(false);
  const [awesomeBet1BetValue, setAwesomeBet1BetValue] = useState(null);
  const [awesomeBet1ManualBetValue, setAwesomeBet1ManualBetValue] = useState('');
  const [awesomeBetQueue2, setAwesomeBetQueue2] = useState([]);
  const [awesomeBet2Results, setAwesomeBet2Results] = useState([]);
  const prevLastGeneratedBustRef = React.useRef(lastGeneratedBust);
  const prevLastGeneratedBustForAwesomeBetRef = React.useRef(lastGeneratedBust); // Separate ref for Awesome Bet 1 tracking
  const awesomeBetTriggerBustRef = React.useRef(null); // Track the bust value at trigger time: null = not waiting, value = capture next different bust
  const prevWeatherConditionRef = React.useRef(weatherCondition);
  const awesomeBet2IterationCountRef = React.useRef(0); // Track iteration count for Awesome Bet 2

  // Convert actual bets to 1 or 2: >=2 -> 2, <2 -> 1
  const highProbabilityActualConvertedBet = useMemo(() => {
    return highProbabilityActualBet.map(bust => bust >= 2 ? 2 : 1);
  }, [highProbabilityActualBet]);

  // Track previous converted length to detect new additions
  const prevConvertedLengthRef = React.useRef(0);

  // Update matched series when converted values are added
  useEffect(() => {
    const betLength = highProbabilityBet.length;
    const convertedLength = highProbabilityActualConvertedBet.length;
    
    // Check if a new converted value was added
    if (convertedLength > prevConvertedLengthRef.current) {
      // n = length of converted
      const n = convertedLength;
      
      // Need at least 4 values in both arrays to calculate match
      if (betLength >= n && n >= 5) {
        // Get last 5 values from converted: converted[n-5] to converted[n-1]
        const convertedMatched = highProbabilityActualConvertedBet.slice(n - 5, n);
        
        // Get last 5 values from bet: bet[n-5] to bet[n-1]
        const betMatched = highProbabilityBet.slice(n - 5, n);
        
        // Count how many match
        let matchCount = 0;
        for (let i = 0; i < 5; i++) {
          if (betMatched[i] === convertedMatched[i]) {
            matchCount++;
          }
        }
        
        // Add the match count to the matched series array
        setMatchedSeries(prev => [...prev, matchCount]);
      }
      
      // Awesome Bet 1 Logic: If bet says 2 but converted is 1, capture next bet value (Sunny condition only)
      if (betLength >= n && n > 0) {
        const lastBet = highProbabilityBet[n - 1]; // Last bet that corresponds to this converted value
        const lastConverted = highProbabilityActualConvertedBet[n - 1]; // Last converted value
        
        // Check if bet was 2 but converted turned out to be 1, and weather is Sunny
        if (lastBet === 2 && lastConverted === 1 && weatherCondition === 'Sunny') {
          // Track current bust value: capture the next bust value that comes in (different from current)
          const currentBust = lastGeneratedBust;
          awesomeBetTriggerBustRef.current = currentBust; // Track current bust, capture when it changes
          const triggerLog = {
            type: 'TRIGGER',
            timestamp: new Date().toLocaleTimeString(),
            bet: lastBet,
            converted: lastConverted,
            currentBust: currentBust,
            // Updated message for Awesome Bet 1 trigger
            message: 'Trace 3x'
          };
          console.log('[Awesome Bet 1 Signal] 🎯 TRIGGERED:', triggerLog);
          
          // Use the last bet value from the Awesome Bet 1 bet queue if available
          const lastBetQueueValue = awesomeBet1BetValueQueue.length > 0
            ? awesomeBet1BetValueQueue[awesomeBet1BetValueQueue.length - 1]
            : null;
          
          // Only fire signal if last bet value is not -1; if -1 or null, do not fire
          if (lastBetQueueValue !== null && lastBetQueueValue !== -1) {
            signalLogger.logSignal({
              botName: 'AwesomeBet1',
              betValue: lastBetQueueValue.toString(),
              status: 'pending',
              timestamp: new Date(),
              error: null,
              retryCount: 0,
              gameHash: null,
              lastValue: currentBust,
              webhookUrl: '',
              message: triggerLog.message,
              signalType: 'TRIGGER'
            });
          }
        }
      }
      
      // Update the ref to track the new length
      prevConvertedLengthRef.current = convertedLength;
    }
  }, [highProbabilityActualConvertedBet, highProbabilityBet, weatherCondition, awesomeBet1BetValueQueue]);

  // Capture bust value for awesome bet queue1 - watch for next bust value after trigger
  useEffect(() => {
    // Check if we're waiting for a capture and if lastGeneratedBust has changed
    if (awesomeBetTriggerBustRef.current !== null && lastGeneratedBust !== null) {
      // Check if the bust value has changed from the trigger value (new bust arrived)
      if (lastGeneratedBust !== awesomeBetTriggerBustRef.current && 
          lastGeneratedBust !== prevLastGeneratedBustForAwesomeBetRef.current) {
        // This is the next bust value after the trigger - capture it
        const capturedBust = lastGeneratedBust;
        // Add to queue first, then generate bet value
        const updatedQueue = [...awesomeBetQueue1, capturedBust];
        const betValue = generateBetValue(updatedQueue);
        
        const captureLog = {
          type: 'CAPTURE',
          timestamp: new Date().toLocaleTimeString(),
          capturedValue: capturedBust,
          triggerBust: awesomeBetTriggerBustRef.current,
          generatedBetValue: betValue,
          message: `Successfully captured bust value ${capturedBust.toFixed(2)}x (trigger was at ${awesomeBetTriggerBustRef.current !== null ? awesomeBetTriggerBustRef.current.toFixed(2) : 'N/A'}x). Generated bet value: ${betValue}`
        };
        // Keep console log for local debugging, but do not send a separate signal log entry
        console.log('[Awesome Bet 1 Signal] ✅ CAPTURED:', captureLog);
        // Update queue and bet value state
        setAwesomeBetQueue1(updatedQueue);
        setAwesomeBet1BetValue(betValue);
        setAwesomeBet1BetValueQueue(prev => [...prev, betValue]); // Add to bet value queue
        // Add last opportunity value to opportunity queue
        if (lastOpportunityValue !== null && lastOpportunityValue !== undefined) {
          setAwesomeBet1OpportunityQueue(prev => [...prev, lastOpportunityValue]);
        }
        // Trigger fire signal
        setAwesomeBet1FireSignal(true);
        console.log('[Awesome Bet 1 Signal] 🎯 Generated Bet Value:', {
          queue: updatedQueue.map(v => v.toFixed(2)),
          betValue: betValue,
          queueSize: updatedQueue.length
        });
        // Reset the trigger
        awesomeBetTriggerBustRef.current = null;
      }
    }
    
    // Update the previous bust ref for Awesome Bet 1 tracking
    prevLastGeneratedBustForAwesomeBetRef.current = lastGeneratedBust;
  }, [lastGeneratedBust, lastOpportunityValue]);

  // Pass matched queue (matchedSeries) to parent component
  useEffect(() => {
    if (onMatchedQueueChange) {
      onMatchedQueueChange(matchedSeries);
    }
  }, [matchedSeries, onMatchedQueueChange]);

  // Track previous converted length for Awesome Bet 2
  const prevConvertedLengthForBet2Ref = React.useRef(0);
  const awesomeBet2ActiveRef = React.useRef(false); // Track if Awesome Bet 2 is active
  const awesomeBet2TransitionTypeRef = React.useRef(null); // 'cloudy-to-sunny' or 'sunny-to-rainy'

  // Handle Awesome Bet 2 based on weather condition transitions
  useEffect(() => {
    const prevCondition = prevWeatherConditionRef.current;
    const currentCondition = weatherCondition;
    
    // Cloudy -> Sunny transition: Start Awesome Bet 2
    if (prevCondition === 'Cloudy' && currentCondition === 'Sunny') {
      awesomeBet2ActiveRef.current = true;
      awesomeBet2TransitionTypeRef.current = 'cloudy-to-sunny';
      awesomeBet2IterationCountRef.current = 0;
      // Clear previous queues
      setAwesomeBetQueue2([]);
      setAwesomeBet2Results([]);
      console.log('[Awesome Bet 2] Cloudy->Sunny transition detected');
    }
    
    // Sunny -> Rainy transition: Start Awesome Bet 2
    if (prevCondition === 'Cloudy' && currentCondition === 'Rainy') {
      awesomeBet2ActiveRef.current = true;
      awesomeBet2TransitionTypeRef.current = 'sunny-to-rainy';
      awesomeBet2IterationCountRef.current = 0;
      // Clear previous queues
      setAwesomeBetQueue2([]);
      setAwesomeBet2Results([]);
      console.log('[Awesome Bet 2] Sunny->Rainy transition detected');
    }
    
    // Reset when condition changes to something else
    if (prevCondition !== currentCondition && 
        !(prevCondition === 'Cloudy' && currentCondition === 'Sunny') &&
        !(prevCondition === 'Cloudy' && currentCondition === 'Rainy')) {
      awesomeBet2ActiveRef.current = false;
      awesomeBet2TransitionTypeRef.current = null;
    }
    
    // Update previous weather condition
    prevWeatherConditionRef.current = currentCondition;
  }, [weatherCondition]);

  // Handle Awesome Bet 2 when new converted values are added
  useEffect(() => {
    const convertedLength = highProbabilityActualConvertedBet.length;
    
    // Check if a new converted value was added and Awesome Bet 2 is active
    if (convertedLength > prevConvertedLengthForBet2Ref.current && awesomeBet2ActiveRef.current && awesomeBet2IterationCountRef.current < 3) {
      const lastConvertedValue = highProbabilityActualConvertedBet[convertedLength - 1];
      const lastBetValue = awesomeBet1BetValueQueue.length > 0
        ? awesomeBet1BetValueQueue[awesomeBet1BetValueQueue.length - 1]
        : null;
      
      if (lastBetValue !== null && lastConvertedValue !== null) {
        let valueToAdd = null;
        
        if (awesomeBet2TransitionTypeRef.current === 'cloudy-to-sunny') {
          // Follow last bet value from bet queue
          valueToAdd = lastBetValue;
        } else if (awesomeBet2TransitionTypeRef.current === 'cloudy-to-rainy') {
          // Invert the bet value: 1->2, 2->1
          valueToAdd = lastBetValue === 1 ? 2 : (lastBetValue === 2 ? 1 : lastBetValue);
        }
        
        if (valueToAdd !== null) {
          // Add to Awesome Bet 2 queue and results
          setAwesomeBetQueue2(prev => [...prev, valueToAdd]);
          setAwesomeBet2Results(prev => [...prev, lastConvertedValue]);
          
          awesomeBet2IterationCountRef.current += 1;
          
          console.log('[Awesome Bet 2] Added values', {
            transitionType: awesomeBet2TransitionTypeRef.current,
            betValue: valueToAdd,
            convertedValue: lastConvertedValue,
            iteration: awesomeBet2IterationCountRef.current
          });
        }
      }
    }
    
    // Update the ref to track the new length
    prevConvertedLengthForBet2Ref.current = convertedLength;
  }, [highProbabilityActualConvertedBet, awesomeBet1BetValueQueue]);

  // Check if queue[i] == result2[i] and stop if they match
  useEffect(() => {
    if (awesomeBetQueue2.length > 0 && awesomeBet2Results.length > 0 && 
        awesomeBetQueue2.length === awesomeBet2Results.length && awesomeBet2ActiveRef.current) {
      const lastIndex = awesomeBetQueue2.length - 1;
      const lastQueueValue = awesomeBetQueue2[lastIndex];
      const lastResultValue = awesomeBet2Results[lastIndex];
      
      // If they match, stop adding
      if (lastQueueValue === lastResultValue) {
        console.log('[Awesome Bet 2] Queue and Results match, stopping', {
          index: lastIndex,
          queueValue: lastQueueValue,
          resultValue: lastResultValue
        });
        awesomeBet2ActiveRef.current = false;
      }
    }
  }, [awesomeBetQueue2, awesomeBet2Results]);

  const streamAnalysis = useMemo(() => {
    if (!gameResults || gameResults.length === 0) {
      return null;
    }

    const totalStream = gameResults.map(result => 
      result.bust >= 2 ? 2 : 1
    );

    // Calculate for all lengths from 6 to 11
    const allSubStreams = [];
    for (let len = 6; len <= 11; len++) {
      const subStream = gameResults.slice(0, len).reverse().map(result => 
        result.bust >= 2 ? 2 : 1
      );

      const extendedPattern1 = [...subStream, 1];
      const extendedPattern2 = [...subStream, 2];

      const countPattern1 = countPatternOccurrences(totalStream, extendedPattern1);
      const countPattern2 = countPatternOccurrences(totalStream, extendedPattern2);

      const totalMatches = countPattern1 + countPattern2;
      const percentage1 = totalMatches > 0 ? ((countPattern1 / totalMatches) * 100).toFixed(1) : '0.0';
      const percentage2 = totalMatches > 0 ? ((countPattern2 / totalMatches) * 100).toFixed(1) : '0.0';

      allSubStreams.push({
        length: len,
        subStream,
        extendedPattern1,
        extendedPattern2,
        countPattern1,
        countPattern2,
        percentage1,
        percentage2,
        totalMatches
      });
    }

    return {
      totalStream,
      totalBits: totalStream.length,
      allSubStreams
    };
  }, [gameResults]);

  // Track high probability bets - add to array when hasHighProbability is detected
  const prevStreamAnalysisRef = React.useRef(null);
  const processedAnalysisRef = React.useRef(new Set()); // Track processed analyses
  
  useEffect(() => {
    if (!streamAnalysis) return;
    
    // Create a unique key for this analysis based on allSubStreams
    const analysisKey = JSON.stringify(streamAnalysis.allSubStreams);
    
    // Skip if this exact analysis was already processed
    if (processedAnalysisRef.current.has(analysisKey)) {
      return;
    }
    
    // Check if streamAnalysis has changed (new analysis)
    const analysisChanged = analysisKey !== JSON.stringify(prevStreamAnalysisRef.current?.allSubStreams);
    
    if (analysisChanged) {
      // Mark this analysis as processed immediately to prevent duplicate processing
      processedAnalysisRef.current.add(analysisKey);
      
      // Clear previous reasoning when new analysis comes
      setHighProbabilityBetReasoning([]);
      
      const betsToAdd = [];
      const reasoningToAdd = [];
      
      // Priority order: P3 (Priority 3 - Highest) > P2 (Priority 2) > P1 (Priority 1 - Lowest)
      // Strict priority: If P3 meets, add by P3 and ignore P2, P1. If P2 meets (and P3 didn't), add by P2 and ignore P1. If P1 meets (and P3, P2 didn't), add by P1.
      // Within each priority, if both percentage1 and percentage2 meet, only add value by percentage1
      
      let anyBetAdded = false; // Track if any bet was added to prevent lower priorities
      
      // PRIORITY 3 (Highest): Check length 10 and 11 for percentage > 80 and count > 2
      if (!anyBetAdded) {
        for (let len = 10; len <= 11; len++) {
          const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
          if (subStreamData) {
            const percentage1 = parseFloat(subStreamData.percentage1);
            const percentage2 = parseFloat(subStreamData.percentage2);
            const countPattern1 = subStreamData.countPattern1;
            const countPattern2 = subStreamData.countPattern2;
            
            // Priority: If both percentage1 and percentage2 meet, only add by percentage1
            // For length 10, 11: if (percentage1 > 80) && (count > 2), add 2
            if (percentage1 > 80 && countPattern1 > 2) {
              betsToAdd.push(2);
              reasoningToAdd.push(`Len${len}: P1>80% (${percentage1.toFixed(1)}%) & count>2 (${countPattern1}) [Priority 3]`);
              anyBetAdded = true;
              break; // If percentage1 meets, ignore percentage2 and break
            }
            
            // For length 10, 11: if (percentage2 > 80) && (count > 2), add 1
            // Only check if percentage1 didn't meet
            if (percentage2 > 80 && countPattern2 > 2) {
              betsToAdd.push(1);
              reasoningToAdd.push(`Len${len}: P2>80% (${percentage2.toFixed(1)}%) & count>2 (${countPattern2}) [Priority 3]`);
              anyBetAdded = true;
            }
            
            // If any condition met, break (don't check other lengths)
            if (anyBetAdded) break;
          }
        }
      }
      
      // PRIORITY 2 (Second): Check if at least 5 lengths 6-11 have percentage >= 50
      // Only check if Priority 3 didn't meet
      if (!anyBetAdded) {
        const len11Data = streamAnalysis.allSubStreams.find(s => s.length === 11);
        const shouldOmitLen11 = len11Data && len11Data.countPattern1 === 0 && len11Data.countPattern2 === 0;
        const maxLen = shouldOmitLen11 ? 10 : 11;
        
        let countValidP1 = 0;
        let countValidP2 = 0;
        for (let len = 6; len <= maxLen; len++) {
          const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
          if (subStreamData) {
            const p1 = parseFloat(subStreamData.percentage1);
            const p2 = parseFloat(subStreamData.percentage2);
            if (p1 >= 50) {
              countValidP1++;
            }
            if (p2 >= 50) {
              countValidP2++;
            }
          }
        }
        
        const lenRange = shouldOmitLen11 ? 'len6-10' : 'len6-11';
        const totalLengths = maxLen - 6 + 1; // 6 to maxLen inclusive
        
        // Priority: If both P1 and P2 meet, only add by P1
        // Add 1 if P1 condition is met
        if (countValidP1 >= 5) {
          betsToAdd.push(1);
          reasoningToAdd.push(`At least 5 of ${lenRange}: P1>=50% (${countValidP1}/${totalLengths}) [Priority 2]`);
          anyBetAdded = true;
        } else if (countValidP2 >= 5) {
          // Add 2 only if P1 condition didn't meet
          betsToAdd.push(2);
          reasoningToAdd.push(`At least 5 of ${lenRange}: P2>=50% (${countValidP2}/${totalLengths}) [Priority 2]`);
          anyBetAdded = true;
        }
      }
      
      // PRIORITY 1 (Lowest): High probability at specific length with continuation
      // Only check if Priority 3 and Priority 2 didn't meet
      if (!anyBetAdded) {
        const highProbLengths = [];
        streamAnalysis.allSubStreams.forEach((subStreamData) => {
          const percentage1 = parseFloat(subStreamData.percentage1);
          const percentage2 = parseFloat(subStreamData.percentage2);
          const totalMatches = subStreamData.countPattern1 + subStreamData.countPattern2;
          const hasHighProbability = (percentage1 > 70 || percentage2 > 70) && totalMatches >= 5;
          
          if (hasHighProbability) {
            highProbLengths.push({
              length: subStreamData.length,
              percentage1,
              percentage2
            });
          }
        });
        
        for (const { length, percentage1, percentage2 } of highProbLengths) {
          // Check if percentage1 > 70, then verify all lengths from this length to 11 have percentage1 >= 50
          // Omit len 11 if both count1 and count2 are 0
          // Priority: If both percentage1 and percentage2 meet, only add by percentage1
          if (percentage1 > 70) {
            let allValid = true;
            const len11Data = streamAnalysis.allSubStreams.find(s => s.length === 11);
            const shouldOmitLen11 = len11Data && len11Data.countPattern1 === 0 && len11Data.countPattern2 === 0;
            const maxLen = shouldOmitLen11 ? 10 : 11;
            
            for (let len = length; len <= maxLen; len++) {
              const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
              if (subStreamData) {
                const p1 = parseFloat(subStreamData.percentage1);
                if (p1 < 50) {
                  allValid = false;
                  break;
                }
              }
            }
            if (allValid) {
              betsToAdd.push(1);
              const lenRange = shouldOmitLen11 ? `len${length}-10` : `len${length}-11`;
              reasoningToAdd.push(`Len${length}: P1>70% (${percentage1.toFixed(1)}%) & all ${lenRange} P1>=50% [Priority 1]`);
              anyBetAdded = true;
              break; // If percentage1 meets, ignore percentage2 and break
            }
          }
          
          // Check if percentage2 > 70, then verify all lengths from this length to 11 have percentage2 >= 50
          // Omit len 11 if both count1 and count2 are 0
          // Only check if percentage1 didn't meet
          if (percentage2 > 70) {
            let allValid = true;
            const len11Data = streamAnalysis.allSubStreams.find(s => s.length === 11);
            const shouldOmitLen11 = len11Data && len11Data.countPattern1 === 0 && len11Data.countPattern2 === 0;
            const maxLen = shouldOmitLen11 ? 10 : 11;
            
            for (let len = length; len <= maxLen; len++) {
              const subStreamData = streamAnalysis.allSubStreams.find(s => s.length === len);
              if (subStreamData) {
                const p2 = parseFloat(subStreamData.percentage2);
                if (p2 < 50) {
                  allValid = false;
                  break;
                }
              }
            }
            if (allValid) {
              betsToAdd.push(2);
              const lenRange = shouldOmitLen11 ? `len${length}-10` : `len${length}-11`;
              reasoningToAdd.push(`Len${length}: P2>70% (${percentage2.toFixed(1)}%) & all ${lenRange} P2>=50% [Priority 1]`);
              anyBetAdded = true;
            }
          }
          
          // If any condition met at this length, break (don't check other lengths)
          if (anyBetAdded) break;
        }
      }
      
      // Add bet values that were determined by the logic
      // IMPORTANT: Even if multiple internal conditions match, we only keep ONE bet per analysis,
      // respecting the highest-priority logic that fired first.
      if (betsToAdd.length > 0) {
        // If somehow multiple bets accumulated, keep only the first one (highest priority in this flow)
        const finalBet = betsToAdd[0];
        const finalReasoning = reasoningToAdd.length > 0 ? [reasoningToAdd[0]] : [];

        setHighProbabilityBet(prev => [...prev, finalBet]);
        setHighProbabilityBetReasoning(finalReasoning);
      }
      
      prevStreamAnalysisRef.current = streamAnalysis;
    }
  }, [streamAnalysis]);

  // Track actual bust results after high probability bets
  const betsAddedRef = React.useRef(0);
  
  useEffect(() => {
    // Track when new bets are added
    if (highProbabilityBet.length > betsAddedRef.current) {
      betsAddedRef.current = highProbabilityBet.length;
    }
  }, [highProbabilityBet]);

  useEffect(() => {
    if (lastGeneratedBust !== null && 
        prevLastGeneratedBustRef.current !== lastGeneratedBust &&
        betsAddedRef.current > highProbabilityActualBet.length) {
      // New bust generated after bets were added, add it to actual bet array
      setHighProbabilityActualBet(prev => [...prev, lastGeneratedBust]);
    }
    prevLastGeneratedBustRef.current = lastGeneratedBust;
  }, [lastGeneratedBust, highProbabilityActualBet.length]);

  const shouldShowNauseatedIcon = (bust) => {
    return bust < 1.5 || (bust >= 2 && bust <= 3);
  };

  const lastDiffValue = last14Diffs.length > 0 ? last14Diffs[0][1] : null;
  const shouldShowStopMoon = lastDiffValue > 14;

  const togglePatternModal = () => {
    setIsPatternModalOpen(!isPatternModalOpen);
  };



  return (
    <div
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 1000,
        background: 'linear-gradient(135deg, #fafafa 0%, #f5f5f5 100%)',
        borderBottom: '1px solid #e0e0e0',
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
        padding: '10px 20px',
      }}
    >
      {/* Non-Operating Day Message - Top Center */}
      {isNonOperatingDay() && (
        <div style={{
          position: 'absolute',
          top: '10px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 1003,
          backgroundColor: '#dc3545',
          color: 'white',
          padding: '10px 20px',
          borderRadius: '8px',
          fontSize: '16px',
          fontWeight: 'bold',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.3)',
          whiteSpace: 'nowrap',
          textAlign: 'center'
        }}>
          We don't operate Monday, Friday and Saturday in EST
        </div>
      )}

      {/* Weather Condition Radio Buttons - Top Left */}
      <div style={{
        position: 'absolute',
        top: '10px',
        left: '10px',
        zIndex: 1002,
        display: 'flex',
        gap: '15px',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        padding: '8px 15px',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2)',
        border: '2px solid #007bff'
      }}>
        <span style={{ fontWeight: 'bold', fontSize: '14px', marginRight: '5px' }}>Condition:</span>
        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
          <input
            type="radio"
            name="weatherCondition"
            value="Sunny"
            checked={weatherCondition === 'Sunny'}
            readOnly
            style={{ cursor: 'pointer' }}
          />
          <span style={{ color: '#ffa500', fontWeight: weatherCondition === 'Sunny' ? 'bold' : 'normal' }}>
            ☀️ Sunny
          </span>
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
          <input
            type="radio"
            name="weatherCondition"
            value="Rainy"
            checked={weatherCondition === 'Rainy'}
            readOnly
            style={{ cursor: 'pointer' }}
          />
          <span style={{ color: '#4169e1', fontWeight: weatherCondition === 'Rainy' ? 'bold' : 'normal' }}>
            🌧️ Rainy
          </span>
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
          <input
            type="radio"
            name="weatherCondition"
            value="Cloudy"
            checked={weatherCondition === 'Cloudy'}
            readOnly
            style={{ cursor: 'pointer' }}
          />
          <span style={{ color: '#808080', fontWeight: weatherCondition === 'Cloudy' ? 'bold' : 'normal' }}>
            ☁️ Cloudy
          </span>
        </label>
      </div>

      {/* Time Display - Top Center */}
      <div style={{
        position: 'absolute',
        top: isNonOperatingDay() ? '60px' : '10px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 1001,
        transition: 'top 0.3s ease'
      }}>
        <div style={{
          backgroundColor: '#007bff',
          color: 'white',
          padding: '6px 20px',
          borderRadius: '8px',
          fontSize: '18px',
          fontWeight: 'bold',
          fontFamily: 'monospace',
          letterSpacing: '1px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
          whiteSpace: 'nowrap'
        }}>
          {getGMT3Time()} <span style={{ fontSize: '12px', fontWeight: 'normal' }}>GMT+9</span>
        </div>
      </div>

      {/* First Row: Last Bust + Last Opportunity + Percent Results */}
      <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', flexWrap: 'wrap', gap: '15px', marginTop: isNonOperatingDay() ? '100px' : '50px', transition: 'margin-top 0.3s ease' }}>
        {lastGeneratedBust !== null && (
          <div style={{ padding: '10px 20px', backgroundColor: lastGeneratedBust > 2 ? '#28a745' : '#dc3545', color: 'white', borderRadius: '8px', fontWeight: 'bold', fontSize: '16px', minWidth: '120px', textAlign: 'center', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
            Last: {lastGeneratedBust.toFixed(2)}x
          </div>
        )}
        {lastOpportunityValue !== null && lastOpportunityValue !== undefined && (
          <div style={{ padding: '10px 20px', backgroundColor: '#ffc107', color: '#856404', borderRadius: '8px', fontWeight: 'bold', fontSize: '16px', minWidth: '120px', textAlign: 'center', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
            Opportunity: {lastOpportunityValue.toFixed(2)}
          </div>
        )}
        {moonPercentResult && moonPercentResult.length > 0 && (
          <div style={{ padding: '10px 20px', backgroundColor: '#f8fbfd', borderRadius: '8px', fontSize: '14px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', whiteSpace: 'nowrap' }}>
            {moonPercentResult.map((res) => `${res.total}: ${res.percentageOver10}`).join(' | ')}
          </div>
        )}
      </div>

      {/* Second Row: Last 14 Game Results */}
      {last14GameResults.length > 0 && (
        <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', flexWrap: 'wrap', gap: '15px', marginTop: '12px' }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: 1 }}>
            {last14GameResults.map((result, index) => {
              const showNauseatedIcon = shouldShowNauseatedIcon(result.bust);
              return (
                <div key={result.gameId || index} style={{ backgroundColor: result.bust >= 10 ? '#e0a800' : result.bust >= 2 ? '#198754' : '#c82333', color: 'white', borderRadius: '6px', padding: '6px 10px', fontWeight: 'bold', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', minWidth: '50px', textAlign: 'center', position: 'relative' }}>
                  {result.bust?.toFixed(2)}x
                  {showNauseatedIcon && (
                    <span style={{ position: 'absolute', top: '-6px', right: '-6px', fontSize: '14px', background: 'rgba(255, 255, 255, 0.9)', borderRadius: '50%', width: '18px', height: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 1px 2px rgba(0,0,0,0.2)' }}>🤢</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Third Row: Game ID Differences + 4V Section + Pattern Modal Toggle */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '15px', marginTop: '12px' }}>
        {/* Left Side: Game ID Differences and 4V Section */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1, minWidth: '300px' }}>
          {last14Diffs.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {last14Diffs.reverse().map(([gameId, diff], index) => (
                <div key={index} style={{ backgroundColor: diff > 10 ? 'orange' : '#e0e0e0', color: diff > 10 ? 'white' : '#333', borderRadius: '6px', padding: '6px 10px', fontWeight: 'bold', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', minWidth: '50px', textAlign: 'center' }}>
                  {diff}
                </div>
              ))}
            </div>
          )}

          {/* 4V Section */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', background: '#f8f9fa', padding: '8px 12px', borderRadius: '8px', border: '1px solid #dee2e6', position: 'relative' }}>
            <span style={{ fontSize: '12px', fontWeight: 'bold', color: '#495057', marginRight: '8px', whiteSpace: 'nowrap' }}>4V:</span>
            <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', position: 'relative' }}>
              {binaryStream.map((bit, index) => {
                const isInPattern = patternIndices.some(startIndex => index >= startIndex && index < startIndex + 9);
                return (
                  <div key={index} style={{ width: '20px', height: '20px', borderRadius: '4px', backgroundColor: bit === 1 ? '#28a745' : '#dc3545', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 'bold', boxShadow: '0 1px 2px rgba(0,0,0,0.1)', position: 'relative', zIndex: 2 }}>
                    {bit}
                    {isInPattern && <div style={{ position: 'absolute', bottom: '-2px', left: '0', width: '100%', height: '2px', backgroundColor: '#007bff', zIndex: 1 }} />}
                  </div>
                );
              })}
              {patternIndices.length > 0 && <div style={{ position: 'absolute', top: '-15px', left: `${patternIndices[0] * 24}px`, width: '216px', height: '2px', backgroundColor: '#007bff', zIndex: 1 }} />}
            </div>
            {patternIndices.length > 0 && <div style={{ position: 'absolute', top: '-8px', right: '8px', backgroundColor: '#007bff', color: 'white', fontSize: '9px', fontWeight: 'bold', padding: '2px 6px', borderRadius: '10px', zIndex: 3 }}>PATTERN FOUND</div>}
          </div>
        </div>

        {/* Right Side: Mode Toggle and Pattern Modal Toggle Button */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          {/* Manual Hash Mode Toggle */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '6px',
            padding: '6px 12px',
            backgroundColor: '#fff3cd',
            borderRadius: '8px',
            border: `1px solid ${isManualHashMode ? '#ffc107' : '#dee2e6'}`
          }}>
            <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#856404' }}>
              Hash:
            </span>
            <button
              onClick={() => {
                onManualHashModeChange(!isManualHashMode);
                if (!isManualHashMode && currentHash) {
                  setManualHashInput(currentHash);
                }
              }}
              style={{
                padding: '4px 10px',
                backgroundColor: isManualHashMode ? '#ffc107' : '#e9ecef',
                color: isManualHashMode ? '#856404' : '#6c757d',
                border: 'none',
                borderRadius: '4px',
                fontSize: '10px',
                fontWeight: 'bold',
                cursor: 'pointer',
                whiteSpace: 'nowrap'
              }}
              title={isManualHashMode ? 'Switch to Extension Mode' : 'Switch to Manual Hash Mode'}
            >
              {isManualHashMode ? '✏️ MANUAL' : '🔌 EXT'}
            </button>
          </div>
          
          {/* Manual Hash Input (shown when in manual mode) */}
          {isManualHashMode && (
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '6px',
              padding: '4px 8px',
              backgroundColor: '#fff',
              borderRadius: '6px',
              border: '1px solid #ffc107'
            }}>
              <input
                type="text"
                value={manualHashInput}
                onChange={(e) => setManualHashInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    onManualHashUpdate(manualHashInput);
                  }
                }}
                placeholder="Enter hash..."
                style={{
                  padding: '4px 8px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  fontSize: '11px',
                  width: '200px',
                  fontFamily: 'monospace'
                }}
              />
              <button
                onClick={() => onManualHashUpdate(manualHashInput)}
                style={{
                  padding: '4px 10px',
                  backgroundColor: '#28a745',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '10px',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
                title="Update hash"
              >
                ✓
              </button>
            </div>
          )}
          
          {/* Mode Toggle Switch */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '8px',
            padding: '6px 12px',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px',
            border: '1px solid #dee2e6'
          }}>
            <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057' }}>
              Mode:
            </span>
            <button
              onClick={() => onModeChange(!isLiveMode)}
              style={{
                padding: '6px 14px',
                backgroundColor: isLiveMode ? '#28a745' : '#ffc107',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '11px',
                fontWeight: 'bold',
                cursor: 'pointer',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                transition: 'all 0.3s ease',
                whiteSpace: 'nowrap'
              }}
              title={isLiveMode ? 'Switch to Test Mode' : 'Switch to Live Mode'}
            >
              {isLiveMode ? '🔴 LIVE' : '🧪 TEST'}
            </button>
          </div>
          
          {/* Show/Hide Pattern Analysis Checkbox */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '6px',
            padding: '6px 12px',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px',
            border: '1px solid #dee2e6'
          }}>
            <input
              type="checkbox"
              id="showPatternAnalysis"
              checked={showPatternAnalysis}
              onChange={(e) => setShowPatternAnalysis(e.target.checked)}
              style={{
                width: '16px',
                height: '16px',
                cursor: 'pointer'
              }}
            />
            <label 
              htmlFor="showPatternAnalysis"
              style={{ 
                fontSize: '11px', 
                fontWeight: 'bold', 
                color: '#495057',
                cursor: 'pointer',
                userSelect: 'none'
              }}
            >
              Show Analysis
            </label>
          </div>
          
          <button
            onClick={togglePatternModal}
            style={{
              padding: '8px 16px',
              backgroundColor: isPatternModalOpen ? '#dc3545' : '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '12px',
              fontWeight: 'bold',
              cursor: 'pointer',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              transition: 'all 0.3s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              whiteSpace: 'nowrap'
            }}
          >
            {isPatternModalOpen ? 'Close Pattern Analysis' : 'Open Pattern Analysis'}
            <span style={{ fontSize: '14px' }}>
              {isPatternModalOpen ? '▲' : '▼'}
            </span>
          </button>
        </div>
      </div>

      {/* Pattern Prediction Modal */}
      {isPatternModalOpen && streamAnalysis && (
        <div style={{
          marginTop: '15px',
          padding: '15px',
          backgroundColor: '#ffffff',
          borderRadius: '8px',
          border: '1px solid #dee2e6',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          animation: 'slideDown 0.3s ease-out'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '15px',
            paddingBottom: '10px',
            borderBottom: '2px solid #007bff'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
              <h3 style={{
                fontSize: '14px',
                fontWeight: 'bold',
                color: '#007bff',
                margin: 0
              }}>
                Pattern Prediction Analysis
              </h3>
              {highProbabilityBet.length > 0 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginLeft: '15px' }}>
                  {/* Line 1: Bet Row */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Bet:</span>
                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                      {highProbabilityBet.map((bet, idx) => (
                        <span key={idx} style={{
                          padding: '2px 6px',
                          backgroundColor: bet === 1 ? '#e8f4fd' : '#e8f9e8',
                          color: bet === 1 ? '#007bff' : '#28a745',
                          borderRadius: '4px',
                          fontSize: '10px',
                          fontWeight: 'bold',
                          border: `1px solid ${bet === 1 ? '#b3d9ff' : '#a3d9a3'}`,
                          minWidth: '24px',
                          textAlign: 'center'
                        }}>
                          {bet}
                        </span>
                      ))}
                    </div>
                  </div>
                  {/* Line 2: Converted Row */}
                  {highProbabilityActualConvertedBet.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Converted:</span>
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {highProbabilityActualConvertedBet.map((converted, idx) => (
                          <span key={idx} style={{
                            padding: '2px 6px',
                            backgroundColor: converted === 1 ? '#e8f4fd' : '#e8f9e8',
                            color: converted === 1 ? '#007bff' : '#28a745',
                            borderRadius: '4px',
                            fontSize: '10px',
                            fontWeight: 'bold',
                            border: `1px solid ${converted === 1 ? '#b3d9ff' : '#a3d9a3'}`,
                            minWidth: '24px',
                            textAlign: 'center'
                          }}>
                            {converted}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Line 3: Actual Row */}
                  {highProbabilityActualBet.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Actual:</span>
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {highProbabilityActualBet.map((actual, idx) => (
                          <span key={idx} style={{
                            padding: '2px 6px',
                            backgroundColor: '#fff3cd',
                            color: '#856404',
                            borderRadius: '4px',
                            fontSize: '10px',
                            fontWeight: 'bold',
                            border: '1px solid #ffc107',
                            minWidth: '24px',
                            textAlign: 'center'
                          }}>
                            {actual.toFixed(2)}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Line 3: Matched Series Row */}
                  {matchedSeries.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Matched:</span>
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {/* 3 empty spaces at the start */}
                        {[null, null, null, null].map((_, idx) => (
                          <span key={`empty-${idx}`} style={{
                            padding: '2px 6px',
                            backgroundColor: 'transparent',
                            color: 'transparent',
                            borderRadius: '4px',
                            fontSize: '10px',
                            fontWeight: 'bold',
                            border: '1px solid transparent',
                            minWidth: '24px',
                            textAlign: 'center'
                          }}>
                            &nbsp;
                          </span>
                        ))}
                        {/* Actual matched values - show only last 2 */}
                        {matchedSeries.map((matchCount, idx) => {
                          // Color coding: Green: 3/4, Yellow: 2, Red: 0-1
                          let backgroundColor, color, borderColor;
                          if (matchCount >= 4) {
                            backgroundColor = '#d4edda';
                            color = '#155724';
                            borderColor = '#c3e6cb';
                          } else if (matchCount <= 1) {
                            backgroundColor = '#f8d7da';
                            color = '#721c24';
                            borderColor = '#f5c6cb';
                          } else {
                            backgroundColor = '#fff3cd';
                            color = '#856404';
                            borderColor = '#ffeaa7';
                          }
                          
                          return (
                            <span key={idx} style={{
                              padding: '2px 6px',
                              backgroundColor,
                              color,
                              borderRadius: '4px',
                              fontSize: '10px',
                              fontWeight: 'bold',
                              border: `1px solid ${borderColor}`,
                              minWidth: '24px',
                              textAlign: 'center'
                            }}>
                              {matchCount}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  {/* Awesome Bet Queue 1 Row + Opportunity Queue + Bet Value Queue + Manual Edit */}
                  {(awesomeBetQueue1.length > 0 || awesomeBet1BetValueQueue.length > 0 || awesomeBet1OpportunityQueue.length > 0) && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '4px' }}>
                      {/* Awesome Bet 1 Queue */}
                      {awesomeBetQueue1.length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Awesome Bet 1:</span>
                          <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                            {awesomeBetQueue1.map((bust, idx) => (
                              <span key={idx} style={{
                                padding: '2px 6px',
                                backgroundColor: '#fff3cd',
                                color: '#856404',
                                borderRadius: '4px',
                                fontSize: '10px',
                                fontWeight: 'bold',
                                border: '1px solid #ffc107',
                                minWidth: '40px',
                                textAlign: 'center'
                              }}>
                                {bust.toFixed(2)}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {/* Opportunity Queue - on next line, above bet queue */}
                      {awesomeBet1OpportunityQueue.length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Opportunity:</span>
                          <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                            {awesomeBet1OpportunityQueue.map((opp, idx) => (
                              <span key={idx} style={{
                                padding: '2px 6px',
                                backgroundColor: '#fff3cd',
                                color: '#856404',
                                borderRadius: '4px',
                                fontSize: '10px',
                                fontWeight: 'bold',
                                border: '1px solid #ffc107',
                                minWidth: '40px',
                                textAlign: 'center'
                              }}>
                                {opp.toFixed(2)}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {/* Bet Value Queue - on next line */}
                      {awesomeBet1BetValueQueue.length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Bet Queue:</span>
                          <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                            {awesomeBet1BetValueQueue.map((betVal, idx) => (
                              <span key={idx} style={{
                                padding: '2px 6px',
                                backgroundColor: betVal > 0 ? '#d4edda' : '#f8d7da',
                                color: betVal > 0 ? '#155724' : '#721c24',
                                borderRadius: '4px',
                                fontSize: '10px',
                                fontWeight: 'bold',
                                border: `1px solid ${betVal > 0 ? '#c3e6cb' : '#f5c6cb'}`,
                                minWidth: '24px',
                                textAlign: 'center'
                              }}>
                                {betVal}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {/* Manual edit last bet value */}
                      {awesomeBet1BetValueQueue.length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginLeft: '70px' }}>
                          <span style={{ fontSize: '10px', fontWeight: 'bold', color: '#6c757d' }}>Edit Last Bet:</span>
                          <input
                            type="number"
                            value={awesomeBet1ManualBetValue}
                            onChange={(e) => setAwesomeBet1ManualBetValue(e.target.value)}
                            placeholder={awesomeBet1BetValueQueue[awesomeBet1BetValueQueue.length - 1].toString()}
                            style={{
                              width: '60px',
                              padding: '2px 4px',
                              fontSize: '10px',
                              borderRadius: '4px',
                              border: '1px solid #ced4da'
                            }}
                          />
                          <button
                            onClick={() => {
                              const parsed = parseFloat(awesomeBet1ManualBetValue);
                              if (!isNaN(parsed)) {
                                setAwesomeBet1BetValueQueue(prev => {
                                  if (prev.length === 0) return prev;
                                  const next = [...prev];
                                  next[next.length - 1] = parsed;
                                  return next;
                                });
                                setAwesomeBet1BetValue(parsed);
                                setAwesomeBet1ManualBetValue('');
                              }
                            }}
                            style={{
                              padding: '2px 6px',
                              fontSize: '10px',
                              borderRadius: '4px',
                              border: 'none',
                              backgroundColor: '#007bff',
                              color: 'white',
                              cursor: 'pointer',
                              fontWeight: 'bold'
                            }}
                          >
                            Update
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                  {/* Awesome Bet 2 Queue + Results */}
                  {(awesomeBetQueue2.length > 0 || awesomeBet2Results.length > 0) && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '4px' }}>
                      {/* Awesome Bet 2 Queue */}
                      {awesomeBetQueue2.length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Awesome Bet 2:</span>
                          <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                            {awesomeBetQueue2.map((betVal, idx) => (
                              <span key={idx} style={{
                                padding: '2px 6px',
                                backgroundColor: betVal > 0 ? '#d4edda' : '#f8d7da',
                                color: betVal > 0 ? '#155724' : '#721c24',
                                borderRadius: '4px',
                                fontSize: '10px',
                                fontWeight: 'bold',
                                border: `1px solid ${betVal > 0 ? '#c3e6cb' : '#f5c6cb'}`,
                                minWidth: '24px',
                                textAlign: 'center'
                              }}>
                                {betVal}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {/* Awesome Bet 2 Results */}
                      {awesomeBet2Results.length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Awesome Bet 2 Results:</span>
                          <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                            {awesomeBet2Results.map((result, idx) => (
                              <span key={idx} style={{
                                padding: '2px 6px',
                                backgroundColor: result === 1 ? '#e8f4fd' : '#e8f9e8',
                                color: result === 1 ? '#007bff' : '#28a745',
                                borderRadius: '4px',
                                fontSize: '10px',
                                fontWeight: 'bold',
                                border: `1px solid ${result === 1 ? '#b3d9ff' : '#a3d9a3'}`,
                                minWidth: '24px',
                                textAlign: 'center'
                              }}>
                                {result}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  {/* Reasoning Row */}
                  {highProbabilityBetReasoning.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', marginTop: '4px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#495057', minWidth: '70px' }}>Reasoning:</span>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', flex: 1 }}>
                        {highProbabilityBetReasoning.map((reason, idx) => (
                          <div key={idx} style={{
                            padding: '4px 8px',
                            backgroundColor: '#f8f9fa',
                            borderRadius: '4px',
                            fontSize: '10px',
                            color: '#495057',
                            border: '1px solid #dee2e6',
                            fontFamily: 'monospace'
                          }}>
                            {reason}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            <button
              onClick={togglePatternModal}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '16px',
                color: '#dc3545',
                cursor: 'pointer',
                fontWeight: 'bold',
                padding: '4px 8px'
              }}
              title="Close modal"
            >
              ×
            </button>
          </div>

          {/* Compact Pattern Prediction Results - All lengths 6-11 */}
          {showPatternAnalysis && (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '6px',
              marginBottom: '15px'
            }}>
              {streamAnalysis.allSubStreams.map((subStreamData, index) => {
              const percentage1 = parseFloat(subStreamData.percentage1);
              const percentage2 = parseFloat(subStreamData.percentage2);
              const totalMatches = subStreamData.countPattern1 + subStreamData.countPattern2;
              const hasHighProbability = (percentage1 > 70 || percentage2 > 70)  &&
                                        totalMatches >= 5;
              // Check if at least one value in the pattern is red (value 1)
              const hasRedLine = subStreamData.subStream.some(bit => bit === 1);
              const isOpportunity = hasRedLine;
              
              return (
              <div key={index} style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '6px 10px',
                backgroundColor: isOpportunity ? '#fff3cd' : '#f8f9fa',
                borderRadius: '4px',
                border: '1px solid #e9ecef',
                borderBottom: hasHighProbability ? '3px solid #dc3545' : '1px solid #e9ecef',
                borderLeft: isOpportunity ? '4px solid #ffc107' : '1px solid #e9ecef'
              }}>
                {/* Length label */}
                <div style={{
                  fontSize: '10px',
                  fontWeight: 'bold',
                  color: '#495057',
                  minWidth: '30px'
                }}>
                  {subStreamData.length}:
                </div>
                
                {/* Substream pattern */}
                <div style={{ display: 'flex', gap: '2px' }}>
                  {subStreamData.subStream.map((bit, bitIndex) => (
                    <div key={bitIndex} style={{
                      width: '16px',
                      height: '16px',
                      borderRadius: '3px',
                      backgroundColor: bit === 2 ? '#28a745' : '#dc3545',
                      color: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '9px',
                      fontWeight: 'bold'
                    }}>
                      {bit}
                    </div>
                  ))}
                </div>
                
                {/* +1 Probability */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '2px 8px',
                  backgroundColor: '#e8f4fd',
                  borderRadius: '3px',
                  border: '1px solid #b3d9ff'
                }}>
                  <span style={{ fontSize: '9px', color: '#007bff', fontWeight: 'bold' }}>+1:</span>
                  <span style={{ fontSize: '10px', color: '#495057', fontWeight: 'bold' }}>{subStreamData.percentage1}%</span>
                  <span style={{ fontSize: '9px', color: '#6c757d' }}>({subStreamData.countPattern1})</span>
                </div>
                
                {/* +2 Probability */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '2px 8px',
                  backgroundColor: '#e8f9e8',
                  borderRadius: '3px',
                  border: '1px solid #a3d9a3'
                }}>
                  <span style={{ fontSize: '9px', color: '#28a745', fontWeight: 'bold' }}>+2:</span>
                  <span style={{ fontSize: '10px', color: '#495057', fontWeight: 'bold' }}>{subStreamData.percentage2}%</span>
                  <span style={{ fontSize: '9px', color: '#6c757d' }}>({subStreamData.countPattern2})</span>
                </div>
              </div>
              );
            })}
            </div>
          )}

          {/* Extension Patterns Section */}
     

          {/* Summary Footer */}
          <div style={{
            marginTop: '15px',
            paddingTop: '10px',
            borderTop: '1px solid #dee2e6',
            fontSize: '10px',
            color: '#6c757d',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div>
              Based on {streamAnalysis.totalBits} total games | {streamAnalysis.totalMatches} total pattern matches
            </div>
            <div style={{
              padding: '4px 8px',
              backgroundColor: '#e9ecef',
              borderRadius: '4px',
              fontWeight: 'bold'
            }}>
              Overall Confidence: {Math.max(streamAnalysis.percentage1, streamAnalysis.percentage2)}%
            </div>
          </div>
        </div>
      )}

      {shouldShowStopMoon && (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          marginTop: '12px',
          padding: '10px',
          backgroundColor: '#dc3545',
          color: 'white',
          borderRadius: '8px',
          fontWeight: 'bold',
          fontSize: '16px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
          animation: 'pulse 2s infinite'
        }}>
          ⚠️ Stop Moon and idle
        </div>
      )}

      <style>
        {`
          @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
          }
          
          @keyframes slideDown {
            from {
              opacity: 0;
              transform: translateY(-20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
        `}
      </style>

      {/* FireSignalService for Awesome Bet 1 */}
      {awesomeBet1BetValue !== null && (
        <FireSignalService
          botName="AwesomeBet1"
          betValue={awesomeBet1BetValue}
          fireSignal={awesomeBet1FireSignal}
          onFireSignal={() => {
            // Reset fire signal after it's sent
            setAwesomeBet1FireSignal(false);
          }}
          gameHash={currentHash || null}
          lastValue={lastGeneratedBust}
        />
      )}
    </div>
  );
}

export default HeaderSection;