// Service to fetch bot configuration from Firebase
import { db } from '../config/firebase';
import { doc, getDoc } from 'firebase/firestore';

/**
 * Fetches bot configuration from Firebase
 * @param {Object} options - Configuration options
 * @param {string} options.collection - Collection name (e.g., 'config', 'botSettings')
 * @param {string} options.documentId - Document ID (e.g., 'botSettings', 'mainConfig')
 * @param {string[]} [options.fields] - Optional array of specific field names to retrieve. If not provided, returns all fields.
 * @returns {Promise<Object|null>} Configuration object or null if not found
 * 
 * @example
 * // Read all fields from a document
 * fetchBotConfig({ collection: 'config', documentId: 'botSettings' })
 * 
 * @example
 * // Read only specific fields
 * fetchBotConfig({ 
 *   collection: 'config', 
 *   documentId: 'botSettings',
 *   fields: ['betAmount', 'threshold', 'enabled']
 * })
 */
export const fetchBotConfig = async ({ 
  collection, 
  documentId, 
  fields = null 
} = {}) => {
  try {
    // Default values if not provided
    const collectionName = collection || 'config';
    const docId = documentId || 'botSettings';
    
    console.log('[BotConfig] Starting to fetch bot configuration from Firebase...');
    console.log('[BotConfig] Collection:', collectionName);
    console.log('[BotConfig] Document ID:', docId);
    if (fields && fields.length > 0) {
      console.log('[BotConfig] Fields to retrieve:', fields);
    } else {
      console.log('[BotConfig] Retrieving all fields');
    }
    
    const docRef = doc(db, collectionName, docId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      const allData = docSnap.data();
      
      // If specific fields are requested, filter the data
      let configData;
      if (fields && fields.length > 0) {
        configData = {};
        console.log('[BotConfig] Extracting field values:');
        console.log('[BotConfig] ┌─────────────────────────────────────────────────┐');
        fields.forEach(field => {
          if (allData.hasOwnProperty(field)) {
            configData[field] = allData[field];
            // Log each field with its value
            const value = allData[field];
            const valueType = typeof value;
            const displayValue = valueType === 'string' && value.length > 100 
              ? value.substring(0, 100) + '...' 
              : value;
            console.log(`[BotConfig] │ ${field.padEnd(20)} = ${String(displayValue).padEnd(30)} (${valueType})`);
          } else {
            console.warn(`[BotConfig] │ ${field.padEnd(20)} = NOT FOUND`);
          }
        });
        console.log('[BotConfig] └─────────────────────────────────────────────────┘');
        console.log('[BotConfig] ✅ Configuration loaded successfully (filtered fields)');
        console.log('[BotConfig] Retrieved fields:', Object.keys(configData));
      } else {
        configData = allData;
        console.log('[BotConfig] ✅ Configuration loaded successfully (all fields)');
        console.log('[BotConfig] Available fields:', Object.keys(configData));
      }
      
      console.log('[BotConfig] Configuration data:', configData);
      return configData;
    } else {
      console.warn(`[BotConfig] ⚠️ No configuration document found at: ${collectionName}/${docId}`);
      return null;
    }
  } catch (error) {
    console.error('[BotConfig] ❌ Error fetching bot configuration from Firebase:', error);
    console.error('[BotConfig] Error details:', {
      code: error.code,
      message: error.message
    });
    
    // Provide helpful guidance for common errors
    if (error.code === 'permission-denied') {
      console.error('[BotConfig] ⚠️ PERMISSION DENIED ERROR');
      console.error('[BotConfig] ========================================');
      console.error('[BotConfig] Your Firestore security rules are blocking read access.');
      console.error('[BotConfig] To fix this, update your Firestore Rules in Firebase Console:');
      console.error('[BotConfig]');
      console.error('[BotConfig] Go to: Firebase Console > Firestore Database > Rules');
      console.error('[BotConfig]');
      console.error('[BotConfig] Add this rule to allow read access:');
      console.error('[BotConfig]');
      console.error('[BotConfig] rules_version = \'2\';');
      console.error('[BotConfig] service cloud.firestore {');
      console.error('[BotConfig]   match /databases/{database}/documents {');
      console.error('[BotConfig]     match /bots/{botId} {');
      console.error('[BotConfig]       allow read: if true;');
      console.error('[BotConfig]     }');
      console.error('[BotConfig]   }');
      console.error('[BotConfig] }');
      console.error('[BotConfig] ========================================');
    }
    
    return null;
  }
};

/**
 * Fetches bot configuration and logs the result
 * This is a convenience function that can be called at app startup
 * 
 * @param {Object} options - Configuration options
 * @param {string} [options.collection='config'] - Collection name
 * @param {string} [options.documentId='botSettings'] - Document ID
 * @param {string[]} [options.fields] - Optional array of specific field names to retrieve
 * 
 * @example
 * // Load all fields from default location
 * loadBotConfiguration()
 * 
 * @example
 * // Load from custom collection/document
 * loadBotConfiguration({ collection: 'settings', documentId: 'main' })
 * 
 * @example
 * // Load only specific fields
 * loadBotConfiguration({ 
 *   collection: 'config', 
 *   documentId: 'botSettings',
 *   fields: ['betAmount', 'enabled']
 * })
 */
export const loadBotConfiguration = async (options = {}) => {
  console.log('[BotConfig] ========================================');
  console.log('[BotConfig] Loading Bot Configuration from Firebase');
  console.log('[BotConfig] ========================================');
  
  const config = await fetchBotConfig(options);
  
  if (config) {
    console.log('[BotConfig] ========================================');
    console.log('[BotConfig] ✅ Bot Configuration Loaded Successfully');
    console.log('[BotConfig] ========================================');
    return config;
  } else {
    console.log('[BotConfig] ========================================');
    console.log('[BotConfig] ⚠️ No Configuration Found or Error Occurred');
    console.log('[BotConfig] ========================================');
    return null;
  }
};

/**
 * Fetches multiple bot configurations from Firebase
 * @param {Object} options - Configuration options
 * @param {string} options.collection - Collection name (e.g., 'bots')
 * @param {string[]} options.documentIds - Array of document IDs to fetch (e.g., ['bot1', 'bot2', 'bot3'])
 * @param {string[]} [options.fields] - Optional array of specific field names to retrieve
 * @returns {Promise<Object>} Object with document IDs as keys and their data as values
 * 
 * @example
 * // Load all fields from multiple bots
 * const bots = await loadMultipleBotConfigs({
 *   collection: 'bots',
 *   documentIds: ['bot1', 'bot2', 'bot3']
 * });
 * 
 * @example
 * // Load specific fields from multiple bots
 * const bots = await loadMultipleBotConfigs({
 *   collection: 'bots',
 *   documentIds: ['bot1', 'bot2'],
 *   fields: ['name', 'active', 'budget']
 * });
 */
export const loadMultipleBotConfigs = async ({ 
  collection, 
  documentIds, 
  fields = null 
} = {}) => {
  if (!collection || !documentIds || !Array.isArray(documentIds)) {
    console.error('[BotConfig] ❌ Invalid parameters for loadMultipleBotConfigs');
    return {};
  }

  console.log('[BotConfig] ========================================');
  console.log('[BotConfig] Loading Multiple Bot Configurations');
  console.log('[BotConfig] Collection:', collection);
  console.log('[BotConfig] Document IDs:', documentIds);
  if (fields && fields.length > 0) {
    console.log('[BotConfig] Fields to retrieve:', fields);
  }
  console.log('[BotConfig] ========================================');

  const results = {};
  
  // Fetch all documents in parallel
  const promises = documentIds.map(async (docId) => {
    const config = await fetchBotConfig({ collection, documentId: docId, fields });
    if (config) {
      results[docId] = config;
      console.log(`[BotConfig] ✅ Loaded ${docId}:`, config.name || docId);
    } else {
      console.warn(`[BotConfig] ⚠️ Failed to load ${docId}`);
    }
  });

  await Promise.all(promises);

  console.log('[BotConfig] ========================================');
  console.log('[BotConfig] ✅ Multiple Bot Configurations Loaded');
  console.log('[BotConfig] Successfully loaded:', Object.keys(results).length, 'out of', documentIds.length, 'bots');
  console.log('[BotConfig] Loaded bot IDs:', Object.keys(results));
  Object.keys(results).forEach(docId => {
    const botName = results[docId].name || docId;
    console.log(`[BotConfig]   - ${docId}: ${botName}`);
  });
  console.log('[BotConfig] ========================================');

  return results;
};

