// services/signalLogger.js
// Centralized signal logging service

class SignalLogger {
  constructor() {
    this.listeners = [];
    this.maxLogs = 100; // Keep last 100 logs
  }

  // Subscribe to signal logs
  subscribe(callback) {
    this.listeners.push(callback);
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(listener => listener !== callback);
    };
  }

  // Log a signal event
  logSignal({ botName, betValue, webhookUrl, status, error, retryCount, timestamp, gameHash, lastValue, message }) {
    const logEntry = {
      id: Date.now() + Math.random(), // Unique ID
      timestamp: timestamp || new Date(),
      botName: botName || 'Unknown',
      betValue: betValue ?? '',
      webhookUrl: webhookUrl || '',
      status: status || 'pending', // 'pending', 'success', 'error'
      error: error || null,
      retryCount: retryCount || 0,
      gameHash: gameHash ?? null,
      lastValue: lastValue ?? null,
      message: message || null,
      formattedTime: this.formatTime(timestamp || new Date())
    };

    // Notify all listeners
    this.listeners.forEach(listener => {
      try {
        listener(logEntry);
      } catch (error) {
        // Silently ignore listener errors
      }
    });
  }

  formatTime(date) {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    const milliseconds = date.getMilliseconds().toString().padStart(3, '0');
    return `${hours}:${minutes}:${seconds}.${milliseconds}`;
  }
}

// Export singleton instance
export const signalLogger = new SignalLogger();

