// Dev CSV data exported as JavaScript module
// This file contains the test data from dev.csv
export const devCsvValues = [1, 2, 3, 2, 3, 5, 2, 3, 2, 4];

