// Firebase configuration
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// TODO: Replace with your Firebase configuration
// You can find this in your Firebase project settings
const firebaseConfig = {
  apiKey: "AIzaSyAAqd6YldHj_T8cbIo1DDIvwLyhBrEbErg",
  authDomain: "icrash-4443c.firebaseapp.com",
  projectId: "icrash-4443c",
  storageBucket: "icrash-4443c.firebasestorage.app",
  messagingSenderId: "280733636986",
  appId: "1:280733636986:web:8376c84ac1db984aa05ec3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
const db = getFirestore(app);

export { db };
export default app;

