// Generate ThreeRedSyncSeries binary string
// Logic: 3+ games with bust < 2x followed by a C value > 2x
// If C >= 2.7, add '1'; if 2x < C < 2.7, add '0'
// Result is in reversed order (newest to oldest)
export const generateThreeRedSyncSeries = (bustValues) => {
  if (!bustValues || bustValues.length === 0) {
    return {
      binaryString: '',
      p1: 0,
      p11: 0,
      p111: 0
    };
  }

  // Reverse to process newest first
  const reversed = [...bustValues].reverse();
  const binary = [];
  let currentLowSequence = [];
  
  for (let i = 0; i < reversed.length - 1; i++) {
    const currentBust = reversed[i];
    const nextBust = reversed[i + 1];
    
    // If current bust is < 2, add to current low sequence
    if (currentBust < 2) {
      currentLowSequence.push(currentBust);
    } else {
      // If we have a sequence of 3+ low busts and current value is > 2
      if (currentLowSequence.length >= 3 && currentBust > 2) {
        // Add '1' if C >= 2.7, '0' if 2x < C < 2.7
        if (currentBust >= 2.5) {
          binary.push('1');
        } else {
          binary.push('0');
        }
      }
      // Reset the sequence
      currentLowSequence = [];
    }
  }
  
  // Check if the last element completes a sequence
  const lastIndex = reversed.length - 1;
  const lastBust = reversed[lastIndex];
  
  if (lastBust !== undefined) {
    if (lastBust < 2) {
      currentLowSequence.push(lastBust);
      // Don't output anything for incomplete sequences
    } else {
      // If the last element is > 2.0, it might complete a sequence
      if (currentLowSequence.length >= 3 && lastBust > 2) {
        if (lastBust >= 2.5) {
          binary.push('1');
        } else {
          binary.push('0');
        }
      }
    }
  }

  // Return binary string (not reversed - newest to oldest, right to left)
  const binaryString = binary.join('');
  
  // Calculate pattern counts
  const patternCounts = calculatePatternCounts(binaryString);
  
  return {
    binaryString,
    p1: patternCounts.p1,
    p11: patternCounts.p11,
    p111: patternCounts.p111,
    n0: patternCounts.n0
  };
};

// Helper function to calculate p1, p11, p111, n0 from a binary string
const calculatePatternCounts = (binaryString) => {
  if (!binaryString || binaryString.length === 0) {
    return { p1: 0, p11: 0, p111: 0, n0: 0 };
  }
  
  // Calculate pattern counts by scanning from right to left (end to start of string)
  // These properties count occurrences that appear BEFORE finding the target pattern
  // "Before" means positions we encounter FIRST when scanning from right to left
  
  // p1: Count how many '1' digits appear before the first "11" pattern (scanning from right)
  // Example: "1101001000100" 
  //   Positions: 0 1 2 3 4 5 6 7 8 9 10 11 12
  //   Values:    1 1 0 1 0 0 1 0 0 0  1  0  0
  //   Scan R→L: start at 12, find "11" at 0-1, count '1's encountered before = 3 (at pos 10, 6, 3)
  let countOnesBeforePair = 0;
  let foundPair11 = false;
  for (let i = binaryString.length - 1; i >= 0; i--) {
    if (i > 0 && binaryString.substring(i - 1, i + 1) === '11') {
      foundPair11 = true;
      break; // Found "11", stop counting
    }
    if (binaryString[i] === '1') {
      countOnesBeforePair++;
    }
  }
  if (!foundPair11) countOnesBeforePair = 0; // No "11" found, return 0
  
  // p11: Count how many "11" patterns appear before the first "111" pattern (scanning from right)
  // Example: "111011001000100"
  //   Scan R→L: start at end, find "111" pattern, count "11" patterns encountered before = 1
  let countPairsBeforeTriple = 0;
  let foundTriple111 = false;
  for (let i = binaryString.length - 1; i >= 2; i--) {
    if (binaryString.substring(i - 2, i + 1) === '111') {
      foundTriple111 = true;
      break; // Found "111", stop counting
    }
    // Check if current position is part of "11" pattern (but not overlapping with "111" we haven't found yet)
    if (i > 0 && binaryString.substring(i - 1, i + 1) === '11') {
      countPairsBeforeTriple++;
    }
  }
  if (!foundTriple111) countPairsBeforeTriple = 0; // No "111" found, return 0
  
  // p111: Count how many "111" patterns appear before the first "1111" pattern (scanning from right)
  // Example: "1111011100111000100"
  //   Scan R→L: start at end, find "1111" pattern, count "111" patterns encountered before = 2
  let countTriplesBeforeQuad = 0;
  let foundQuad1111 = false;
  for (let i = binaryString.length - 1; i >= 3; i--) {
    if (binaryString.substring(i - 3, i + 1) === '1111') {
      foundQuad1111 = true;
      break; // Found "1111", stop counting
    }
    // Check if current position is part of "111" pattern
    if (binaryString.substring(i - 2, i + 1) === '111') {
      countTriplesBeforeQuad++;
    }
  }
  if (!foundQuad1111) countTriplesBeforeQuad = 0; // No "1111" found, return 0
  
  // n0: Count how many '0' digits appear before the first '1' pattern (scanning from right)
  // Example: "0001001000100" 
  //   Positions: 0 1 2 3 4 5 6 7 8 9 10 11 12
  //   Values:    0 0 0 1 0 0 1 0 0 0  1  0  0
  //   Scan R→L: start at 12, find '1' at 10, count '0's encountered before = 2 (at pos 12, 11)
  //   If no '1' found, count all trailing zeros
  let countZerosBeforeOne = 0;
  for (let i = binaryString.length - 1; i >= 0; i--) {
    if (binaryString[i] === '1') {
      break; // Found '1', stop counting
    }
    if (binaryString[i] === '0') {
      countZerosBeforeOne++;
    }
  }
  
  return {
    p1: countOnesBeforePair,
    p11: countPairsBeforeTriple,
    p111: countTriplesBeforeQuad,
    n0: countZerosBeforeOne
  };
};

// Calculate max p1, p11, p111 by progressively removing end bytes
export const calculateMaxPatternCounts = (bustValues) => {
  // First, generate the full binary string
  const fullResult = generateThreeRedSyncSeries(bustValues);
  const binaryString = fullResult.binaryString;
  
  if (!binaryString || binaryString.length === 0) {
    return {
      maxP1: 0,
      maxP11: 0,
      maxP111: 0,
      maxN0: 0,
      originalP1: 0,
      originalP11: 0,
      originalP111: 0,
      originalN0: 0
    };
  }
  
  let maxP1 = fullResult.p1;
  let maxP11 = fullResult.p11;
  let maxP111 = fullResult.p111;
  let maxN0 = fullResult.n0;
  
  // Progressively remove characters from the end and calculate pattern counts
  // Start from full length (already have the value) down to 1
  for (let i = binaryString.length; i > 0; i--) {
    const truncatedString = binaryString.substring(0, i);
    const patternCounts = calculatePatternCounts(truncatedString);
    
    // Update max values
    if (patternCounts.p1 > maxP1) {
      maxP1 = patternCounts.p1;
    }
    if (patternCounts.p11 > maxP11) {
      maxP11 = patternCounts.p11;
    }
    if (patternCounts.p111 > maxP111) {
      maxP111 = patternCounts.p111;
    }
    if (patternCounts.n0 > maxN0) {
      maxN0 = patternCounts.n0;
    }
  }
  
  return {
    maxP1: maxP1,
    maxP11: maxP11,
    maxP111: maxP111,
    maxN0: maxN0,
    originalP1: fullResult.p1,
    originalP11: fullResult.p11,
    originalP111: fullResult.p111,
    originalN0: fullResult.n0
  };
};

