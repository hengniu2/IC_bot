export const isBotEnabled = (botName) => {
  try {
    const saved = localStorage.getItem('botControlStates');
    if (saved) {
      const states = JSON.parse(saved);
      return states[botName] === true;
    }
  } catch (e) {
    console.error('Error reading bot state:', e);
  }
  return false; // Default to disabled if not found
};

// Bot name mapping (control panel key -> actual bot name)
export const BOT_NAME_MAP = {
  'fourV': '4V',
  'swing': 'Swing',
  'badRed': 'BadRed',
  'threeRed': 'ThreeRed',
  'moonSeries': 'MoonSeries',
  'moonTouch': 'MoonTouch'
};
