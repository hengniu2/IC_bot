Backend (Laravel) Scaffolding Notes
====================================

This folder contains the Laravel-specific source files for the medical appointment API (controllers, models, services, routes, migrations, seeders). The full Laravel framework is not included because PHP/Composer were not available on this machine. Once PHP 8.1+ and Composer are installed, initialize Laravel and then keep/merge these files.

Quick setup once PHP/Composer are available
-------------------------------------------
1) Install PHP 8.1+ and Composer.
2) From this `backend` folder, initialize Laravel into the existing directory:
   - `composer create-project laravel/laravel .`
3) Copy/retain the provided app files (they match Laravel 10 layout). If the create-project overwrote them, re-apply the files below.
4) Set up `.env` (PostgreSQL), then run:
   - `php artisan key:generate`
   - `php artisan migrate --seed`
   - `php artisan serve`

Included files
--------------
- `app/Models/Doctor.php`
- `app/Models/Appointment.php`
- `app/Http/Controllers/DoctorController.php`
- `app/Http/Controllers/AppointmentController.php`
- `app/Http/Requests/StoreAppointmentRequest.php`
- `app/Services/AppointmentService.php`
- `routes/api.php` (append/replace routes)
- `database/migrations/2024_01_01_000000_create_doctors_and_appointments.php`
- `database/seeders/DoctorSeeder.php`

Backend highlights
------------------
- Pessimistic locking in booking (`lockForUpdate`).
- Unique constraint `(doctor_id, start_time)` to prevent double-booking.
- Validation for 30-min weekday slots between 09:00–17:00.


