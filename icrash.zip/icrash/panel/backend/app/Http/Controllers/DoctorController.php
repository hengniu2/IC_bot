<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Services\AppointmentService;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function index()
    {
        return Doctor::all();
    }

    public function availability(Request $request, Doctor $doctor, AppointmentService $service)
    {
        $date = CarbonImmutable::parse($request->query('date', now()->toDateString()));
        $slots = $service->availability($doctor, $date);

        return response()->json($slots);
    }
}

