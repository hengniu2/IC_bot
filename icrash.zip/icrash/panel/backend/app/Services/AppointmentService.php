<?php

namespace App\Services;

use App\Models\Appointment;
use App\Models\Doctor;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AppointmentService
{
    private const SLOT_MINUTES = 30;
    private const START_HOUR = 9;
    private const END_HOUR = 17; // exclusive

    public function book(int $doctorId, string $patientName, CarbonImmutable $start): Appointment
    {
        $this->ensureSlotValidity($start);

        $end = $start->addMinutes(self::SLOT_MINUTES);

        return DB::transaction(function () use ($doctorId, $patientName, $start, $end) {
            $exists = Appointment::where('doctor_id', $doctorId)
                ->where('start_time', $start)
                ->lockForUpdate()
                ->exists();

            if ($exists) {
                throw ValidationException::withMessages([
                    'start_time' => 'Slot was just booked. Please choose another time.',
                ]);
            }

            return Appointment::create([
                'doctor_id' => $doctorId,
                'patient_name' => $patientName,
                'start_time' => $start,
                'end_time' => $end,
                'status' => 'scheduled',
            ]);
        });
    }

    public function availability(Doctor $doctor, CarbonImmutable $date): array
    {
        $startOfDay = $date->startOfDay()->setTime(self::START_HOUR, 0);
        $endOfDay = $date->startOfDay()->setTime(self::END_HOUR, 0);

        $booked = $doctor->appointments()
            ->whereBetween('start_time', [$startOfDay, $endOfDay])
            ->pluck('start_time')
            ->map(fn($dt) => $dt->toIso8601String())
            ->toArray();

        $slots = [];
        for ($slot = $startOfDay; $slot < $endOfDay; $slot = $slot->addMinutes(self::SLOT_MINUTES)) {
            $slots[] = [
                'start_time' => $slot->toIso8601String(),
                'available' => !in_array($slot->toIso8601String(), $booked, true),
            ];
        }

        return $slots;
    }

    private function ensureSlotValidity(CarbonImmutable $start): void
    {
        if ($start->isWeekend()) {
            throw ValidationException::withMessages(['start_time' => 'Doctor works Mon-Fri only.']);
        }

        if ((int) $start->minute !== 0 && (int) $start->minute !== 30) {
            throw ValidationException::withMessages(['start_time' => 'Slots must start on the half hour.']);
        }

        $hour = (int) $start->hour;
        if ($hour < self::START_HOUR || $hour >= self::END_HOUR) {
            throw ValidationException::withMessages(['start_time' => 'Slots must be between 09:00-17:00.']);
        }
    }
}

