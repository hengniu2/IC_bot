# Medical Appointment API & Frontend

This repo has two parts:
- `backend/`: Laravel API for doctor availability and booking with locking to prevent double-bookings.
- `frontend/`: Vite + React UI to try the API (list doctors, show availability, book a slot, see conflicts).

What you need to run it (not installed here yet)
------------------------------------------------
- PHP 8.1+ with Composer
- Node.js 18+ with npm
- PostgreSQL 14+ (or update `.env` to match your DB)

How to bring up the backend once PHP/Composer are installed
-----------------------------------------------------------
1) `cd backend`
2) `composer create-project laravel/laravel .` (pulls the Laravel framework into this folder)
3) If the scaffolding overwrites files, copy the provided app files back (controllers, models, service, routes, migration, seeder).
4) Create and edit `.env` for your Postgres connection, then run:
   - `php artisan key:generate`
   - `php artisan migrate --seed`
5) Start the API: `php artisan serve --host=0.0.0.0 --port=8000`

How to run the frontend
-----------------------
1) `cd frontend`
2) `npm install`
3) `npm run dev` (default dev server: http://localhost:3000)
   - Set the API URL with `VITE_API_URL` or adjust the fallback in `src/App.jsx`.

Concurrency and booking rules
-----------------------------
- Pessimistic locking during booking plus a unique DB constraint on `(doctor_id, start_time)` so two patients can’t grab the same slot.
- Validation enforces 30-minute slots on weekdays between 09:00–17:00.
Key Terms:

MNP: Moon Next Pairs

TR+: Three Reds

MSS: Moon Sum Series

BVH (VFB): Bust Value History

MID: Moon Interval Difference

SBtrend: Immediate Analysis of Current Situation

Bots:

Red-Three-Bot:
This bot fires when the "Next Value" of the 3 cards in the TR+ pattern is less than 3.

MoonTouch Bot:
This bot fires when the last two values in the Moon Sum Series (MSS) are both less than 40.

MoonNextPairs Bot:
This bot checks the following MNP patterns:

const patternsToCheck = [
  [1, 1, 1, 1, 1, 2],
  [1, 1, 1, 1, 1, 2, 1],
  [1, 1, 1, 1, 1, 2, 1, 1],
  [1, 1, 1, 1, 1, 2, 1, 1, 1],
  [2, 2, 2, 2, 2, 1],
  [2, 2, 2, 2, 2, 1, 2],
  [2, 2, 2, 2, 2, 1, 2, 2],
  [2, 2, 2, 2, 2, 1, 2, 2, 2]
];

Let me know if you need any further clarification.

BadRedsBot
  3 reds
  Loss After Win: 2-3, <1.5

SwingBot
  3 Signals
  